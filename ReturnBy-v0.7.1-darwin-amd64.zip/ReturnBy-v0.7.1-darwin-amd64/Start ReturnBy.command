#!/bin/sh
cd "$(dirname "$0")" || exit 1
./ReturnBy
result=$?
if [ "$result" -ne 0 ]; then printf "Press Return to close."; read answer; fi
exit "$result"
