@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (py -3 start_returnby.py) else (python start_returnby.py)
if errorlevel 1 pause
