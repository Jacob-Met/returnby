#!/usr/bin/env python3
"""Local-only static server for the versioned ReturnBy browser build."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os
import sys
import webbrowser

HOST = "127.0.0.1"
PORT = 4173
URL = f"http://{HOST}:{PORT}/"
APP = Path(__file__).resolve().parent / "app"

def main():
    if not (APP / "index.html").is_file():
        print("ReturnBy app files are missing. Extract the whole ZIP first.", file=sys.stderr)
        return 1
    try:
        server = ThreadingHTTPServer((HOST, PORT), partial(SimpleHTTPRequestHandler, directory=str(APP)))
    except OSError as error:
        print(f"Cannot start ReturnBy at {URL}: {error}", file=sys.stderr)
        print("Close other apps using port 4173; the fixed port protects browser-local saved data.", file=sys.stderr)
        return 1
    print("ReturnBy v0.1.0 / portable backup edition")
    print(f"Open {URL} in your browser. Press Ctrl+C to stop.")
    print("Everything stays on this computer; the server listens only on 127.0.0.1.", flush=True)
    if os.environ.get("RETURNBY_NO_OPEN") != "1":
        webbrowser.open(URL)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        print("\nReturnBy stopped.")
    finally:
        server.server_close()
    return 0

if __name__ == "__main__":
    sys.exit(main())
