#!/bin/sh
cd "$(dirname "$0")"
exec python3 start_returnby.py
