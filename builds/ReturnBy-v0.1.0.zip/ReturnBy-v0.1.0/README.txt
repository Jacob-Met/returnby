RETURNBY — Portable browser build, v0.1.0

What this is
ReturnBy tracks reviewed return deadlines from pasted order confirmations,
offers .ics calendar reminders, printable return-trip checklists, and private
JSON backup/restore with explicit conflict review.

Requirements
Python 3.10+ installed. A modern browser. Google Chrome 156 was actually
tested; other browsers were not acceptance-tested for this release.
No npm install, internet access, account, or cloud service is required to run.

Launch (after EXTRACTING the whole ZIP)
Windows: Double-click start_returnby.cmd (Python 3 or py -3 must be installed).
macOS: In Terminal, run: python3 start_returnby.py
Linux: Run ./start_returnby.sh or python3 start_returnby.py
Open http://127.0.0.1:4173/ if the browser does not open automatically.
Keep the terminal open while using the app; Ctrl+C stops it.

IMPORTANT: Use the same address and port every time. Saved return records live
in browser localStorage keyed to that origin. Different browsers, profiles,
ports, or clearing site storage have separate data. Use Download backup before
switching browsers or clearing data. Keep JSON backups private: they include
merchant, order, amount, date and policy-source details. Original pasted email
text is NOT included in a backup. Do not open app/index.html via file://.

Data & known limitations
Runs a local static server bound to 127.0.0.1; no inbox connection or external
API. You must manually review order dates, policy windows, and store terms.
Import accepts at most 5 MiB and 10,000 saved orders; conflicting IDs block a
whole import. Edits in a second tab may require a fresh preview. The local
server has no authentication and is intended for one person's computer.
Do not make it accessible beyond localhost.

Verified
264 tests in 12 files; TypeScript & Vite production build; Chrome 156 real
browser acceptance for backup, import failures, concurrent-tab recovery,
text injection safety and restored records used by the trip-checklist
download. See screenshots/ for real app captures.
