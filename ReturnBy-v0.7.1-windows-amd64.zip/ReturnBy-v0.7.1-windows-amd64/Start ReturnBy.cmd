@echo off
cd /d "%~dp0"
ReturnBy.exe
if errorlevel 1 pause
