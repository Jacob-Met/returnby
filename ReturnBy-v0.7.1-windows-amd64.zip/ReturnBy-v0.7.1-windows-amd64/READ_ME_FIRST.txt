RETURNBY 0.7.1 — windows-amd64

Double-click Start ReturnBy.cmd (or ReturnBy.exe).
No Python, Node, Go, installation or network access is required.
A current browser is required. The complete browser app is inside the executable.
The launcher opens http://127.0.0.1:8769 in your normal browser.
If it cannot open automatically, open that address yourself.
Keep the launcher window open; Ctrl+C stops it. Saved work remains in your browser.

Use the SAME browser profile and address as your previous ReturnBy release.
This preserves saved purchases, refunds and trips without moving their data.
An occupied port does not cause a silent fallback. Close the other local server.
Advanced: --port 18769 or RETURNBY_PORT=18769 chooses another origin; use a backup
to transfer data. --no-open prints the address without opening a browser.
--version prints this executable's exact version and source.

These binaries are unsigned. macOS/Windows may show publisher checks.
Linux amd64 is exercised on the estate. Other platform binaries are crosscompiled;
read the release notes for actual platform execution coverage.

ReturnBy does not upload receipts or synchronize accounts. Backups are unencrypted.
Calendar files need import and notification setup in your calendar app.

Source: https://github.com/Jacob-Met/returnby/commit/593afb6b75460c8680317c71f42a81b3576438ff
Toolchain: go version go1.22.2 linux/amd64
