#!/usr/bin/env python3
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys, os

folder = Path(__file__).resolve().parent
host, port = "127.0.0.1", 8769
try:
    port = int(os.environ.get("RETURNBY_PORT", "8769"))
    if not 1 <= port <= 65535:
        raise ValueError("RETURNBY_PORT must be between 1 and 65535")
    server = ThreadingHTTPServer((host, port), partial(SimpleHTTPRequestHandler, directory=str(folder)))
except (OSError, ValueError) as error:
    print(f"ReturnBy cannot start on http://127.0.0.1:{port}:", error, file=sys.stderr)
    print("If the port is busy, set RETURNBY_PORT to a free port and start again.", file=sys.stderr)
    sys.exit(2)
print(f"ReturnBy running at http://127.0.0.1:{port}", flush=True)
print("Open this address in your browser; press Ctrl+C to stop.", flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
