RETURNBY / BROWSER PREVIEW / 2026-11-10 (UTC)

SOURCE
  Repo: https://github.com/Jacob-Met/returnby
  Commit: abd33f98a571e03e9c36d2ea0a27a392c823e275
  Pull request: https://github.com/Jacob-Met/returnby/pull/83

WHAT IT IS
  A local-only browser tracker for return deadlines. Paste a confirmation,
  review detected details, maintain several orders, back up and restore saved
  records, and download individual or combined calendar reminders.

START (requires Node.js 20+ and a current browser)
  Windows: double-click START-WINDOWS.cmd
  macOS or Linux: open a terminal in this folder, run ./start-mac-linux.sh
  All platforms: node serve.mjs
  Then open http://127.0.0.1:8787/ in your browser.
  Stop with Ctrl+C. The server binds only to your computer's loopback interface.
  If port 8787 is busy, set PORT to another integer before running.

CHANGED IN THIS PREVIEW
  The single-order calendar button now rereads latest saved details, rejects
  stale/removed/duplicate records instead of exporting the wrong deadline,
  and keeps the unsaved intake draft. The application uses the same reviewed,
  bounded RFC 5545 calendar logic for single and multi-order exports.

PRIVACY AND LIMITS
  Saved orders reside in this browser's localStorage, not in a cloud account.
  Different browser profiles or machines do not share the tracker automatically.
  Backups and downloaded calendar files must be handled privately.
  Merchant return windows are heuristics: confirm the deadline with the store.
  Cross-tab writes are not atomic; the download rechecks observed storage state.
  Neither a GitHub account nor an npm install is needed to run this package.
  Verified on Linux with Node 22 and headless Chrome 156; Windows, macOS and
  other browser combinations have not been independently tested this release.

BUILD / VERIFICATION
  Source commit above built using npm ci, npm test, npm run build on a
  HAMON Renpo fleet worker. 422 Vitest tests and TypeScript/Vite build passed.
  Actual Chrome test: valid .ics download; cross-tab-like stale date refusal,
  refreshed export and preserved draft. evidence/stale-calendar.png is a real
  browser capture with fabricated example orders.
