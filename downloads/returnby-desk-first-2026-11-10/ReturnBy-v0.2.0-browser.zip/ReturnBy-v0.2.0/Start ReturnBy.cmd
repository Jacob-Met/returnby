@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% == 0 (py -3 serve_returnby.py) else (python serve_returnby.py)
pause
