#!/usr/bin/env python3
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys

folder = Path(__file__).resolve().parent
host, port = "127.0.0.1", 8769
try:
    server = ThreadingHTTPServer((host, port), partial(SimpleHTTPRequestHandler, directory=str(folder)))
except OSError as error:
    print("ReturnBy cannot start on http://127.0.0.1:8769 (port in use or unavailable):", error, file=sys.stderr)
    sys.exit(2)
print("ReturnBy running at http://127.0.0.1:8769", flush=True)
print("Open this address in your browser; press Ctrl+C to stop.", flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
