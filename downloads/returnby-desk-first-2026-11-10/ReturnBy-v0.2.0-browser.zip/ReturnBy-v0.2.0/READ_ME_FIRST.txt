RETURNBY 0.2.0 — LOCAL BROWSER RELEASE

Requires Python 3; no Node/npm needed to use this release.
Windows: double-click Start ReturnBy.cmd, or run py -3 serve_returnby.py.
macOS: double-click Start ReturnBy.command, or run python3 serve_returnby.py.
Linux: run ./Start ReturnBy.sh, or python3 serve_returnby.py.
Then open http://127.0.0.1:8769 in your browser; press Ctrl+C to stop.
The launcher binds only to 127.0.0.1. Keep the same port/browser profile:
reviewed orders are saved in that browser's local storage for this origin.
Do not open index.html directly by file:// because the module assets need HTTP.

Review/save several returns, correct them, back up and restore, select calendar
reminders, plan a month, and download offline printable return-trip checklists.
Pasted emails are not uploaded or retained by the app. Downloaded backups
contain order details and are unencrypted; keep those files private.
Merchant rules are reference estimates, not verified current return policies.
Calendar reminders are file exports, not live subscriptions.

Source: https://github.com/Jacob-Met/returnby/commit/b5ab27fdd9c77100ec0a6d3894d497efb8d0e7c1
Build: npm ci; npm test; npm run build (from matching source)
