RETURNBY 0.2.1 — LOCAL BROWSER RELEASE

Requires Python 3; no Node/npm needed to use this release.
Windows: double-click Start ReturnBy.cmd, or run py -3 serve_returnby.py.
macOS: double-click Start ReturnBy.command, or run python3 serve_returnby.py.
Linux: run ./Start ReturnBy.sh, or python3 serve_returnby.py.
Then open http://127.0.0.1:8769 in your browser; press Ctrl+C to stop.
If 8769 is busy, choose a free port with RETURNBY_PORT (e.g. 18769).
Linux/macOS: RETURNBY_PORT=18769 python3 serve_returnby.py
Windows Command Prompt: set RETURNBY_PORT=18769, then py -3 serve_returnby.py.
The launcher binds only to 127.0.0.1. Keep the same port/browser profile:
reviewed orders are saved in that browser's local storage for this origin.
Do not open index.html directly by file:// because the module assets need HTTP.

Review/save several returns, correct them, back up and restore, select calendar
reminders, plan a month, and download offline printable return-trip checklists.
Pasted emails are not uploaded or retained by the app. Downloaded backups
contain order details, saved trips and private packing notes. Backups are
unencrypted; keep those files private.
Merchant rules are reference estimates, not verified current return policies.
Calendar reminders are file exports, not live subscriptions.

Source: https://github.com/Jacob-Met/returnby/commit/613f15f023c017f1ea1d53d901b73e157e29e7a4
Build: npm ci; npm test; npm run build (from matching source)
