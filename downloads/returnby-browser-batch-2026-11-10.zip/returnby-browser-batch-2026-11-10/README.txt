RETURNBY / MULTI-CONFIRMATION BROWSER PREVIEW / 2026-11-10 UTC

SOURCE AND STATUS
  Repository: https://github.com/Jacob-Met/returnby
  Source commit: ec5ed7acf589b360316ae81907827626f03f492f
  Source integration: https://github.com/Jacob-Met/returnby/pull/85
  All application files come from that exact merged commit; this is a
  downloaded offline preview, not a hosted account or inbox application.

WHAT IT DOES
  Review many order confirmation texts at once via the home page link:
  'Review several order confirmations together'. Add pasted text or local
  UTF-8 .txt files, correct dates/order details/window days per confirmation,
  select only reviewed orders, inspect duplicate warnings, then save one
  checked append. Existing calendar exports, backups, trip checklist,
  deadline overview and single-order intake remain available.

START / NODE.JS 20+ / NO NPM INSTALL
  Unzip this archive.
  Windows: run START-WINDOWS.cmd in the extracted folder.
  macOS/Linux: run ./start-mac-linux.sh from a terminal.
  Any platform: node serve.mjs
  Open http://127.0.0.1:8787/ . Stop the server with Ctrl+C.
  The server binds only to 127.0.0.1 (loopback). Set PORT to an unused
  port first if 8787 is occupied. No cloud account or credentials are used.

PRIVACY AND HONEST LIMITS
  Orders save to browser localStorage in that browser profile; pasted
  confirmation text remains only in unsaved memory, not stored.
  No email inbox is connected. Return policy windows are local heuristics.
  The selected append rereads saved orders before writing, but concurrent
  tabs can still write after that reread. Avoid simultaneous edits.
  Keep any backups or calendar downloads private. Sample screenshots use
  wholly fictional orders. No real payment or network model action exists.

BUILD AND ACCEPTANCE
  Exact source commit ran 461 Vitest tests (22 files) and a strict
  TypeScript/Vite build on a HAMON Renpo Linux node with Node 22.
  All six Chrome CDP acceptance groups passed: local file selection,
  corrected/selected append, duplicates with keyboard acknowledgment,
  stale second tab refusal, storage read/write recovery, malformed files,
  late reads, mobile 390px and keyboard review/save.
  evidence/browser-checks.json records those observed checks.
  evidence/desktop-final-review.png and phone-final-review.png are real
  browser captures with fictional inputs. Produced with a corrected local
  CDP key-event receiver; no product code was changed for the correction.
  ZIP contents and launch flow were tested after extraction on Linux.
  Windows/macOS launchers and other browsers were not independently run.

INTEGRITY
  SHA256SUMS.txt lists every file below the package root except itself.
  Binary contents are static, except the loopback HTTP serving script.
