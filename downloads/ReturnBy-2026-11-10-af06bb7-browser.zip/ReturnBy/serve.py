#!/usr/bin/env python3
"""Serve the packaged ReturnBy app only on this computer; no online service."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "site"
PORT = 8769

class LocalOnlyHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, format, *args):
        super().log_message(format, *args)

if __name__ == "__main__":
    if not (ROOT / "index.html").is_file():
        raise SystemExit("ReturnBy site files are missing. Extract the complete ZIP first.")
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), LocalOnlyHandler)
    except OSError as e:
        raise SystemExit(f"Cannot start ReturnBy on port {PORT}: {e}")
    print(f"ReturnBy is running locally: http://127.0.0.1:{PORT}/", flush=True)
    print("Keep this window open while using ReturnBy. Press Ctrl+C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
