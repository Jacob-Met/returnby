ReturnBy — standalone browser package
Source: https://github.com/Jacob-Met/returnby/commit/af06bb7b265ef281182d24e01f6c8c7005c5d790
Built: 2026-11-10, from exact pinned source (npm ci and npm run build).

Windows: extract the whole ZIP; double-click Start ReturnBy.cmd.
macOS: extract; open Terminal in this folder and run ./Start\ ReturnBy.command
Linux: extract; run ./Start\ ReturnBy.sh
All systems: Python 3 is required. You can also run python3 serve.py here.
Then visit http://127.0.0.1:8769/ in your browser.
Keep the terminal/window running; Ctrl+C stops the local server.

No npm install, login or payment is needed. The HTTP server binds ONLY to
127.0.0.1. No private order confirmation data is included in this package.
Saved returns live in that browser profile's localStorage, not the ZIP or a server.
Back up your saved orders before changing browser profiles or clearing storage.
An exported email is processed locally; no inbox or other online service is used.

Recent changes include local confirmation-file review, saved-return search,
and a cross-tab notification so you can refresh your tracked returns without
silently replacing an unsaved order draft. Tabs must share the same origin
(http://127.0.0.1:8769) for localStorage and cross-tab notices.
Merchant return-policy lookup is not a guarantee. Confirm the retailer's current
rules and when your return clock starts. No cross-device synchronization.
Chrome was tested on Linux; Windows/macOS launchers are not natively tested.
