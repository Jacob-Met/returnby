@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 serve.py
) else (
  python serve.py
)
if errorlevel 1 (
  echo Install Python 3 if needed and run this launcher again.
  pause
)
