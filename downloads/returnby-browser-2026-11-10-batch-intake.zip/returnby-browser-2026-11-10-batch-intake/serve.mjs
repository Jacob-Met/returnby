import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {dirname, extname, resolve, sep} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), 'site');
const port = Number(process.env.PORT ?? 8787);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('PORT must be between 1 and 65535');
const types = {
  '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8',
  '.css':'text/css; charset=utf-8', '.svg':'image/svg+xml',
  '.png':'image/png', '.jpg':'image/jpeg', '.ico':'image/x-icon',
  '.webmanifest':'application/manifest+json'
};
const server = createServer(async (req, res) => {
  if (req.headers.host !== `127.0.0.1:${port}` && req.headers.host !== `localhost:${port}`) {
    res.writeHead(403).end(); return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {res.writeHead(405,{'Allow':'GET, HEAD'}).end();return;}
  let raw;
  try {raw = decodeURIComponent(new URL(req.url ?? '/', 'http://127.0.0.1').pathname);}
  catch {res.writeHead(400).end();return;}
  if (raw.includes('\0') || raw.includes('\\')) {res.writeHead(400).end();return;}
  const filename=resolve(root, '.' + (raw === '/' ? '/index.html' : raw));
  if (!filename.startsWith(root + sep)) {res.writeHead(403).end();return;}
  try {
    const body=await readFile(filename);
    res.writeHead(200, {'Content-Type':types[extname(filename)]??'application/octet-stream',
      'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(req.method==='HEAD'?undefined:body);
  } catch {res.writeHead(404).end();}
});
server.listen(port,'127.0.0.1',()=>console.log(`ReturnBy ready: http://127.0.0.1:${port}/`));
