RETURNBY / LOCAL BROWSER PREVIEW / 2026-11-10 / MULTI-CONFIRMATION INTAKE

SOURCE
  Public repository: https://github.com/Jacob-Met/returnby
  Merged main commit: ec5ed7acf589b360316ae81907827626f03f492f
  Integration pull request: https://github.com/Jacob-Met/returnby/pull/85
  Feature parent: https://github.com/Jacob-Met/returnby/pull/39

HOW TO START (Node.js 20+ required; no npm install needed)
  Windows: double-click START-WINDOWS.cmd
  macOS/Linux: run ./start-mac-linux.sh in this extracted folder
  All platforms: node serve.mjs
  Open http://127.0.0.1:8787/ in a browser. Stop with Ctrl+C.
  Port busy? Choose a valid PORT environment value before launching.
  The server listens on this computer only (127.0.0.1).

WHAT CHANGED
  Start on the tracker and select "Review several order confirmations together"
  or open /batch-intake.html directly. Paste or load up to 20 UTF-8 text
  confirmations; correct each extracted order, explicitly select the reviewed
  orders, inspect possible duplicates and save the chosen orders in one append.
  Existing tracker editing, backup/restore, calendar export, trip checklist
  and monthly deadline planning remain available.

PRIVACY / LIMITS
  The original confirmation text stays in this page's memory and is not
  transmitted or stored by the app. Only approved fields enter browser
  localStorage. Files are read locally. No inbox, account or AI connection.
  Confirm retailer return deadlines independently; policies are heuristics.
  Concurrent tabs can race; stale review is checked but not transactional.
  Plain-text files only, <=100 KiB each, <=1 MiB total, <=20 confirmations.
  Amounts are displayed as entered, not verified payment data.
  Backups and calendar downloads can contain sensitive order data.
  Browser storage and reminders remain scoped to the same browser/profile/port.

WHAT WAS TESTED
  Renpo Linux worker, Node 22 and headless Chrome.
  461 Vitest tests passed across 22 files; TypeScript/Vite build passed.
  Six Chrome real-browser groups passed: local files, corrections, duplicates
  with keyboard acknowledgement, stale second-tab refusal, storage and
  file-read failure recovery, phone keyboard selection and final save.
  No recorded page/console errors or external network requests.
  evidence/ contains genuine fictional-order Chrome screenshots.
  The packaged entry and assets were checked after clean ZIP extraction.
  Windows and macOS native launchers were not independently exercised.
  This is a versioned browser package, not a formal GitHub Release.
