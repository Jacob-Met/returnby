# ReturnBy native Chrome receiving on LA7

**PASS:** the exact frozen optional store-order contribution works in real Chrome on the existing native LA7 route. The single receiving run passed all 14 groups: six baseline controls and eight candidate groups. The baseline also supplies the expected negative observation: it has no list-order selector.

This is actual browser qualification of the built application. It is not a production-site deployment, a source merge, or an Actions waiver.

## Exact inputs and native route

The original source/evidence packet remains unchanged on ThinkPad at `/home/jacob/hamon-universal-e3a41d2b3368-returnby-store-order`, clean Git `57b2e8a1c68b674bc76e8d371356c6286f2a3073`, over ReturnBy main `1e662c387be5f66f8499fac7ec443f58d2198379`. All 55 frozen source/test/config inputs and 16 previously built assets were transferred as 71 exact files, 359,048 bytes. No build, source test or dependency installation was repeated. `TRANSFER-RECEIPT.json` records SHA-256, Git blob identities, byte counts and original POSIX modes; Windows modes are not claimed to be POSIX modes.

The receiving directory is `C:\Users\minec\Hamon\receiving\autonomous-e3a41d2b3368-returnby-store-order` on device `42ad330c-bb9a-4d2f-bcb4-6efeb4c6583e` (DESKTOP-LA7CMTA).

The existing runtime was verified directly:
- Node `C:\Users\minec\Hamon\runtime\node-v24.21.0-win-x64\node.exe`: v24.21.0, SHA-256 `ba4e6d110e8c1592a1ecd390f6b05f3da124b13871a5be62b341a07a853c6c32`.
- Chrome `C:\Program Files\Google\Chrome\Application\chrome.exe`: actual browser protocol reports Chrome/154.0.8037.98.
- No Puppeteer or Playwright installation was needed. The receiver uses Node's built-in WebSocket and Chrome DevTools Protocol.
- Git 2.55.0.windows.5 is used only for this isolated native evidence checkpoint.

The pre-run observation at 22:22:53 UTC admitted 420,290,400,256 free disk bytes, 3,310,492 KiB free memory, 27% CPU load and zero Chrome processes. These are point-in-time observations, not a reservation.

## Actual application receiving

The run was 2026-10-08 22:22:54–22:22:59 UTC. Each version received a distinct new browser profile and an ephemeral HTTP server bound to 127.0.0.1. Seven synthetic reviewed-order records were seeded in that profile's localStorage. No existing profile or user data was read.

Both versions passed empty initial state; rendered deadline order and counts; due filtering without storage changes; an actual .ics download for the non-first ACME-late record; Remove of the exact ACME-early ID; and reload with retained records, default deadline order and all-filter state.

The candidate additionally passed:
- Native CDP mouse/Tab navigation to the real labeled select, with a visible 2px keyboard outline.
- Native End-key choice of “Store A–Z, then deadline”, followed by real DOM layout and card ordering: three ACME case/whitespace variants are contiguous, equal-deadline ties remain stable, Zulu records retain their within-store deadline order, and the blank store is last.
- Unchanged saved-record bytes when changing display order.
- A 390px viewport with the select fully inside the viewport and no horizontal document overflow.
- The same calendar and Remove actions after grouping and filtering, preserving immutable record identity.
- Reload resetting the session display choice to deadline without rewriting saved records.

The two real calendar downloads completed through Chrome's download subsystem into owned directories. Their UID, summary, all-day due date and reminder were checked against the intended visible record. The differing bytes reflect real DTSTAMP times; byte equality across the two downloads is not claimed.

Screenshots were inspected at desktop and 390px widths. The select, focus outline, grouped visible cards and existing actions are legible and contained. Complete screenshots, card geometry snapshots, downloaded ICS files, browser logs and protocol event evidence are preserved under `browser-v1/`. No page exception or page error was observed. Every application request remained on its private local origin.

## Preservation and cleanup

All 71 received source and built-asset bytes stayed unchanged. Both Chrome children exited 0, both HTTP servers closed, and only the two newly created test profiles were removed. A separate post-run native observation at 22:23:54 found zero Chrome processes carrying this owned root, absent profiles and no listeners on either receiving HTTP port. The browser slot was then released to the LP owner.

No live services, scheduled tasks, hub configuration, unrelated checkout, dependency target, credentials or security settings were changed. No policy bypass or GitHub request/write occurred. The Actions hold remains in force.

This uses headless Chrome with CDP-delivered keyboard/mouse events and software rendering; it is not physical keyboard delivery, GPU/window acceptance, parser/save-form coverage, or public deployment acceptance.

## Adoption boundary and other products

The established native LA7 receiving pattern is an exact-byte isolated input directory, explicit existing executable paths, fresh resource admission, private ephemeral browser/server state and recorded cleanup. The existing Aetherline owner route provided a concrete precedent; its WebGPU receiving failure was preserved as a distinct fact and was not used to infer GPU success here.

ReturnBy now has the previously missing actual-browser evidence. The candidate built closure is available under `candidate/dist` for its current product/release owner. Any later source integration or hosted adoption must preserve current owners, fresh parent composition and the Actions hold.

Echo remains separate: its accepted Linux replay binary and core/replay receipts do not establish native graphics. The existing LA7 Echo artifacts belong to the earlier Godot receiver. The observed LA7 seat had no Rust/Cargo on PATH, standard user Rust/Visual Studio locations were absent, and no existing Windows Rust receiver was established. The Echo owner's next bounded command is `CARGO_BUILD_JOBS=1 cargo build --locked --offline -p hamon-echo-statement --bin echo-statement` only after the exact complete source/config/module closure, dependency cache and native resource admission are established. Its current full-workspace graph is metadata-only and must not be blindly built; the unexecuted window receiver is Linux X11/Xvfb-specific.

The pneumatic cycle CLI remains qualified on its original native Linux runtime. No Windows binary, compiler, or deployment equivalence is inferred.

`ACCEPTANCE.json` and `MEMBER-INDEX.json` bind this append-only browser receipt. The prior ThinkPad unit/build/minimal-DOM packet remains historical and unchanged.
