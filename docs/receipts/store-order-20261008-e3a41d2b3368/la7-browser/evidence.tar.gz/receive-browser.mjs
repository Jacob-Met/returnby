import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync,rmSync} from 'node:fs';
import {resolve,dirname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
const root=dirname(fileURLToPath(import.meta.url));
const chrome='C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const sha=b=>createHash('sha256').update(b).digest('hex');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn,label,ms=15000){const end=Date.now()+ms;while(Date.now()<end){const x=await fn();if(x)return x;await sleep(100);}throw Error('Timed out: '+label);}
const manifest=JSON.parse(readFileSync(resolve(root,'TRANSFER-RECEIPT.json')));
function sourcePins(){return manifest.files.map(f=>{const b=readFileSync(resolve(root,f.path));assert.equal(b.length,f.bytes,f.path);assert.equal(sha(b),f.sha256,f.path);return {path:f.path,sha256:f.sha256};});}
const before=sourcePins();
const result={schema:'e3.returnby.actual-browser-receiving/1',started:new Date().toISOString(),node:process.version,platform:process.platform,source_git:manifest.source_git,transfer_sha256:manifest.transfer_sha256,scope:'Actual isolated Chrome static application receiving; synthetic local data; no production adoption',sides:[],source_unchanged:false};
const out=resolve(root,'browser-v1');mkdirSync(out,{recursive:false});
class CDP{
 constructor(ws){this.ws=ws;this.next=1;this.pending=new Map();this.events=[];
 ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}}else this.events.push(m);});}
 static async open(url){const ws=new WebSocket(url);await new Promise((r,j)=>{const t=setTimeout(()=>j(Error('CDP open timeout')),10000);ws.addEventListener('open',()=>{clearTimeout(t);r();},{once:true});ws.addEventListener('error',e=>{clearTimeout(t);j(Error('CDP socket error'));},{once:true});});return new CDP(ws);}
 send(method,params={},sessionId){const id=this.next++;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('CDP timeout '+method));},15000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}
 close(){this.ws.close();}
}
let records;
const deadlineIds=['receipt-zulu-expired','receipt-acme-early','receipt-acme-tie','receipt-zulu-early','receipt-unknown','receipt-beta','receipt-acme-late'];
const storeIds=['receipt-acme-early','receipt-acme-tie','receipt-acme-late','receipt-beta','receipt-zulu-expired','receipt-zulu-early','receipt-unknown'];
function groups(side,name,details){side.groups.push({name,status:'pass',details});}
async function receive(sideName){
 const side={side:sideName,groups:[],errors:[],server_requests:[],cleanup:{},source_unchanged:false};result.sides.push(side);
 const dir=resolve(out,sideName);mkdirSync(dir);const profile=resolve(dir,'profile');const downloads=resolve(dir,'downloads');mkdirSync(downloads);
 assert(!existsSync(profile));const dist=resolve(root,sideName,'dist');
 const server=createServer((req,res)=>{const u=new URL(req.url,'http://127.0.0.1');const pathname=u.pathname==='/'?'/index.html':u.pathname;const p=resolve(dist,'.'+decodeURIComponent(pathname));side.server_requests.push({method:req.method,path:u.pathname});if(!p.startsWith(dist+sep)||!existsSync(p)){res.writeHead(404);res.end();return;}const type=p.endsWith('.js')?'text/javascript':p.endsWith('.css')?'text/css':p.endsWith('.svg')?'image/svg+xml':'text/html';res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'});res.end(readFileSync(p));});
 await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r);});
 const origin='http://127.0.0.1:'+server.address().port;
 side.origin=origin;
 const args=['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-default-apps','--disable-sync','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'--window-size=1280,900','about:blank'];
 side.browser_command={executable:chrome,args};let proc,cdp,exited=false,exitInfo;
 let log='';try{
  proc=spawn(chrome,args,{stdio:['ignore','pipe','pipe'],windowsHide:true});
  side.pid=proc.pid;
  proc.stdout.on('data',b=>log+=b);proc.stderr.on('data',b=>log+=b);
  proc.once('exit',(code,signal)=>{exited=true;exitInfo={code,signal};});
  proc.once('error',e=>side.errors.push('spawn: '+e.message));
  const active=await until(()=>{const p=resolve(profile,'DevToolsActivePort');if(existsSync(p))return readFileSync(p,'utf8').trim().split(/\r?\n/);if(exited)throw Error('Chrome exited before debugging');return null;},'private Chrome debugging file',20000);
  cdp=await CDP.open('ws://127.0.0.1:'+active[0]+active[1]);
  side.browser=await cdp.send('Browser.getVersion');
  await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads,eventsEnabled:true});
  const target=await cdp.send('Target.createTarget',{url:'about:blank'});
  const {sessionId}=await cdp.send('Target.attachToTarget',{targetId:target.targetId,flatten:true});
  const send=(method,params={})=>cdp.send(method,params,sessionId);
  const evaluate=async expression=>{const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error('Page exception '+JSON.stringify(r.exceptionDetails));return r.result.value;};
  const ids=()=>evaluate("Array.from(document.querySelectorAll('#list .card')).map(c=>c.querySelector('[data-del]').dataset.del)");
  const storage=()=>evaluate("localStorage.getItem('returnby.v1')");
  async function click(selector){const p=await evaluate("(()=>{const e=document.querySelector("+JSON.stringify(selector)+");if(!e)throw Error('missing selector');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();if(!r.width||!r.height)throw Error('invisible target');return {x:r.x+r.width/2,y:r.y+r.height/2};})()");await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...p});await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...p});}
  async function key(key,code,keyCode){await send('Input.dispatchKeyEvent',{type:'rawKeyDown',key,code,windowsVirtualKeyCode:keyCode,nativeVirtualKeyCode:keyCode});await send('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:keyCode,nativeVirtualKeyCode:keyCode});}
  async function snapshot(name){const data=await evaluate("({title:document.title,order:document.querySelector('#list-order')?.value??null,focus:document.activeElement?.id,cards:Array.from(document.querySelectorAll('#list .card')).map(c=>({id:c.querySelector('[data-del]').dataset.del,icsId:c.querySelector('[data-ics]').dataset.ics,merchant:c.querySelector('.order-head strong').textContent,due:c.querySelector('.return-by').textContent,rect:{x:c.getBoundingClientRect().x,y:c.getBoundingClientRect().y,width:c.getBoundingClientRect().width,height:c.getBoundingClientRect().height}})),counts:['tracked-count','soon-count','expired-count'].map(id=>document.getElementById(id).textContent),storageKeys:Object.keys(localStorage)})");writeFileSync(resolve(dir,name+'.json'),JSON.stringify(data,null,2)+'\n');const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const b=Buffer.from(shot.data,'base64');writeFileSync(resolve(dir,name+'.png'),b);return {...data,screenshot_sha256:sha(b)};}
  await send('Page.enable');await send('Runtime.enable');await send('Log.enable');await send('Network.enable');
  await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
  await send('Page.navigate',{url:origin+'/'});
  await until(()=>evaluate("document.readyState==='complete'&&!!document.querySelector('#list .empty')"),'initial real application');
  assert.equal(await storage(),null);
  assert.equal(await evaluate("document.getElementById('tracked-count').textContent"),'0');
  groups(side,'new-profile-empty-tracker',{storageAbsent:true});
  if(!records)records=await evaluate("(()=>{const spec=[['receipt-zulu-early','Zulu Goods',2],['receipt-acme-late','ACME',6],['receipt-beta','Beta Outlet',4],['receipt-acme-early',' acme ',1],['receipt-unknown','',3],['receipt-acme-tie','Acme',1],['receipt-zulu-expired','Zulu Goods',-1]];const date=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');return spec.map(([id,merchant,offset],i)=>{const due=new Date();due.setHours(12,0,0,0);due.setDate(due.getDate()+offset);const ordered=new Date(due);ordered.setDate(ordered.getDate()-30);return {id,merchant,orderNo:'ITEM-'+(i+1),total:'10.00',orderDate:date(ordered),windowDays:30,windowSource:'user',createdAt:'2026-10-08T00:00:00.000Z'};});})()");
  const initialStorage=JSON.stringify(records);
  await evaluate("localStorage.setItem('returnby.v1',"+JSON.stringify(initialStorage)+")");
  await send('Page.reload',{ignoreCache:true});await until(async()=>JSON.stringify(await ids())===JSON.stringify(deadlineIds),'default deadline order');
  const initial=await snapshot('initial');
  assert.deepEqual(initial.counts,['7','6','1']);assert.deepEqual(initial.storageKeys,['returnby.v1']);assert.equal(await storage(),initialStorage);
  assert(initial.cards.every(x=>x.id===x.icsId));
  groups(side,'rendered-default-deadline-order',{ids:deadlineIds,counts:initial.counts,recordAndActionIdsAgree:true,screenshot:initial.screenshot_sha256});
  const hasOrder=await evaluate("!!document.getElementById('list-order')");
  if(sideName==='baseline'){
   assert.equal(hasOrder,false);side.feature_negative={expected:true,observed:'No list-order control; original rendered deadline order retained'};
  }else{
   assert.equal(hasOrder,true);
   const label=await evaluate("({value:document.getElementById('list-order').value,labels:Array.from(document.getElementById('list-order').labels).map(x=>x.textContent),options:Array.from(document.getElementById('list-order').options).map(x=>({value:x.value,text:x.textContent}))})");
   assert.equal(label.value,'deadline');assert(label.labels.some(x=>x.includes('List order')));assert.equal(label.options.length,2);assert.equal(label.options[1].text,'Store A–Z, then deadline');
   await click('#filter-all');await key('Tab','Tab',9);await key('Tab','Tab',9);await key('Tab','Tab',9);
   assert.equal(await evaluate("document.activeElement.id"),'list-order');
   const focus=await evaluate("({style:getComputedStyle(document.activeElement).outlineStyle,width:getComputedStyle(document.activeElement).outlineWidth})");assert.notEqual(focus.style,'none');assert.notEqual(focus.width,'0px');
   await key('End','End',35);
   await until(()=>evaluate("document.getElementById('list-order').value==='store'"),'native select keyboard choice');
   await until(async()=>JSON.stringify(await ids())===JSON.stringify(storeIds),'rendered grouped order');
   assert.equal(await storage(),initialStorage);
   const grouped=await snapshot('store-order');
   assert.equal(grouped.focus,'list-order');assert(grouped.cards.every((x,i,a)=>i===0||x.rect.y>a[i-1].rect.y));
   groups(side,'native-keyboard-store-order',{label,focus,ids:storeIds,persistenceUnchanged:true,screenshot:grouped.screenshot_sha256});
   await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:false});
   const narrow=await evaluate("(()=>{const s=document.getElementById('list-order');s.scrollIntoView({block:'center'});const r=s.getBoundingClientRect();return {left:r.left,right:r.right,width:r.width,viewport:innerWidth,documentWidth:document.documentElement.scrollWidth};})()");
   assert(narrow.left>=0&&narrow.right<=narrow.viewport&&narrow.width>0);assert(narrow.documentWidth<=narrow.viewport);
   const narrowShot=await snapshot('store-order-narrow');
   groups(side,'narrow-rendered-control',{...narrow,screenshot:narrowShot.screenshot_sha256});
   await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
  }
  await click('#filter-due');
  const expectedDue=(sideName==='candidate'?storeIds:deadlineIds).filter(x=>x!=='receipt-zulu-expired');
  await until(async()=>JSON.stringify(await ids())===JSON.stringify(expectedDue),'due filter with current ordering');
  assert.equal(await evaluate("document.getElementById('filter-due').getAttribute('aria-pressed')"),'true');
  assert.equal(await storage(),initialStorage);
  groups(side,'rendered-filter-preserves-storage',{ids:expectedDue});
  await click('[data-ics="receipt-acme-late"]');
  const file=await until(()=>{const files=readdirSync(downloads);return files.length===1&&files[0].endsWith('.ics')?files[0]:null;},'actual calendar download',20000);
  const icsBytes=readFileSync(resolve(downloads,file));const ics=icsBytes.toString('utf8').replace(/\r\n /g,'');
  assert.equal(file,'return-ACME.ics');assert(ics.includes('UID:receipt-acme-late@returnby\r\n'));assert(ics.includes('SUMMARY:Return deadline: ACME #ITEM-2\r\n'));assert(ics.includes('TRIGGER:-P3D\r\n'));
  const due=await evaluate("(()=>{const c=document.querySelector('[data-ics=\"receipt-acme-late\"]').closest('.card');return c.querySelector('.return-by').textContent.replace('RETURN BY ','').replaceAll('-','');})()");
  assert(ics.includes('DTSTART;VALUE=DATE:'+due+'\r\n'));assert.equal(await storage(),initialStorage);
  groups(side,'real-calendar-download-after-ordering',{file,bytes:icsBytes.length,sha256:sha(icsBytes),record:'receipt-acme-late',due});
  await click('[data-del="receipt-acme-early"]');
  const remaining=records.filter(x=>x.id!=='receipt-acme-early');const afterRemoval=JSON.stringify(remaining);
  await until(async()=>await storage()===afterRemoval,'actual remove persistence');
  assert.deepEqual(await ids(),expectedDue.filter(x=>x!=='receipt-acme-early'));
  groups(side,'real-remove-keeps-record-identity',{removed:'receipt-acme-early',storedIds:remaining.map(x=>x.id)});
  await send('Page.reload',{ignoreCache:true});
  const expectedReload=deadlineIds.filter(x=>x!=='receipt-acme-early');
  await until(async()=>JSON.stringify(await ids())===JSON.stringify(expectedReload),'reload defaults to deadline and all filter');
  assert.equal(await storage(),afterRemoval);
  if(sideName==='candidate')assert.equal(await evaluate("document.getElementById('list-order').value"),'deadline');
  const reload=await snapshot('reloaded');
  assert.deepEqual(reload.counts,['6','5','1']);
  groups(side,'reload-retains-records-resets-display-choice',{ids:expectedReload,counts:reload.counts,persistenceUnchanged:true});
  const browserErrors=cdp.events.filter(e=>e.sessionId===sessionId&&((e.method==='Runtime.exceptionThrown')||(e.method==='Log.entryAdded'&&e.params.entry.level==='error')));
  assert.deepEqual(browserErrors,[]);
  side.actual_download_events=cdp.events.filter(e=>e.method?.startsWith('Browser.download')).map(e=>({method:e.method,params:e.params}));
  side.page_request_urls=cdp.events.filter(e=>e.sessionId===sessionId&&e.method==='Network.requestWillBeSent').map(e=>e.params.request.url);
  assert(side.page_request_urls.every(u=>u.startsWith(origin+'/')||u.startsWith('blob:'+origin+'/')||u.startsWith('data:')));
  side.source_unchanged=JSON.stringify(sourcePins())===JSON.stringify(before);assert(side.source_unchanged);
  side.status='pass';
 }catch(e){side.status='failed';side.errors.push(e.stack||String(e));}
 finally{
  if(cdp){try{await cdp.send('Browser.close');}catch(e){side.cleanup.closeDiagnostic=e.message;}cdp.close();}
  if(proc&&!exited){try{await until(()=>exited,'owned Chrome exit',10000);}catch(e){side.cleanup.termination='owned child handle only';proc.kill();try{await until(()=>exited,'owned child termination',5000);}catch(x){side.cleanup.exitWaitError=x.message;}}}
  side.cleanup.browser_exit=exitInfo??null;side.cleanup.browser_exited=exited;
  await new Promise(r=>server.close(r));side.cleanup.server_closed=true;
  writeFileSync(resolve(dir,'browser.log'),log);
  if(exited&&existsSync(profile)){try{rmSync(profile,{recursive:true,force:false,maxRetries:3,retryDelay:250});side.cleanup.profile_removed=!existsSync(profile);}catch(e){side.cleanup.profile_remove_error=e.message;}}
  side.cleanup.profile_path=profile;
  side.source_unchanged=JSON.stringify(sourcePins())===JSON.stringify(before);
  writeFileSync(resolve(dir,'RESULT.json'),JSON.stringify(side,null,2)+'\n');
 }
 return side;
}
try{
 const baseline=await receive('baseline');assert.equal(baseline.status,'pass','baseline receiving failed');
 const candidate=await receive('candidate');assert.equal(candidate.status,'pass','candidate receiving failed');
 result.status='pass';
}catch(e){result.status='failed';result.error=e.stack||String(e);}
finally{
 result.finished=new Date().toISOString();result.source_unchanged=JSON.stringify(sourcePins())===JSON.stringify(before);
 result.synthetic_records=records;
 result.groups=result.sides.reduce((n,x)=>n+x.groups.length,0);
 result.cleanup_complete=result.sides.every(x=>x.cleanup.browser_exited&&x.cleanup.server_closed&&x.cleanup.profile_removed);
 if(!result.source_unchanged||!result.cleanup_complete)result.status='failed';
 writeFileSync(resolve(out,'RESULTS.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({status:result.status,groups:result.groups,sides:result.sides.map(x=>({side:x.side,status:x.status,groups:x.groups.length,errors:x.errors,cleanup:x.cleanup})),source_unchanged:result.source_unchanged,cleanup_complete:result.cleanup_complete,receipt:resolve(out,'RESULTS.json')},null,2));
 process.exitCode=result.status==='pass'?0:1;
}
