import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { stripTypeScriptTypes } from 'node:module';

const root=path.resolve(process.argv[2]);
const fixture=[
 {id:'zeta-first',merchant:'Zeta Outdoor',orderDate:'2026-10-01',windowDays:8,windowSource:'user',createdAt:'2026-10-01T10:00:00Z'},
 {id:'acme',merchant:'Acme Books',orderDate:'2026-10-01',windowDays:9,windowSource:'user',createdAt:'2026-10-01T10:01:00Z'},
 {id:'zeta-second',merchant:'Zeta Outdoor',orderDate:'2026-10-01',windowDays:10,windowSource:'user',createdAt:'2026-10-01T10:02:00Z'},
 {id:'birch',merchant:'Birch Home',orderDate:'2026-10-01',windowDays:11,windowSource:'user',createdAt:'2026-10-01T10:03:00Z'},
 {id:'expired',merchant:'Amber Shop',orderDate:'2026-09-01',windowDays:30,windowSource:'user',createdAt:'2026-10-01T10:04:00Z'},
 {id:'unnamed',merchant:'',orderDate:'2026-10-01',windowDays:14,windowSource:'user',createdAt:'2026-10-01T10:05:00Z'},
 {id:'zeta-case',merchant:'  ZETA   OUTDOOR ',orderDate:'2026-10-01',windowDays:8,windowSource:'user',createdAt:'2026-10-01T10:06:00Z'},
];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sources=async dir=>{
 const result={};
 for(const name of ['src/main.ts','src/deadline.ts','src/ics.ts','src/store.ts','index.html']){
  const b=await fs.readFile(path.join(dir,name)); result[name]=sha(b);
 }
 try{result['src/list-order.ts']=sha(await fs.readFile(path.join(dir,'src/list-order.ts')));}catch(e){if(e.code!=='ENOENT')throw e;}
 return result;
};
class ReceivingDate extends Date{
 constructor(...args){super(...(args.length?args:['2026-10-08T12:00:00Z']));}
 static now(){return Date.parse('2026-10-08T12:00:00Z');}
}
async function receive(kind){
 const dir=path.join(root,kind),before=await sources(dir);
 let savedRaw=JSON.stringify(fixture),writes=0,refresh,objectSerial=0;
 const originalRaw=savedRaw,objects=new Map(),anchors=[],elements=new Map(),cases=[];
 class Element{
  constructor(id){this.id=id;this.value='';this.innerHTML='';this.textContent='';this.dataset={};this.hidden=false;this.listeners={};this.classList={toggle(){}};}
  addEventListener(type,listener){this.listeners[type]=listener;}
  setAttribute(){}
  contains(){return false;}
  click(){anchors.push({href:this.href,download:this.download});}
  focus(){}
 }
 const element=id=>{if(!elements.has(id))elements.set(id,new Element(id));return elements.get(id)};
 const document={querySelector:s=>element(s),createElement:tag=>new Element(tag),activeElement:null};
 const context={console,Date:ReceivingDate,Intl,Math,Array,Map,Set,Number,String,Blob,crypto,
  HTMLButtonElement:Element,document,
  load:()=>JSON.parse(savedRaw),save:data=>{writes++;savedRaw=JSON.stringify(data)},
  parse:()=>{throw Error('Unexpected parser call')},lookup:()=>{throw Error('Unexpected policy call')},
  knownMerchants:[],samples:[],
  startDayRefresh:callback=>{refresh=callback},
  URL:{createObjectURL:blob=>{const key='blob:fixture-'+(++objectSerial);objects.set(key,blob);return key;},revokeObjectURL(){}},
 };
 vm.createContext(context);
 const execute=source=>vm.runInContext(stripTypeScriptTypes(source.replace(/^import[^\n]+\n/gm,'').replace(/^export /gm,'')),context);
 execute(await fs.readFile(path.join(dir,'src/deadline.ts'),'utf8'));
 execute(await fs.readFile(path.join(dir,'src/ics.ts'),'utf8'));
 if(kind==='candidate')execute(await fs.readFile(path.join(dir,'src/list-order.ts'),'utf8'));
 execute(await fs.readFile(path.join(dir,'src/main.ts'),'utf8'));
 const ids=()=>Array.from(element('#list').innerHTML.matchAll(/data-ics="([^"]+)"/g),m=>m[1]);
 const counts=()=>['#tracked-count','#soon-count','#expired-count'].map(s=>element(s).textContent);
 const check=(name,fn)=>{try{fn();cases.push({name,passed:true});}catch(e){cases.push({name,passed:false,message:e.message});}};
 const trigger=id=>element(id).listeners.click?.({target:element(id)});
 const setOrder=value=>{element('#list-order').value=value;element('#list-order').listeners.change?.({currentTarget:element('#list-order')});};
 const deadlineIds=['expired','zeta-first','zeta-case','acme','zeta-second','birch','unnamed'];
 const storeIds=['acme','expired','birch','zeta-first','zeta-case','zeta-second','unnamed'];
 check('existing default deadline sequence and global counts',()=>{assert.deepEqual(ids(),deadlineIds);assert.deepEqual(counts(),['7','6','1']);});
 element('#paste').value='Unfinished original email';element('#preview').innerHTML='<input name="merchant" value="Unfinished corrected store">';element('#preview').hidden=false;
 const intake=()=>[element('#paste').value,element('#preview').innerHTML,element('#preview').hidden];
 const draftBefore=intake();
 const html=await fs.readFile(path.join(dir,'index.html'),'utf8');
 check('one accessible optional store-order choice',()=>{
  assert.match(html,/<label class="list-order" for="list-order">/);
  assert.match(html,/<option value="deadline">Deadline \(soonest first\)<\/option><option value="store">Store A–Z, then deadline<\/option>/);
  assert.equal(typeof element('#list-order').listeners.change,'function');
 });
 setOrder('store');
 const storeObserved=ids();
 check('store contiguity, within-store deadlines, stable ties and unnamed records',()=>assert.deepEqual(storeObserved,storeIds));
 trigger('#filter-due');
 check('date filter keeps store order while counts remain global',()=>{
  assert.deepEqual(ids(),['acme','birch','zeta-first','zeta-case','zeta-second','unnamed']);
  assert.deepEqual(counts(),['7','6','1']);
 });
 trigger('#filter-expired');
 check('expired filter retains the exact target',()=>assert.deepEqual(ids(),['expired']));
 trigger('#filter-all');
 check('filter changes retain the selected store order',()=>assert.deepEqual(ids(),storeIds));
 setOrder('deadline');
 check('returning to default restores the original order',()=>assert.deepEqual(ids(),deadlineIds));
 setOrder('store');refresh();
 check('day refresh retains the selected store order',()=>assert.deepEqual(ids(),storeIds));
 check('view changes preserve unfinished intake and make no storage writes',()=>{
  assert.deepEqual(intake(),draftBefore);assert.equal(writes,0);assert.equal(savedRaw,originalRaw);
 });
 element('#list').listeners.click({target:{dataset:{ics:'zeta-second'}}});
 assert.equal(anchors.length,1);
 const calendar=await objects.get(anchors[0].href).text();
 check('original calendar action still targets the selected identity without writing',()=>{
  assert.match(calendar,/UID:zeta-second@returnby.local/);
  assert.match(calendar,/DTSTART;VALUE=DATE:20261011/);
  assert.equal(writes,0);assert.equal(savedRaw,originalRaw);
 });
 element('#list').listeners.click({target:{dataset:{del:'acme'}}});
 check('original Remove preserves all other saved records and their persisted order',()=>{
  assert.equal(writes,1);assert.deepEqual(JSON.parse(savedRaw),fixture.filter(row=>row.id!=='acme'));
  assert.equal(ids().includes('acme'),false);assert.deepEqual(intake(),draftBefore);
 });
 const after=await sources(dir);assert.deepEqual(after,before);
 return {kind,source:before,cases,store_observed:storeObserved,calendar_sha256:sha(calendar),calendar,writes,stored_after_remove:JSON.parse(savedRaw),source_bytes_unchanged:true};
}
const baseline=await receive('baseline'),candidate=await receive('candidate');
assert.deepEqual(candidate.cases.filter(c=>!c.passed),[]);
const expectedNegative=['one accessible optional store-order choice','store contiguity, within-store deadlines, stable ties and unnamed records','date filter keeps store order while counts remain global','filter changes retain the selected store order','day refresh retains the selected store order'];
assert.deepEqual(baseline.cases.filter(c=>!c.passed).map(c=>c.name),expectedNegative);
assert.equal(candidate.calendar,baseline.calendar);
assert.deepEqual(candidate.stored_after_remove,baseline.stored_after_remove);
const report={schema:'returnby.store-order.main-receiving/1',at:new Date().toISOString(),node:process.version,
 environment:'actual source through built-in TypeScript stripping in a minimal DOM fixture; fixed receiving clock, real ICS builder; not a browser execution',
 baseline,candidate,calendar_bytes_identical:true,remove_result_identical:true,status:'passed'};
const out=path.join(root,'MAIN-RECEIVING.json');
await fs.writeFile(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:report.status,baseline_pass:baseline.cases.filter(c=>c.passed).length,baseline_fail:baseline.cases.filter(c=>!c.passed).length,candidate_pass:candidate.cases.filter(c=>c.passed).length,candidate_fail:candidate.cases.filter(c=>!c.passed).length,receipt:out,sha256:sha(await fs.readFile(out))}));
