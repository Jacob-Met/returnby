from pathlib import Path
Path(__file__).with_name('PACKAGED_CODE_EXECUTED').write_text('ran')
