import pathlib,json,hashlib,shutil,datetime,os
R=pathlib.Path('/run/user/1000/snap.chromium/hamon-returnby-manual-db371a37f4c8')
S=R/'source';assert not S.exists()
m=json.loads((R/'evidence/original-source-manifest.json').read_text())['files']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for e in m:assert sha((R/'original'/e['path']).read_bytes())==e['sha256']
shutil.copytree(R/'original',S)
p=json.loads((R/'candidate-input-r1.json').read_text())
for name,content in p['files'].items():
 q=S/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(content)
entries=[]
for q in sorted(S.rglob('*')):
 if q.is_file():
  b=q.read_bytes();entries.append({'path':str(q.relative_to(S)),'bytes':len(b),'sha256':sha(b),'gitBlob':git(b)})
deltas=[e['path'] for e in entries if e['path'] not in {x['path'] for x in m} or e['sha256']!=next(x['sha256'] for x in m if x['path']==e['path'])]
assert set(deltas)==set(p['files'])
E=R/'evidence/candidate-r1';E.mkdir()
for name,rows in [('source-manifest.json',entries),('runtime-manifest.json',[e for e in entries if not e['path'].startswith('tests/')])]:
 (E/name).write_text(json.dumps({'base':p['base'],'files':rows},indent=2)+'\n')
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(entries),'deltas':deltas,'original46Exact':True}
(E/'source-freeze.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
