import pathlib,json,hashlib,datetime
R=pathlib.Path('/run/user/1000/snap.chromium/hamon-returnby-manual-db371a37f4c8');S=R/'source';E=R/'evidence/candidate-r1';E.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
extra=S/'node_modules/.vite/vitest/da39a3ee5e6b4b0d3255bfef95601890afd80709/results.json'
assert extra.stat().st_size==912 and sha(extra.read_bytes())=='3bb5fc520cb896a0b43c16b548685e8eb8f3af8793e25ff51433daaf9667e54f'
assert len([x for x in (S/'node_modules').rglob('*') if x.is_file()])==1
(S/'node_modules').rename(E/'staging-r1-carried-cache')
(E/'staging-negative.json').write_text(json.dumps({'observedPID':4117757,'error':'AssertionError at set(deltas)==set(p[files])','cause':'copytree included original maintained Vitest generated local cache; no candidate test ran','preservedCache':'staging-r1-carried-cache','resolution':'relocated this exact own generated cache; source assertions unchanged'},indent=2)+'\n')
m=json.loads((R/'evidence/original-source-manifest.json').read_text())['files'];p=json.loads((R/'candidate-input-r1.json').read_text());entries=[]
for q in sorted(S.rglob('*')):
 if q.is_file():
  b=q.read_bytes();entries.append({'path':str(q.relative_to(S)),'bytes':len(b),'sha256':sha(b),'gitBlob':git(b)})
assert len(entries)==52
deltas=[e['path'] for e in entries if e['path'] not in {x['path'] for x in m} or e['sha256']!=next(x['sha256'] for x in m if x['path']==e['path'])]
assert set(deltas)==set(p['files'])
for name,content in p['files'].items():assert (S/name).read_bytes()==content.encode()
for e in m:assert sha((R/'original'/e['path']).read_bytes())==e['sha256']
for name,rows in [('source-manifest.json',entries),('runtime-manifest.json',[e for e in entries if not e['path'].startswith('tests/')])]:
 (E/name).write_text(json.dumps({'base':p['base'],'files':rows},indent=2)+'\n')
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(entries),'deltas':deltas,'original46Exact':True,'unexpectedRuntimeFiles':[]}
(E/'source-freeze.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
