import { afterEach, expect, test, vi } from 'vitest';
import { validateOrderFields } from '../original/src/order-admission';
import { load, save } from '../original/src/store';
const draft = { merchant: 'Receipt <&> 東京', orderNo: "A'42", total: '2750 JPY', orderDate: '2026-10-09', windowDays: '30' };
afterEach(() => vi.unstubAllGlobals());
for (const [date, days, due] of [['2026-10-09','30','2026-11-08'],['2024-02-28','2','2024-03-01'],['2024-02-29','1','2024-03-01'],['2026-01-31','1','2026-02-01']]) {
 test('fixed original calendar '+date+'+'+days, () => expect(validateOrderFields({...draft,orderDate:date,windowDays:days})).toEqual({days:Number(days),due}));
}
for (const days of ['','0','-1','1.5','Infinity','1e2','3700001']) test('original rejects window '+JSON.stringify(days),()=>expect(()=>validateOrderFields({...draft,windowDays:days})).toThrow());
test('original rejects invalid civil day',()=>expect(()=>validateOrderFields({...draft,orderDate:'2026-02-30'})).toThrow());
test('original rejects field4097',()=>expect(()=>validateOrderFields({...draft,merchant:'x'.repeat(4097)})).toThrow());
const order = {id:'ORIGINAL',merchant:'Original',orderDate:'2026-01-01',windowDays:30,windowSource:'user',createdAt:'2026-01-01T00:00:00.000Z',extension:{keep:['literal',7]}};
test('original load and save retain exact row order and extension fields',()=>{
 const current=[order,{...order,id:'REMOTE',orderNo:'second'}];let raw=JSON.stringify(current);let writes=0;
 vi.stubGlobal('localStorage',{getItem:()=>raw,setItem:(_k:string,v:string)=>{raw=v;writes++;}});
 const fresh=load();expect(fresh).toEqual(current);save([...fresh,{...order,id:'NEW'}]);
 expect(JSON.parse(raw).slice(0,2)).toEqual(current);expect(writes).toBe(1);
});
for(const raw of ['{bad','{}','[null]','[{"id":"partial"}]']) test('original refuses malformed collection '+raw,()=>{
 let writes=0;vi.stubGlobal('localStorage',{getItem:()=>raw,setItem:()=>writes++});expect(()=>load()).toThrow();expect(writes).toBe(0);
});
test('original read error propagates',()=>{vi.stubGlobal('localStorage',{getItem:()=>{throw Error('READ_REFUSED');}});expect(()=>load()).toThrow('READ_REFUSED');});
test('original write error propagates without mutation',()=>{const raw=JSON.stringify([order]);vi.stubGlobal('localStorage',{getItem:()=>raw,setItem:()=>{throw Error('WRITE_REFUSED');}});expect(()=>save([])).toThrow('WRITE_REFUSED');expect(load()).toEqual([order]);});
