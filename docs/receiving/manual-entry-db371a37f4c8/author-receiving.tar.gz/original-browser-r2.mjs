import { chromium } from '/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root=process.argv[2], out=process.argv[3];
const requests=[], checks=[], downloads=[], errors=[];
const record=(name,actual)=>{checks.push({name,actual});return actual;};
const server=createServer(async(req,res)=>{
 try {
  const url=new URL(req.url,'http://local');let path=decodeURIComponent(url.pathname);
  if(!path.startsWith('/returnby/')){res.writeHead(404);res.end();return;}
  path=path.slice('/returnby/'.length)||'index.html';
  const file=resolve(root,path);if(!file.startsWith(resolve(root)+'/'))throw Error('outside');
  const b=await readFile(file);requests.push({path:url.pathname,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')});
  res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml'})[extname(file)]||'application/octet-stream');res.end(b);
 } catch {res.writeHead(404);res.end();}
});
let browser,context;let receipt={started:new Date().toISOString(),checks,requests,downloads,errors};
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port+'/returnby/';
try {
 browser=await chromium.launch({executablePath:'/snap/bin/chromium',headless:true,timeout:45000});
 context=await browser.newContext({viewport:{width:1280,height:900},timezoneId:'UTC'});
 await context.addInitScript(()=>{
  window.__writes=[];const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){window.__writes.push({key:k,value:v});return set.call(this,k,v);};
 });
 const page=await context.newPage();page.on('download',d=>downloads.push(d.suggestedFilename()));page.on('pageerror',e=>errors.push(String(e)));
 await page.goto(base,{waitUntil:'networkidle',timeout:20000});
 assert.equal(await page.locator('#preview').isVisible(),false);
 assert.equal(await page.evaluate(()=>localStorage.getItem('returnby.v1')),null);
 assert.deepEqual(await page.evaluate(()=>window.__writes),[]);
 record('opening does not save or expose a manual-only page',true);
 await page.locator('#find').click();
 assert.equal(await page.locator('#preview').isVisible(),true);
 assert.equal(await page.locator('#preview [name=windowDays]').inputValue(),'30');
 assert.match(await page.locator('#src').innerText(),/fallback/);
 assert.equal(await page.locator('#preview [name=merchant]').inputValue(),'');
 assert.equal(await page.locator('#preview [name=orderDate]').inputValue(),'');
 record('blank Find exposes editable fields and30-day fallback',await page.locator('#preview').innerText());
 await page.locator('#paste').fill('A paper receipt with no recognized fields <&> 東京');
 await page.locator('#find').click();
 assert.equal(await page.locator('#preview [name=windowDays]').inputValue(),'30');
 assert.match(await page.locator('#src').innerText(),/fallback/);
 assert.deepEqual(await page.evaluate(()=>window.__writes),[]);
 assert.equal(await page.evaluate(()=>localStorage.getItem('returnby.v1')),null);
 assert.deepEqual(downloads,[]);assert.deepEqual(errors,[]);
 record('unparseable Find is editable without persistence or downloads',true);
 await page.screenshot({path:out+'/original-unparseable-desktop.png',fullPage:true});
 receipt.pass=true;receipt.base=base;
} catch(e){receipt.pass=false;receipt.error=String(e.stack||e);process.exitCode=1;}
finally{
 if(context)await context.close();
 if(browser)await browser.close();
 await new Promise(r=>server.close(r));
 receipt.finished=new Date().toISOString();receipt.browserClosed=true;receipt.serverClosed=true;
 await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
}
