import { chromium } from '/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root=process.argv[2],out=process.argv[3];
const requests=[],checks=[],downloads=[],errors=[],images=[];
const sha=b=>createHash('sha256').update(b).digest('hex');
const receipt={started:new Date().toISOString(),checks,requests,downloads,errors,images};
async function checkpoint(name,details){checks.push({name,details});await writeFile(out+'/progress.json',JSON.stringify(receipt,null,2)+'\n');}
const server=createServer(async(req,res)=>{
 try {
  const url=new URL(req.url,'http://local');let path=decodeURIComponent(url.pathname);
  if(!path.startsWith('/returnby/')){res.writeHead(404);res.end();return;}
  path=path.slice('/returnby/'.length)||'index.html';
  const file=resolve(root,path);if(!file.startsWith(resolve(root)+'/'))throw Error('outside');
  const b=await readFile(file);requests.push({path:url.pathname,bytes:b.length,sha256:sha(b)});
  res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml'})[extname(file)]||'application/octet-stream');res.end(b);
 }catch{res.writeHead(404);res.end();}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port+'/returnby/';
let browser;const contexts=[];
const original={id:'ORIGINAL',merchant:'Original store',orderNo:'OLD',orderDate:'2026-01-01',windowDays:30,windowSource:'policy',createdAt:'2026-01-01T00:00:00.000Z',extension:{keep:['literal',7]}};
const draft={merchant:'Receipt <&> 東京',orderNo:"A'42",total:'2750 JPY',orderDate:'2026-10-09',windowDays:'30'};
const ids={merchant:'manual-merchant',orderNo:'manual-order-no',total:'manual-total',orderDate:'manual-date',windowDays:'manual-days'};
async function context(seed=[],phone=false){
 const c=await browser.newContext({viewport:phone?{width:390,height:844}:{width:1280,height:900},timezoneId:'UTC',isMobile:phone,hasTouch:phone});contexts.push(c);
 await c.addInitScript(seed=>{
  if(location.protocol!=='http:')return;
  const get=Storage.prototype.getItem,set=Storage.prototype.setItem;
  if(get.call(localStorage,'returnby.v1')===null&&seed.length)set.call(localStorage,'returnby.v1',JSON.stringify(seed));
  window.__writes=[];window.__refuseRead=false;window.__refuseWrite=false;window.__afterWrite=false;
  window.__rawGet=()=>get.call(localStorage,'returnby.v1');
  window.__rawSet=v=>set.call(localStorage,'returnby.v1',v);
  Storage.prototype.getItem=function(k){if(k==='returnby.v1'&&window.__refuseRead)throw Error('READ_REFUSED');return get.call(this,k);};
  Storage.prototype.setItem=function(k,v){
   if(k==='returnby.v1'){
    window.__writes.push({key:k,value:v});
    if(window.__refuseWrite)throw Error('WRITE_REFUSED');
    set.call(this,k,v);
    if(window.__afterWrite){window.__afterWrite=false;throw Error('AFTER_WRITE');}
   }else set.call(this,k,v);
  };
 },seed);
 c.on('page',p=>{p.on('download',d=>downloads.push(d.suggestedFilename()));p.on('pageerror',e=>errors.push(String(e)));});
 return c;
}
async function go(c,path='manual-entry.html'){
 const p=await c.newPage();await p.goto(base+path,{waitUntil:'networkidle',timeout:15000});return p;
}
async function fill(p,values=draft){for(const [key,value] of Object.entries(values))await p.locator('#'+ids[key]).fill(value);}
async function review(p){await p.getByRole('button',{name:'Review deadline',exact:true}).click();assert.equal(await p.locator('#manual-review').isVisible(),true);}
async function rows(p){return JSON.parse(await p.evaluate(()=>window.__rawGet())||'[]');}
async function writes(p){return p.evaluate(()=>window.__writes);}
async function snap(p){return p.evaluate(()=>({fields:[...document.querySelectorAll('#manual-form input')].map(x=>[x.name,x.value]),review:document.querySelector('#manual-review').textContent,visible:!document.querySelector('#manual-review').hidden}));}
async function capture(p,name){const file=out+'/'+name;await p.screenshot({path:file,fullPage:true});const b=await readFile(file);images.push({name,bytes:b.length,sha256:sha(b)});}
try{
 browser=await chromium.launch({executablePath:'/snap/bin/chromium',headless:true,timeout:45000});
 const c=await context([original,{...original,id:'REMOVED'}]);const p=await go(c,'index.html');
 await p.getByRole('link',{name:'Enter a receipt manually',exact:true}).click();
 assert.match(p.url(),/\/returnby\/manual-entry.html$/);
 assert.equal(await p.locator('#manual-date').inputValue(),'');assert.equal(await p.locator('#manual-days').inputValue(),'');
 assert.deepEqual(await writes(p),[]);assert.equal(await p.locator('#manual-review').isVisible(),false);
 await fill(p);await review(p);
 assert.equal(await p.locator('#review-merchant').innerText(),draft.merchant);assert.equal(await p.locator('#review-orderNo').innerText(),draft.orderNo);
 assert.equal(await p.locator('#review-total').innerText(),draft.total);assert.equal(await p.locator('#review-due').innerText(),'2026-11-08');
 assert.deepEqual(await writes(p),[]);assert.deepEqual(downloads,[]);
 await checkpoint('explicit linked route, blank required inputs and literal preview without save/download',{draft,due:'2026-11-08'});
 await p.locator('#manual-total').fill('2751 JPY');
 assert.equal(await p.locator('#manual-review').isVisible(),false);assert.equal(await p.locator('#manual-save').isDisabled(),true);
 await p.locator('#manual-total').fill('2750 JPY');await review(p);
 await p.evaluate(()=>{document.querySelector('#manual-order-no').value='Changed without input event';});
 await p.locator('#manual-save').click();assert.equal(await p.locator('#manual-review').isVisible(),false);assert.deepEqual(await writes(p),[]);
 await p.locator('#manual-order-no').fill(draft.orderNo);await review(p);
 await checkpoint('both ordinary edits and programmatic later values retire stale review',true);
 await capture(p,'desktop-reviewed-receipt.png');
 const other=await go(c,'index.html');
 const latest=[{...original,merchant:'Corrected in second tab',extension:{keep:['later',9]}},{...original,id:'REMOTE',orderNo:'ADDED'}];
 await other.evaluate(v=>localStorage.setItem('returnby.v1',JSON.stringify(v)),latest);
 await p.locator('#manual-save').dblclick({delay:35});
 const saved=await rows(p);assert.deepEqual(saved.slice(0,2),latest);assert.equal(saved.length,3);
 const own=saved[2];assert.match(own.id,/^[0-9a-f-]{36}$/);assert.ok(Number.isFinite(Date.parse(own.createdAt)));
 assert.deepEqual({...own,id:'observed',createdAt:'observed'},{id:'observed',createdAt:'observed',merchant:draft.merchant,orderNo:draft.orderNo,total:draft.total,orderDate:draft.orderDate,windowDays:30,windowSource:'user'});
 assert.equal((await writes(p)).length,1);assert.equal(await p.locator('#manual-save').isDisabled(),true);
 assert.deepEqual(downloads,[]);
 await checkpoint('fresh actual second-tab edit/add/remove preserved; double-click writes one user-labelled identity',{latest,saved:own,writes:(await writes(p)).length});
 await p.getByRole('link',{name:'View tracker',exact:true}).click();
 assert.equal(await p.locator('#list .card').filter({hasText:draft.merchant}).count(),1);
 assert.match(await p.locator('#list .card').filter({hasText:draft.merchant}).innerText(),/YOUR RULE \/ 30 DAYS/);
 await p.locator('details').evaluate(e=>{e.open=true;});
 const downloadPromise=p.waitForEvent('download');await p.locator('#backup-export').click();const dl=await downloadPromise;await dl.saveAs(out+'/explicit-backup.json');
 const backup=JSON.parse(await readFile(out+'/explicit-backup.json','utf8'));assert.equal(backup.schema,'returnby.backup');assert.deepEqual(backup.orders.find(o=>o.id===own.id),own);
 await checkpoint('ordinary tracker and explicit real backup download accept the manual record',{backupOrders:backup.orders.length,download:dl.suggestedFilename()});
 await c.close();
 const c2=await context([original]);const q=await go(c2);await fill(q);await review(q);const before=await snap(q);
 await q.evaluate(()=>{window.__refuseRead=true;});await q.locator('#manual-save').click();
 assert.match(await q.locator('#manual-message').innerText(),/Could not read/);assert.deepEqual(await snap(q),before);assert.deepEqual(await writes(q),[]);
 await q.evaluate(()=>{window.__refuseRead=false;window.__rawSet('{bad');});await q.locator('#manual-save').click();
 assert.deepEqual(await snap(q),before);assert.deepEqual(await writes(q),[]);assert.equal(await q.evaluate(()=>window.__rawGet()),'{bad');
 await q.evaluate(v=>{window.__rawSet(JSON.stringify(v));window.__refuseWrite=true;},[original]);await q.locator('#manual-save').click();
 assert.match(await q.locator('#manual-message').innerText(),/Could not save/);assert.deepEqual(await snap(q),before);assert.deepEqual(await rows(q),[original]);
 const remote2=await go(c2,'index.html');const latest2=[{...original,total:'new total',extension:{keep:'after refusal'}},{...original,id:'AFTER_REFUSAL'}];
 await remote2.evaluate(v=>localStorage.setItem('returnby.v1',JSON.stringify(v)),latest2);await q.evaluate(()=>{window.__refuseWrite=false;});await q.locator('#manual-save').click();
 assert.deepEqual((await rows(q)).slice(0,2),latest2);assert.equal((await rows(q)).length,3);
 await checkpoint('read error, malformed JSON and write error preserve exact draft/review; retry freshly retains later second-tab changes',true);
 await c2.close();
 const c3=await context();const u=await go(c3);await fill(u);await review(u);await u.evaluate(()=>{window.__afterWrite=true;});await u.locator('#manual-save').click();
 assert.match(await u.locator('#manual-message').innerText(),/Could not save/);const uncertain=await rows(u);assert.equal(uncertain.length,1);
 await u.locator('#manual-save').click();assert.deepEqual(await rows(u),uncertain);assert.equal((await writes(u)).length,1);assert.equal(await u.locator('#manual-save').isDisabled(),true);
 await checkpoint('write-took-effect-then-error retry recognizes exact persisted identity without a duplicate write',{id:uncertain[0].id,writes:1});
 await u.locator('#manual-another').click();assert.equal(await u.locator('#manual-days').inputValue(),'');assert.equal(await u.locator('#manual-date').inputValue(),'');
 assert.equal(await u.locator('#manual-review').isVisible(),false);assert.deepEqual(await rows(u),uncertain);
 await fill(u,{...draft,merchant:'Amazon'});await review(u);await u.evaluate(()=>{window.__afterWrite=true;});await u.locator('#manual-save').click();let colliding=await rows(u);
 const attempted=colliding.at(-1);colliding.push({...attempted});await u.evaluate(v=>window.__rawSet(JSON.stringify(v)),colliding);
 const count=(await writes(u)).length;await u.locator('#manual-save').click();assert.match(await u.locator('#manual-message').innerText(),/more than once/);assert.deepEqual(await rows(u),colliding);assert.equal((await writes(u)).length,count);
 colliding=colliding.slice(0,-1);colliding[colliding.length-1].total='Different saved record';await u.evaluate(v=>window.__rawSet(JSON.stringify(v)),colliding);await u.locator('#manual-save').click();
 assert.match(await u.locator('#manual-message').innerText(),/different/);assert.deepEqual(await rows(u),colliding);
 await checkpoint('explicit Add another clears only form; duplicate/different identity collision refuses overwrite',true);await c3.close();
 const cp=await context([],true);const phone=await go(cp);await phone.reload({waitUntil:'networkidle'});assert.deepEqual(await writes(phone),[]);
 await fill(phone,{...draft,merchant:'Amazon <&> 東京 🧾',orderDate:'2024-02-28',windowDays:'1.5'});await phone.getByRole('button',{name:'Review deadline',exact:true}).tap();
 assert.equal(await phone.locator('#manual-review').isVisible(),false);assert.equal(await phone.locator('#manual-days').inputValue(),'1.5');assert.deepEqual(await writes(phone),[]);
 await phone.locator('#manual-days').fill('2');await phone.getByRole('button',{name:'Review deadline',exact:true}).tap();assert.equal(await phone.locator('#review-due').innerText(),'2024-03-01');
 assert.equal(await phone.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 await capture(phone,'phone-reviewed-receipt.png');await phone.locator('#manual-save').tap();
 assert.equal((await rows(phone))[0].windowSource,'user');assert.equal(await phone.locator('#manual-success').isVisible(),true);
 assert.equal(await phone.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);await capture(phone,'phone-saved-receipt.png');
 await checkpoint('direct built subpath/reload, phone touch, invalid window retention, leap date and unclipped literal review',true);await cp.close();
 const ck=await context();const key=await go(ck);await fill(key,{...draft,merchant:'Amazon'});
 await key.locator('#manual-days').focus();await key.keyboard.press('Enter');
 assert.equal(await key.evaluate(()=>document.activeElement.id),'manual-review-title');await key.keyboard.press('Tab');
 assert.equal(await key.evaluate(()=>document.activeElement.id),'manual-save');await key.keyboard.press('Space');
 assert.equal((await rows(key)).length,1);assert.equal((await rows(key))[0].windowSource,'user');await key.keyboard.press('Enter');assert.equal((await rows(key)).length,1);
 await checkpoint('keyboard Enter reviews, Tab reaches Save, Space saves known merchant as user and repeat Enter cannot duplicate',true);await ck.close();
 assert.deepEqual(errors,[]);assert.equal(downloads.length,1);receipt.pass=true;
}catch(e){receipt.pass=false;receipt.error=String(e.stack||e);process.exitCode=1;}
finally{
 for(const c of contexts)await c.close().catch(()=>{});
 if(browser)await browser.close();
 await new Promise(r=>server.close(r));
 receipt.finished=new Date().toISOString();receipt.browserClosed=true;receipt.serverClosed=true;
 await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
}
