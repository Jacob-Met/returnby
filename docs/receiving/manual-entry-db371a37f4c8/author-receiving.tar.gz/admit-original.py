import pathlib,os,json,hashlib,shutil,datetime,stat
R=pathlib.Path('/run/user/1000/snap.chromium/hamon-returnby-manual-db371a37f4c8')
D=pathlib.Path('/home/jacob/returnby-batch-c77045b4/source/node_modules')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def entry(p,base):
 q=str(p.relative_to(base))
 if p.is_symlink():
  assert p.resolve().is_relative_to(base.resolve()),q
  return {'path':q,'type':'symlink','target':os.readlink(p)}
 assert p.is_file(),q
 b=p.read_bytes();return {'path':q,'type':'file','bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
f=os.statvfs(R);m=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert f.f_bavail*f.f_frsize>=256*1024**2 and m>=2*1024**3
P=json.loads((R/'input-packet.json').read_text()); assert len(P['files'])==46
original=R/'original';assert not original.exists();original.mkdir()
manifest=[]
for e in P['files']:
 b=e['content'].encode();assert len(b)==e['size'] and git(b)==e['sha'],e['path']
 p=original/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 manifest.append({'path':e['path'],'bytes':len(b),'gitBlob':git(b),'sha256':sha(b)})
E=R/'evidence';E.mkdir()
root=P['rootContract'];b=root['content'].encode();assert git(b)==root['gitBlob'];(E/'ROOT-CONTRACT.md').write_bytes(b)
(E/'CONTRACT.md').write_text(P['authorContract'])
write(E/'original-source-manifest.json',{'repository':P['repository'],'commit':P['commit'],'tree':'96bb753431587f74eec2e3eefbb2198cb85d8f5e','files':manifest})
write(E/'full-original-tree.json',P['fullTree'])
lock=json.loads((original/'package-lock.json').read_text());installed=json.loads((D/'.package-lock.json').read_text());checks=[]
for p,e in installed['packages'].items():
 if not p:continue
 c=lock['packages'][p]
 assert all(e.get(k)==c.get(k) for k in ('version','resolved','integrity')),p
 checks.append({'path':p,'version':e.get('version'),'exact':True})
paths=[]
for base,ds,fs in os.walk(D,followlinks=False):
 if pathlib.Path(base)==D:ds[:]=[x for x in ds if x not in ('.vite','.vite-temp')]
 for n in sorted(fs):paths.append(pathlib.Path(base)/n)
before=sorted([entry(p,D) for p in paths],key=lambda e:e['path'])
N=R/'node_modules';assert not N.exists();N.mkdir()
for e in before:
 s=D/e['path'];d=N/e['path'];d.parent.mkdir(parents=True,exist_ok=True)
 if e['type']=='symlink':d.symlink_to(e['target'])
 else:shutil.copy2(s,d)
after=sorted([entry(D/e['path'],D) for e in before],key=lambda e:e['path'])
copied=sorted([entry(N/e['path'],N) for e in before],key=lambda e:e['path'])
assert before==after==copied
write(E/'donor-manifest.json',{'donor':str(D),'exclusions':['.vite','.vite-temp'],'installedLockChecks':checks,'files':before,'copied':str(N),'allSourceAndCopyExact':True})
receipt={'at':stamp(),'sourceFiles':len(manifest),'sourceBytes':sum(e['bytes'] for e in manifest),'originalExact':True,'contract':{'sha256':sha((E/'CONTRACT.md').read_bytes()),'bytes':(E/'CONTRACT.md').stat().st_size},'rootContract':{'gitBlob':root['gitBlob'],'sha256':sha(b),'bytes':len(b)},'donorFiles':len(before),'donorBytes':sum(e.get('bytes',0) for e in before),'installedPackageChecks':len(checks),'copyExact':True,'freeAfter':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,'candidateWritten':False}
write(E/'original-admission-r1.json',receipt);print(json.dumps(receipt))
