import pathlib,json,hashlib,os,datetime,stat
R=pathlib.Path('/run/user/1000/snap.chromium/hamon-returnby-manual-db371a37f4c8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(base,manifest):
 return [e['path'] for e in manifest if sha(base/e['path'])!=e['sha256']]
original=json.loads((R/'evidence/original-source-manifest.json').read_text())['files']
candidate=json.loads((R/'evidence/candidate-r1/source-manifest.json').read_text())['files']
d=json.loads((R/'evidence/donor-manifest.json').read_text())
errors=[]
for base in [pathlib.Path(d['donor']),pathlib.Path(d['copied'])]:
 for e in d['files']:
  p=base/e['path']
  if e['type']=='symlink':
   if not p.is_symlink() or os.readlink(p)!=e['target']:errors.append(str(p))
  elif sha(p)!=e['sha256'] or stat.S_IMODE(p.stat().st_mode)!=e['mode']:errors.append(str(p))
native=json.loads((R/'evidence/candidate-native-r1/receipt.json').read_text())
ownPids=[4035818,4043761,4063883,4063951,4064254,4064385,4064999,4078840,4084717,4117757,4124259,4129130]+[e['pid'] for e in native['commands']]+[4163765]
for run in ['original-browser-r1','original-browser-r2','candidate-browser-r1']:
 w=json.loads((R/'evidence'/run/'wrapper.json').read_text())
 ownPids += [int(x) for x in w['observed']]
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalMismatches':check(R/'original',original),'candidateMismatches':check(R/'source',candidate),'donorAndCopyMismatches':errors,'knownOwnPidsStillPresent':[p for p in sorted(set(ownPids)) if pathlib.Path('/proc/'+str(p)).exists()],'profilesAbsent':{run:not (R/'evidence'/run/'tmp').exists() for run in ['original-browser-r1','original-browser-r2','candidate-browser-r1']},'rootReceivingExcluded':'reserved root-receiving is never read or archived; root browser may currently be active','mainSharedSourceExact':all(next(x['sha256'] for x in candidate if x['path']==name)==next(x['sha256'] for x in original if x['path']==name) for name in ['src/main.ts','src/store.ts','src/order-admission.ts','src/deadline.ts','src/parse.ts','src/policy.ts','src/backup.ts','src/ics.ts']),'free':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize}
(R/'evidence/author-final-audit-r1.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
