import pathlib,os,json,hashlib,subprocess,time,datetime,signal,sys
R=pathlib.Path(__file__).resolve().parent; O=R/'original'; E=R/'evidence'/'original-native-r1'; E.mkdir()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 m=json.loads((R/'evidence/original-source-manifest.json').read_text())['files']
 return [e['path'] for e in m if sha(O/e['path'])!=e['sha256']]
assert not check()
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert free>=256*1024**2 and mem>=2*1024**3
commands=[
 ['tsc',['/usr/bin/node',str(R/'node_modules/typescript/bin/tsc'),'--noEmit'],O],
 ['build',['/usr/bin/node',str(R/'node_modules/vite/bin/vite.js'),'build','--outDir',str(E/'dist')],O],
 ['maintained',['/usr/bin/node',str(R/'node_modules/vitest/vitest.mjs'),'run','--reporter=json','--outputFile='+str(E/'maintained.json')],O],
 ['oracle',['/usr/bin/node',str(R/'node_modules/vitest/vitest.mjs'),'run','original-oracle.test.ts','--root',str(R/'evidence'),'--reporter=json','--outputFile='+str(E/'oracle.json')],R/'evidence']]
receipt={'started':stamp(),'guard':{'free':free,'memory':mem},'commands':[]}
env={**os.environ,'TZ':'UTC','TMPDIR':str(R/'tmp'),'XDG_CACHE_HOME':str(R/'cache'),'CI':'1'};(R/'tmp').mkdir();(R/'cache').mkdir()
for name,cmd,cwd in commands:
 t=time.monotonic()
 with (E/(name+'.stdout')).open('wb') as out,(E/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
  timed=False
  try:rc=p.wait(timeout=90)
  except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 row={'name':name,'argv':cmd,'cwd':str(cwd),'pid':p.pid,'exit':rc,'timeout':timed,'seconds':time.monotonic()-t};receipt['commands'].append(row)
 (E/'progress.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if rc:break
receipt.update({'finished':stamp(),'sourceMismatches':check(),'allPass':len(receipt['commands'])==4 and all(e['exit']==0 for e in receipt['commands']) and not check()})
(E/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
