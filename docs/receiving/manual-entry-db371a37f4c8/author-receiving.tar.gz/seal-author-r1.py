import pathlib,json,hashlib,tarfile,gzip,io,datetime,os,shutil,base64
R=pathlib.Path('/run/user/1000/snap.chromium/hamon-returnby-manual-db371a37f4c8');S=R/'seal-r1';assert not S.exists();S.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;assert free>=256*1024**2
files={}
for side,manifest in [('original','original-source-manifest.json'),('source','candidate-r1/source-manifest.json')]:
 for e in json.loads((R/'evidence'/manifest).read_text())['files']:
  p=R/side/e['path'];assert sha(p.read_bytes())==e['sha256'];files[str(p.relative_to(R))]=p
for p in (R/'evidence').rglob('*'):
 if p.is_file() and 'node_modules' not in p.relative_to(R/'evidence').parts:files[str(p.relative_to(R))]=p
for p in R.iterdir():
 if p.is_file() and p.suffix in ('.py','.mjs','.json'):files[p.name]=p
assert not any('root-receiving' in n for n in files)
rows=[{'path':n,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'gitBlob':git(p.read_bytes())} for n,p in sorted(files.items())]
manifest={'version':1,'created':stamp(),'repository':'Jacob-Met/returnby','sourceBase':'bd07785d10ba40e524756b059c3f3cc548927f9f','files':rows,'exclusions':['private dependency binaries (full admitted hashes retained)','generated ordinary tool caches','root-receiving (exclusive peer directory, never inspected)','seal-r1 (external seal metadata)']}
write(S/'author-manifest.json',manifest)
archive=S/'author-receiving.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,p in list(sorted(files.items()))+[('author-manifest.json',S/'author-manifest.json')]:
    b=p.read_bytes();t=tarfile.TarInfo(name);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
expected={e['path']:e for e in rows};expected['author-manifest.json']={'sha256':sha((S/'author-manifest.json').read_bytes()),'bytes':(S/'author-manifest.json').stat().st_size}
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected);assert {t.name for t in members}==set(expected)
 for t in members:
  assert t.isfile() and not pathlib.PurePosixPath(t.name).is_absolute() and '..' not in pathlib.PurePosixPath(t.name).parts
  b=tar.extractfile(t).read();assert len(b)==expected[t.name]['bytes'] and sha(b)==expected[t.name]['sha256']
assert all(sha(files[e['path']].read_bytes())==e['sha256'] for e in rows)
shutil.copyfile(R/'evidence/AUTHOR.md',S/'AUTHOR.md')
prior=json.loads((R/'evidence/author-final-audit-r1.json').read_text())
audit={'sealed':stamp(),'priorActualSourceDependencyProcessAudit':prior,'payloadFiles':len(rows),'logicalArchiveMembers':len(expected),'payloadBytes':sum(e['bytes'] for e in rows),'allMembersExact':True,'allPayloadBeforeAfterExact':True,'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'peerDirectoryExcluded':True}
write(S/'author-final-audit.json',audit)
seal={'version':1,'sealed':stamp(),'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'gitBlob':git(archive.read_bytes())},'manifest':{'name':'author-manifest.json','sha256':sha((S/'author-manifest.json').read_bytes())},'report':{'name':'AUTHOR.md','sha256':sha((S/'AUTHOR.md').read_bytes())},'audit':{'name':'author-final-audit.json','sha256':sha((S/'author-final-audit.json').read_bytes())},'refWritten':False}
write(S/'author-seal.json',seal)
objects=[];(S/'transfer').mkdir()
for name in ['author-receiving.tar.gz','AUTHOR.md','author-manifest.json','author-seal.json','author-final-audit.json']:
 b=(S/name).read_bytes();objects.append({'name':name,'path':'docs/receiving/manual-entry-db371a37f4c8/'+name,'bytes':len(b),'sha256':sha(b),'gitBlob':git(b)})
 encoded=base64.b64encode(b).decode();(S/'transfer'/(name+'.b64')).write_text('\n'.join(encoded[i:i+60000] for i in range(0,len(encoded),60000))+'\n')
write(S/'objects.json',objects);print(json.dumps({'archive':seal['archive'],'objects':objects,'payloadFiles':len(rows),'members':len(expected)}))
