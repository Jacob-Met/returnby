import pathlib,os,json,hashlib,subprocess,time,datetime,signal,shutil
R=pathlib.Path(__file__).resolve().parent;E=R/'evidence/original-browser-r2';E.mkdir();T=E/'tmp';T.mkdir()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def procs():
 out={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   s=(p/'stat').read_text().rsplit(')',1)[1].split();c=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');out[int(p.name)]={'ppid':int(s[1]),'pgrp':int(s[2]),'start':s[19],'cmd':c}
  except (OSError,ValueError):pass
 return out
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert free>=256*1024**2 and mem>=2*1024**3
m=json.loads((R/'evidence/original-source-manifest.json').read_text())['files']
assert all(sha(R/'original'/e['path'])==e['sha256'] for e in m)
cmd=['/usr/bin/node',str(R/'original-browser-r2.mjs'),str(R/'evidence/original-native-r1/dist'),str(E)]
receipt={'started':stamp(),'guard':{'free':free,'memory':mem},'argv':cmd,'driverSha256':sha(R/'original-browser-r2.mjs'),'observed':{},'forced':[]}
env={**os.environ,'TMPDIR':str(T),'XDG_CACHE_HOME':str(R/'cache'),'DEBUG':'pw:browser','TZ':'UTC'}
with (E/'driver.stdout').open('wb') as out,(E/'driver.stderr').open('wb') as err:
 p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err,start_new_session=True);receipt['pid']=p.pid
 known={p.pid};start=time.monotonic()
 while p.poll() is None and time.monotonic()-start<120:
  snap=procs();changed=True
  while changed:
   found={pid for pid,e in snap.items() if e['ppid'] in known};changed=bool(found-known);known|=found
  for pid in known:
   if pid in snap:receipt['observed'][str(pid)]=snap[pid]
  time.sleep(.25)
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);receipt['forced'].append('wrapper deadline groupTERM')
 try:receipt['exit']=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);receipt['forced'].append('groupKILL');receipt['exit']=p.wait()
time.sleep(4);snap=procs()
alive={pid:e for pid,e in snap.items() if str(pid) in receipt['observed'] and e['start']==receipt['observed'][str(pid)]['start']}
receipt['alive']=alive
if not alive:shutil.rmtree(T)
receipt.update({'finished':stamp(),'profileAbsent':not T.exists(),'sourceExact':all(sha(R/'original'/e['path'])==e['sha256'] for e in m)})
(E/'wrapper.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='observed'}))
