# Root independent contract: ReturnBy explicit receipt entry

Frozen 2026-10-09T03:11Z by estate-db371a37f4c8/root before any manual-entry candidate or authored tests are read.

## Original and beneficiary

Repository Jacob-Met/returnby. Current canonical main is recorded separately as 1e662c387be5f66f8499fac7ec443f58d2198379. The selected owner-qualified receiving baseline is commit bd07785d10ba40e524756b059c3f3cc548927f9f, actual commit tree96bb753431587f74eec2e3eefbb2198cb85d8f5e, sole parent PR20 head7829e56e57ef91dfe8edd5853fd68d6c7890fac0. It is not represented as merged main.

Root independently read exact original index.html, src/main.ts, src/store.ts, src/order-admission.ts and src/deadline.ts through pinned repository source. Shared store blobc7333d076f851c4dbad6199eaebd6ca34f4abdb3 propagates failed reads; shared admission blobfcc5ad1761f4d2125549554f1c2835854d5e98c5 validates dates/windows/field lengths; deadline blobbcef920c0f9846b789b1a0aa01b833c7d99ba5d4 uses existing calendar-date arithmetic.

Original Find deadline on blank/unparseable input already exposes editable fields. Manual entry is therefore indirectly possible today. The proposed benefit is a direct receipt/no-email route, explicit user-supplied window and visible derived-deadline review before saving, without implying retailer policy recognition.

Existing #8/#10 integration ownership, accepted store/admission/deadline/main/parser/backup/calendar/lifecycle paths and newer owner contributions remain preserved. Candidate publication is an owner handoff; root does not authorize merging their entire held stack.

## Manually fixed expectations

1. The original app's blank/unparseable Find deadline journey is observed before candidate entry. Its editable fields and policy/default labeling are retained as the baseline, not relabeled as absent. Loading either original page or proposed manual page must not itself write storage or create a calendar download.

2. The manual route accepts reviewed literal metadata and does not require an email/parser/policy match. Fixed example: merchant "Receipt <&> 東京", order number "A'42", total "2750 JPY", order date2026-10-09, user-entered30days. The derived deadline is2026-11-08. Saved windowSource is user even if the merchant/day count happens to match the policy table. Values remain literal text; markup does not execute.

3. Date/window validation uses the unchanged admitted helper. Independent date examples include2024-02-28 +2days =2024-03-01 and2024-02-29 +1day =2024-03-01. Invalid calendar dates, zero/fractional/nonfinite/overflowing windows and overlong fields refuse mutable work and leave the draft correctable. No new retailer rule or clinical/legal return-policy authority is claimed.

4. Preview shows the exact submitted fields, selected window and derived date before any save. Editing a field after preview retires or blocks that stale review until the new values are reviewed. Cancel/review/back actions do not save. A deliberate Save applies only the currently reviewed draft.

5. Save obtains the current accepted-store list immediately before appending. Existing rows retain their order and every known/unknown extension field. A different tab's addition, edit or removal after preview remains reflected in the fresh save input. The helper/store/schema are not replaced or weakened. This is a fresh-read synchronous append contract, not a claim of cross-tab compare-and-swap or database transaction isolation.

6. Failed or malformed reads do not become an empty list; no write follows. Failed writes preserve the draft, review and useful error feedback, with no success/reset/navigation claim. A deliberate retry performs a new read, preserving changes made since the failure, and adds one reviewed order.

7. After a successful Save, the accepted review is retired so a second rapid click/Enter does not append another copy. Reloading the ordinary tracker shows the one saved identity and user label. Generated ID/timestamp are observed runtime values, not invented expected constants.

8. The new entry and return-to-tracker link work in the existing Vite base and built output, including direct page entry/reload. Existing paste/review, backup, calendar and saved-order routes remain intact. No automatic calendar import/download, email, account or network call is introduced.

9. Native consumer qualification must use the admitted existing runtime/dependency bytes, fresh capacity guards and exclusively owned source/output/browser/profile paths. Preserve original source/fixtures/negatives and close owned runtime processes. A source-only or controlled-adapter pass is labeled at its actual level; a browser/UI or storage result is claimed only after actual execution.

Root has not read a candidate or authored tests. Exact additional original fixture/observer choices may be frozen separately before candidate exposure. A later source-review-discovered boundary must remain separately dated, rather than being inserted into this pre-exposure contract.
