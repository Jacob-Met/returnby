import pathlib,json,hashlib,subprocess,datetime,os
R=pathlib.Path(__file__).resolve().parent;P=R.parent;S=R/'candidate-r1'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
ad=json.loads((R/'RUNTIME-ADMISSION-r1.json').read_text());assert all(pin(S/rel)==v for rel,v in ad['files'].items())
C=R/'vite-config-native-r2.mjs'
with C.open('xb') as f:f.write((S/'vite.config.ts').read_bytes())
assert C.read_bytes()==(S/'vite.config.ts').read_bytes()
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert free>=256*1024**2 and mem>=2*1024**3
cmd=['/usr/bin/node',str(P/'node_modules/vite/bin/vite.js'),'build','--configLoader','native','--config',str(C),'--outDir',str(R/'candidate-build-r2')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(cmd,cwd=S,env={**os.environ,'TMPDIR':str(R),'XDG_CACHE_HOME':str(R/'build-cache-r2'),'TZ':'UTC','CI':'1'},capture_output=True,text=True,timeout=45)
result={'schema':'returnby-root-build-v1','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard':{'free':free,'memory':mem},'argv':cmd,'cwd':str(S),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'sourceExact':all(pin(S/rel)==v for rel,v in ad['files'].items()),'configAdapter':{'path':str(C),'pin':pin(C),'bytesExactOriginalTypeScriptConfig':True,'reason':'Native loader in installed Node22 rejected .ts before any compilation; exact JS-compatible config bytes re-exposed as .mjs for native import; no product config changes.'},'built':{str(f.relative_to(R/'candidate-build-r2')):pin(f) for f in sorted((R/'candidate-build-r2').rglob('*')) if f.is_file()}}
with (R/'BUILD-r2.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='built'}));print(json.dumps({'builtCount':len(result['built']),'receipt':pin(R/'BUILD-r2.json')}))
raise SystemExit(p.returncode)
