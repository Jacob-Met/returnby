"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.save = exports.load = exports.read = void 0;
const KEY = 'returnby.v1';
const isOrder = (value) => {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const o = value;
    return ['id', 'merchant', 'orderDate', 'createdAt'].every((key) => typeof o[key] === 'string')
        && typeof o.windowDays === 'number' && Number.isFinite(o.windowDays)
        && (o.windowSource === 'policy' || o.windowSource === 'default' || o.windowSource === 'user')
        && (o.orderNo === undefined || typeof o.orderNo === 'string')
        && (o.total === undefined || typeof o.total === 'string');
};
// Backup/restore must distinguish unreadable storage from an empty tracker.
const read = () => {
    const raw = localStorage.getItem(KEY);
    return raw === null ? [] : JSON.parse(raw);
};
exports.read = read;
const load = () => {
    const raw = localStorage.getItem(KEY);
    if (raw === null)
        return [];
    const orders = JSON.parse(raw);
    if (!Array.isArray(orders) || !orders.every(isOrder))
        throw new Error('Saved returns have an unsupported format');
    return orders;
};
exports.load = load;
const save = (o) => localStorage.setItem(KEY, JSON.stringify(o));
exports.save = save;
