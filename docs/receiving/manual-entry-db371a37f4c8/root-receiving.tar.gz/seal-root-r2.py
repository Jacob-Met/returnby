import pathlib,json,hashlib,datetime,tarfile,zipfile,io,base64,os
R=pathlib.Path(__file__).resolve().parent;P=R.parent;O=R/'publication-r2';O.mkdir()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def bp(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
def pin(p):return bp(p.read_bytes())
def save(name,obj):
 with (O/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def census():
 found={}
 for q in pathlib.Path('/proc').iterdir():
  if not q.name.isdigit():continue
  try:
   cmd=(q/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   names=[pathlib.PurePath(v.decode(errors='replace')).name for v in (q/'cmdline').read_bytes().split(b'\0') if v]
   if str(R) in cmd and (any(n.startswith('browser-runner-') or n.startswith('run-browser-') for n in names) or (names and names[0] in ['chromium','chrome','chrome_crashpad_handler'])):found[q.name]=cmd
  except OSError:pass
 return found
A=P/'seal-r1';arc=A/'author-receiving.tar.gz';assert pin(arc)['sha256']=='124872603b961bd2ef2f30639f42c3a4cb2eb7ae5352e32667555c2e5d9ffd84';assert pin(arc)['gitBlob']=='a4135fd098527ab7abe07b06459a9d6c0ead195d'
am=json.loads((A/'author-manifest.json').read_text());lookup={e['path']:e for e in am['files']}
with tarfile.open(arc,'r:gz') as t:
 members=t.getmembers();assert all(m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts for m in members)
 assert len({m.name for m in members})==len(members)==190
 assert set(lookup).issubset({m.name for m in members})
 extra=set(m.name for m in members)-set(lookup);assert len(extra)==1
 assert json.loads(t.extractfile(next(iter(extra))).read())==am
 for rel,e in lookup.items():
  b=t.extractfile(rel).read();assert bp(b)=={k:e[k] for k in ['bytes','sha256','gitBlob']},rel
  assert b==(P/rel).read_bytes(),rel
authorAdmission={'verified':now(),'archive':pin(arc),'members':190,'payloads':189,'allMemberBytesAndNativeFilesExact':True,'manifest':pin(A/'author-manifest.json')}
save('author-archive-admission.json',authorAdmission)
ad=json.loads((R/'RUNTIME-ADMISSION-r1.json').read_text())
assert all(pin(R/'candidate-r1'/rel)==v and pin(P/'source'/rel)==v for rel,v in ad['files'].items())
build=json.loads((R/'BUILD-r2.json').read_text());D=R/'candidate-build-r2';assert len(build['built'])==9
for rel,e in build['built'].items():assert pin(D/rel)==e
previewManifest={'schema':'returnby-qualified-preview-v1','sourceCommit':'d153659d1f561e1c316a1f9278b3d0b32c222c2f','sourceTree':'c22fdac96a2d4219bb1a0b8b350b1f6c60d7d8db','parent':'bd07785d10ba40e524756b059c3f3cc548927f9f','buildReceipt':pin(R/'BUILD-r2.json'),'files':build['built'],'receiving':['9010a9a43f6d0b7cb0c532a883e9715d2af351a8fbc12bfd4665a817d7732ead','c5967b39c8c9969c028aad41415e1f94a4552ae469d1595cde4608f2956c2d14','fbaa23a9ae5173e39dfa733684c0ec5e175376d20fb9e1499a7f95e96be9ac88'],'use':'Extract all files together; serve through an existing permitted local static route. Open index.html or manual-entry.html. Keep this qualified owner-baseline preview separate from newer installed owner generations.'}
with zipfile.ZipFile(O/'qualified-preview.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in sorted(build['built']):z.writestr(rel,(D/rel).read_bytes())
 z.writestr('BUILD-MANIFEST.json',json.dumps(previewManifest,indent=2)+'\n')
with zipfile.ZipFile(O/'qualified-preview.zip') as z:
 assert len(z.namelist())==10 and set(z.namelist())==set(build['built'])|{'BUILD-MANIFEST.json'}
 for rel in build['built']:assert z.read(rel)==(D/rel).read_bytes()
 assert json.loads(z.read('BUILD-MANIFEST.json'))==previewManifest
save('preview-seal.json',{'verified':now(),'archive':pin(O/'qualified-preview.zip'),'staticFiles':9,'members':10,'allNativeBuildBytesExact':True,'sourceCommit':previewManifest['sourceCommit'],'manifest':previewManifest})
for name in ['ROOT.md','README.md']:
 with (O/name).open('xb') as f:f.write((R/name).read_bytes())
wrappers={}
for name in ['original-browser-r1','candidate-browser-r1','candidate-browser-r2','candidate-browser-r3']:
 w=json.loads((R/name/'wrapper.json').read_text())
 assert w['alive']=={} and w['profileAbsent'] and w['cacheAbsent'] and w['servedExact'] and w['forced']==[]
 wrappers[name]={'receipt':pin(R/name/'receipt.json'),'wrapper':pin(R/name/'wrapper.json'),'exit':w['exit'],'finished':w['finished']}
assert [wrappers[n]['exit'] for n in wrappers]==[0,1,1,0]
active=census();assert active=={},active
final={'schema':'returnby-root-final-audit-v1','verified':now(),'all34CandidateSourceBytesExact':True,'all9BuildFilesExact':True,'browserWrappers':wrappers,'ownedBrowserNamespaceAbsent':True,'sourcePlan':pin(R/'SOURCE-TREE-PLAN.json'),'runtimeAudit':pin(R/'RUNTIME-FINAL-AUDIT-r1.json'),'preview':pin(O/'qualified-preview.zip'),'rootReport':pin(O/'ROOT.md'),'authorArchiveAdmission':authorAdmission}
save('root-final-audit.json',final)
payload={}
for p in sorted(R.rglob('*')):
 if not p.is_file() or O in p.parents:continue
 rel=str(p.relative_to(R));assert '..' not in pathlib.PurePosixPath(rel).parts
 payload[rel]=p.read_bytes()
for name in ['author-archive-admission.json','root-final-audit.json','preview-seal.json']:payload['publication/'+name]=(O/name).read_bytes()
manifest={'schema':'returnby-root-archive-v1','created':now(),'repository':'Jacob-Met/returnby','sourceCommit':previewManifest['sourceCommit'],'files':[{'path':n,**bp(b)} for n,b in sorted(payload.items())],'excluded':['publication-r1 archive/transfer recursion','external dependency and browser binaries','author-owned root except exact archive admission']};save('root-manifest.json',manifest)
with tarfile.open(O/'root-receiving.tar.gz','x:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
 b=(O/'root-manifest.json').read_bytes();info=tarfile.TarInfo('ARCHIVE-MANIFEST.json');info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(O/'root-receiving.tar.gz','r:gz') as t:
 assert len(t.getmembers())==len(payload)+1
 for n,b in payload.items():assert t.extractfile(n).read()==b
 assert json.loads(t.extractfile('ARCHIVE-MANIFEST.json').read())==manifest
for rel,e in build['built'].items():assert pin(D/rel)==e
assert all(pin(R/'candidate-r1'/rel)==v and pin(P/'source'/rel)==v for rel,v in ad['files'].items())
save('root-seal.json',{'sealed':now(),'archive':pin(O/'root-receiving.tar.gz'),'payloads':len(payload),'members':len(payload)+1,'payloadBytes':sum(map(len,payload.values())),'allArchiveMembersRoundTripExact':True,'sourceAndBuiltBytesUnchanged':True,'manifest':pin(O/'root-manifest.json')})
names=['root-receiving.tar.gz','ROOT.md','README.md','root-manifest.json','root-seal.json','root-final-audit.json','qualified-preview.zip','preview-seal.json'];objects={n:pin(O/n) for n in names};save('objects.json',objects)
T=O/'transfer';T.mkdir()
for n in names:
 with (T/(n+'.b64')).open('x',encoding='ascii') as f:f.write(base64.b64encode((O/n).read_bytes()).decode('ascii')+'\n')
print(json.dumps({'objects':objects,'payloads':len(payload),'members':len(payload)+1,'authorMembersExact':190,'finished':now()}))
