import { chromium } from '/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs';
import {createServer} from 'node:http';import {readFile,writeFile} from 'node:fs/promises';import{resolve,extname}from'node:path';import{createHash}from'node:crypto';import assert from'node:assert/strict';
import {installStorageObserver,originalJourney,receiptJourney} from './browser-predicates-r4.mjs';
const [mode,root,out,adapterPath]=process.argv.slice(2), own=resolve(out,'..');
const receipt={schema:'returnby-root-independent-browser-v1',mode,started:new Date().toISOString(),pid:process.pid,checks:[],requests:[],downloads:[],pageErrors:[],externalRequests:[]};
const hash=b=>createHash('sha256').update(b).digest('hex');
receipt.predicatesSha256=hash(await readFile(new URL('./browser-predicates-r4.mjs',import.meta.url)));
const server=createServer(async(req,res)=>{
 try {const url=new URL(req.url,'http://local');if(!url.pathname.startsWith('/returnby/')){res.writeHead(404);res.end();return;}
 const part=decodeURIComponent(url.pathname.slice('/returnby/'.length))||'index.html',file=resolve(root,part);
 if(!file.startsWith(resolve(root)+'/'))throw Error('outside admitted serving root');
 const bytes=await readFile(file);receipt.requests.push({url:url.pathname,bytes:bytes.length,sha256:hash(bytes)});
 res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json'})[extname(file)]||'application/octet-stream');res.end(bytes);
 }catch(e){res.writeHead(404);res.end();}
});
let browser,context;
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port+'/returnby/';
try{
 browser=await chromium.launch({executablePath:'/snap/bin/chromium',headless:true,timeout:45000});
 receipt.browserVersion=browser.version();
 context=await browser.newContext({viewport:{width:1280,height:900},timezoneId:'UTC'});
 await context.addInitScript(installStorageObserver);
 context.on('page',p=>{p.on('download',d=>receipt.downloads.push(d.suggestedFilename()));p.on('pageerror',e=>receipt.pageErrors.push(String(e)));p.on('request',r=>{if(!r.url().startsWith(base)&&!r.url().startsWith('data:'))receipt.externalRequests.push(r.url());});});
 const page=await context.newPage();const record=(name,actual)=>receipt.checks.push({name,actual});
 if(mode==='original')await originalJourney(page,base,record,out);
 else if(mode==='candidate'){
 const ui=JSON.parse(await readFile(adapterPath,'utf8')),oracle=JSON.parse(await readFile(new URL('./ORACLE.json',import.meta.url),'utf8'));
 receipt.adapter={path:adapterPath,sha256:hash(await readFile(adapterPath))};
 await receiptJourney({page,other:await context.newPage(),base,ui,oracle,record,out});
 }else throw Error('unknown run mode');
 assert.deepEqual(receipt.downloads,[]);assert.deepEqual(receipt.pageErrors,[]);assert.deepEqual(receipt.externalRequests,[]);
 receipt.pass=true;receipt.base=base;
}catch(e){receipt.pass=false;receipt.error=String(e.stack||e);process.exitCode=1;}
finally{
 if(context){await context.close();receipt.contextClosed=true;}if(browser){await browser.close();receipt.browserClosed=true;}
 await new Promise(r=>server.close(r));receipt.serverClosed=true;receipt.finished=new Date().toISOString();
 await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({pass:receipt.pass,mode,checks:receipt.checks.length,error:receipt.error,finished:receipt.finished}));
}
