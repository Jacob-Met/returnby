import pathlib,os,json,hashlib,subprocess,time,datetime,signal,shutil,sys
R=pathlib.Path(__file__).resolve().parent; P=R.parent; mode=sys.argv[1]; name=sys.argv[2]; D=pathlib.Path(sys.argv[3]); A=pathlib.Path(sys.argv[4]) if len(sys.argv)>4 else R/'unused-adapter.json'
E=R/name;E.mkdir();T=E/'tmp';T.mkdir();C=E/'cache';C.mkdir()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
def snap():
 out={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:s=(p/'stat').read_text().rsplit(')',1)[1].split();out[int(p.name)]={'ppid':int(s[1]),'start':s[19]}
  except (OSError,ValueError):pass
 return out
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert free>=256*1024**2 and mem>=2*1024**3
before={str(p.relative_to(D)):pin(p) for p in sorted(D.rglob('*')) if p.is_file()}
cmd=['/usr/bin/node',str(R/'browser-runner-r4.mjs'),mode,str(D),str(E),str(A)]
receipt={'schema':'returnby-root-browser-process-v1','started':stamp(),'guard':{'free':free,'memory':mem},'argv':cmd,'runner':pin(R/'browser-runner-r4.mjs'),'predicates':pin(R/'browser-predicates-r4.mjs'),'servedBefore':before,'observed':{},'forced':[]}
env={**os.environ,'TMPDIR':str(T),'XDG_CACHE_HOME':str(C),'DEBUG':'pw:browser','TZ':'UTC'}
with (E/'stdout.txt').open('xb') as out,(E/'stderr.txt').open('xb') as err:
 p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err,start_new_session=True);receipt['pid']=p.pid;known={p.pid};start=time.monotonic()
 while p.poll() is None and time.monotonic()-start<180:
  s=snap();changed=True
  while changed:
   found={pid for pid,e in s.items() if e['ppid'] in known};changed=bool(found-known);known|=found
  for pid in known:
   if pid in s:
    e=s[pid]
    try:e={**e,'cmd':pathlib.Path('/proc',str(pid),'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
    except OSError:pass
    receipt['observed'][str(pid)]=e
  time.sleep(.25)
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);receipt['forced'].append('deadline group TERM')
 try:receipt['exit']=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);receipt['forced'].append('deadline group KILL');receipt['exit']=p.wait()
time.sleep(4);s=snap();alive={pid:e for pid,e in s.items() if str(pid) in receipt['observed'] and e['start']==receipt['observed'][str(pid)]['start']}
receipt['alive']=alive
if not alive:shutil.rmtree(T);shutil.rmtree(C)
after={str(p.relative_to(D)):pin(p) for p in sorted(D.rglob('*')) if p.is_file()}
receipt.update({'finished':stamp(),'profileAbsent':not T.exists(),'cacheAbsent':not C.exists(),'servedAfter':after,'servedExact':before==after})
if (E/'receipt.json').exists():receipt['nativeReceipt']=pin(E/'receipt.json')
with (E/'wrapper.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['observed','servedBefore','servedAfter']}))
raise SystemExit(0 if receipt['exit']==0 and not alive and before==after else 1)
