import pathlib,os,hashlib,json,datetime,subprocess,difflib
R=pathlib.Path(__file__).resolve().parent;P=R.parent;S=P/'source';D=R/'candidate-r1';D.mkdir()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert free>=256*1024**2 and mem>=2*1024**3
M=P/'evidence/candidate-r1/runtime-manifest.json';assert pin(M)['sha256']=='318f062fd8ed1b0a1073dc7a4e8d9d007a7a175c3de43cbfaaa03fa5bdb78171'
manifest=json.loads(M.read_text());assert manifest['base']=='bd07785d10ba40e524756b059c3f3cc548927f9f'
admitted={};unchanged=[];changed=[];added=[];diffs={}
for entry in manifest['files']:
 rel=pathlib.PurePosixPath(entry['path']);assert not rel.is_absolute() and '..' not in rel.parts
 src=S/rel;got=pin(src);assert got=={k:entry[k] for k in ['bytes','sha256','gitBlob']},rel
 dst=D/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('xb') as f:f.write(src.read_bytes())
 assert pin(dst)==got;admitted[str(rel)]=got
 original=P/'original'/rel
 if original.exists():
  if original.read_bytes()==src.read_bytes():unchanged.append(str(rel))
  else:changed.append(str(rel));diffs[str(rel)]=''.join(difflib.unified_diff(original.read_bytes().decode('utf-8').splitlines(True),src.read_bytes().decode('utf-8').splitlines(True),fromfile='original/'+str(rel),tofile='candidate/'+str(rel)))
 else:added.append(str(rel))
assert set(changed)=={'README.md','index.html','vite.config.ts'}
assert set(added)=={'docs/MANUAL_ENTRY.md','manual-entry.html','src/manual-entry-view.ts','src/manual-entry.css','src/manual-entry.ts'}
assert len(admitted)==34 and len(unchanged)==26
receipt={'schema':'returnby-root-runtime-admission-v1','admittedAt':stamp(),'base':manifest['base'],'tree':'96bb753431587f74eec2e3eefbb2198cb85d8f5e','manifest':pin(M),'guard':{'free':free,'memory':mem},'files':admitted,'unchanged':unchanged,'changed':changed,'added':added,'candidateTestsUnread':True,'preExposureFreeze':pin(R/'PRE-EXPOSURE-FREEZE.json')}
with (R/'RUNTIME-ADMISSION-r1.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
with (R/'EXISTING-DELTA-r1.json').open('x',encoding='utf-8') as f:json.dump(diffs,f,indent=2);f.write('\n')
print(json.dumps({'admission':pin(R/'RUNTIME-ADMISSION-r1.json'),'count':len(admitted),'unchanged':len(unchanged),'changed':changed,'added':added,'guard':receipt['guard']}))
cmd=['/usr/bin/node',str(P/'node_modules/vite/bin/vite.js'),'build','--configLoader','native','--outDir',str(R/'candidate-build-r1')]
env={**os.environ,'TMPDIR':str(R),'XDG_CACHE_HOME':str(R/'build-cache-r1'),'TZ':'UTC','CI':'1'}
p=subprocess.run(cmd,cwd=D,env=env,capture_output=True,text=True,timeout=45)
out=R/'BUILD-r1.json';built={str(f.relative_to(R/'candidate-build-r1')):pin(f) for f in sorted((R/'candidate-build-r1').rglob('*')) if f.is_file()}
result={'startedFromAdmission':receipt['admittedAt'],'finished':stamp(),'argv':cmd,'cwd':str(D),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'sourceExact':all(pin(D/rel)==v for rel,v in admitted.items()),'built':built}
with out.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({**result,'builtCount':len(built),'built':None}))
raise SystemExit(p.returncode)
