import pathlib,hashlib,json,datetime,os,subprocess
R=pathlib.Path(__file__).resolve().parent
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert free>=256*1024**2 and mem>=2*1024**3
files={n:pin(R/n) for n in ['ROOT-CONTRACT.md','ORACLE.json','original-node-r1.cjs','browser-predicates-r1.mjs']}
receipt={'frozen':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateAndAuthoredTestsUnseen':True,'files':files,'guard':{'availableBytes':free,'memoryAvailableBytes':mem},'identity':{'uid':os.getuid(),'gid':os.getgid(),'boot':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()},'node':subprocess.check_output(['/usr/bin/node','--version'],text=True).strip()}
with (R/'PRE-EXPOSURE-FREEZE.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
p=subprocess.run(['/usr/bin/node','--check',str(R/'browser-predicates-r1.mjs')],capture_output=True,text=True)
print(json.dumps({'browserSyntaxExit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
assert p.returncode==0
p=subprocess.run(['/usr/bin/node',str(R/'original-node-r1.cjs')],capture_output=True,text=True,timeout=30,env={**os.environ,'TZ':'UTC'})
with (R/'original-node-wrapper-r1.json').open('x',encoding='utf-8') as f:json.dump({'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receipt':pin(R/'original-node-r1/receipt.json')},f,indent=2);f.write('\n')
print(json.dumps({'originalNodeExit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
raise SystemExit(p.returncode)
