import pathlib,subprocess,json,datetime
R=pathlib.Path(__file__).resolve().parent
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.Popen(['python3','-B','-u',str(R/'seal-root-r2.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
out,err=p.communicate(timeout=60)
receipt={'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'exit':p.returncode,'stdout':out,'stderr':err}
with (R/'seal-wrapper-r2.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
raise SystemExit(p.returncode)
