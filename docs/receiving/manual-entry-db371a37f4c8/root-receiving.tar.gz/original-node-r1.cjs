const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const R=__dirname, P=path.dirname(R), O=path.join(P,'original'), E=path.join(R,'original-node-r1');
fs.mkdirSync(E); const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const ts=require(path.join(P,'node_modules/typescript/lib/typescript.js'));
const oracle=JSON.parse(fs.readFileSync(path.join(R,'ORACLE.json'),'utf8'));
const expected={'src/store.ts':'c7333d076f851c4dbad6199eaebd6ca34f4abdb3','src/order-admission.ts':'fcc5ad1761f4d2125549554f1c2835854d5e98c5','src/deadline.ts':'bcef920c0f9846b789b1a0aa01b833c7d99ba5d4'};
const receipt={schema:'returnby-root-original-node-v1',started:new Date().toISOString(),pid:process.pid,node:process.version,typescript:ts.version,oracleSha256:hash(fs.readFileSync(path.join(R,'ORACLE.json'))),sources:{},checks:[],level:'actual native Node22 using original TypeScript transpiled by admitted TypeScript5.9.3; controlled localStorage adapter, no browser claim'};
const record=(name,actual)=>receipt.checks.push({name,actual});
try {
fs.mkdirSync(path.join(E,'modules'));fs.writeFileSync(path.join(E,'modules/package.json'),'{"type":"commonjs"}\n',{flag:'wx'});
for(const [rel,want] of Object.entries(expected)){
 const b=fs.readFileSync(path.join(O,rel)); assert.equal(git(b),want);
 const transpiled=ts.transpileModule(b.toString('utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022},reportDiagnostics:true});
 assert.deepEqual(transpiled.diagnostics,[]);
 const output=path.join(E,'modules',path.basename(rel,'.ts')+'.js');fs.writeFileSync(output,transpiled.outputText,{flag:'wx'});
 receipt.sources[rel]={bytes:b.length,sha256:hash(b),git:git(b),emittedSha256:hash(Buffer.from(transpiled.outputText))};
}
const {validateOrderFields}=require(path.join(E,'modules/order-admission.js'));
for(const [orderDate,windowDays,due] of oracle.validDates){const got=validateOrderFields({...oracle.draft,orderDate,windowDays});assert.deepEqual(got,{days:Number(windowDays),due});record('valid calendar date '+orderDate+' plus '+windowDays,got);}
for(const orderDate of oracle.invalidDates){assert.throws(()=>validateOrderFields({...oracle.draft,orderDate}));record('invalid calendar date refused',orderDate);}
for(const windowDays of oracle.invalidWindows){assert.throws(()=>validateOrderFields({...oracle.draft,windowDays}));record('invalid window refused',windowDays);}
assert.throws(()=>validateOrderFields({...oracle.draft,...oracle.invalidEnd}));record('calendar reminder end overflow refused',oracle.invalidEnd);
for(const field of ['merchant','orderNo','total']){
 assert.equal(validateOrderFields({...oracle.draft,[field]:'X'.repeat(oracle.maxText)}).due,oracle.expected.due);
 assert.throws(()=>validateOrderFields({...oracle.draft,[field]:'X'.repeat(oracle.invalidText)}));
 record('text length boundary '+field,{accepted:oracle.maxText,refused:oracle.invalidText});
}
const {load,save}=require(path.join(E,'modules/store.js'));
let raw=null,reads=0,writes=[];
global.localStorage={getItem(k){assert.equal(k,oracle.key);reads++;return raw;},setItem(k,v){assert.equal(k,oracle.key);writes.push(v);raw=v;}};
assert.deepEqual(load(),[]);assert.deepEqual(writes,[]);record('absent storage loads empty without writes',true);
raw=JSON.stringify(oracle.existing);assert.deepEqual(load(),oracle.existing);record('existing rows and extension fields preserved',load());
for(const bad of ['{','{"unsupported":true}','[{"id":"incomplete"}]']){raw=bad;const before=writes.length;assert.throws(()=>load());assert.equal(writes.length,before);record('malformed or unsupported storage refused',bad);}
global.localStorage.getItem=()=>{throw new Error('root receiver read denied');};assert.throws(()=>load(),/root receiver read denied/);assert.deepEqual(writes,[]);record('read failure propagates without write',true);
global.localStorage.setItem=()=>{throw new Error('root receiver quota adapter');};assert.throws(()=>save(oracle.existing),/root receiver quota adapter/);record('write failure propagates',true);
for(const [rel,pin] of Object.entries(receipt.sources))assert.equal(hash(fs.readFileSync(path.join(O,rel))),pin.sha256);
receipt.pass=true;receipt.sourceExact=true;
}catch(e){receipt.pass=false;receipt.error=String(e.stack||e);process.exitCode=1;}
receipt.finished=new Date().toISOString();fs.writeFileSync(path.join(E,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({pass:receipt.pass,checks:receipt.checks.length,error:receipt.error,pid:process.pid,node:process.version,finished:receipt.finished}));
