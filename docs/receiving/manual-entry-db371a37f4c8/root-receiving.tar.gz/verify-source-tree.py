import pathlib,json,hashlib,datetime
R=pathlib.Path(__file__).resolve().parent;P=R.parent
pre=json.loads((R/'SOURCE-TREE-PREIMAGE.json').read_text())
def build(entries):
 root={}
 for e in entries:
  bits=e['path'].split('/');d=root
  for bit in bits[:-1]:d=d.setdefault(bit,{})
  assert bits[-1] not in d;d[bits[-1]]=('leaf',e)
 trees={}
 def visit(d,prefix=''):
  chunks=[]
  for name,node in sorted(d.items(),key=lambda kv:(kv[0]+('/' if isinstance(kv[1],dict) else '')).encode('utf-8')):
   if isinstance(node,dict):sha=visit(node,prefix+name+'/');mode='40000'
   else:e=node[1];sha=e['sha'];mode=e['mode'].lstrip('0')
   chunks.append((mode+' '+name+'\0').encode('utf-8')+bytes.fromhex(sha))
  raw=b''.join(chunks);sha=hashlib.sha1(('tree '+str(len(raw))+'\0').encode()+raw).hexdigest();trees[prefix[:-1]]=sha;return sha
 return visit(root),trees
leaves=[e for e in pre['baseEntries'] if e['type']!='tree'];base,trees=build(leaves);assert base==pre['baseTree']
for e in pre['baseEntries']:
 if e['type']=='tree':assert trees[e['path']]==e['sha'],e['path']
mapping={e['path']:e for e in leaves};original=dict(mapping);native={}
for o in pre['objects']:
 p=P/'source'/o['path'];b=p.read_bytes();h=hashlib.sha256(b).hexdigest();git=hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()
 assert h==o['sha256'] and git==o['gitBlob']==o['blob'] and len(b)==o['bytes'],o['path']
 native[o['path']]={'bytes':len(b),'sha256':h,'gitBlob':git}
 mapping[o['path']]={'path':o['path'],'mode':'100644','type':'blob','sha':git}
changed=[k for k in original if original[k]['sha']!=mapping[k]['sha']];added=[k for k in mapping if k not in original]
assert set(changed)=={'README.md','index.html','vite.config.ts'}
assert len(added)==6 and len(mapping)==201
untouched=[k for k in original if k not in changed];assert len(untouched)==192
candidate,ct=build(list(mapping.values()))
result={'schema':'returnby-root-source-tree-plan-v1','verified':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':pre['baseCommit'],'baseTree':base,'baseDirectoryTreesVerified':len(trees),'baseLeaves':len(leaves),'sourceTree':candidate,'sourceDirectoryTrees':len(ct),'sourceLeaves':len(mapping),'changed':changed,'added':added,'otherOriginalLeavesModesExact':len(untouched),'nativeContribution':native,'currentMain':pre['currentMain'],'limits':'Selected parent is owner-qualified stack, not canonical main. No ref/merge/deployment is implied.'}
with (R/'SOURCE-TREE-PLAN.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
