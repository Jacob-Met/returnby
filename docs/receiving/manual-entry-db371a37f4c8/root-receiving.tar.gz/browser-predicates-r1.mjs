import assert from 'node:assert/strict';
export function installStorageObserver() {
 const key='returnby.v1', get=Storage.prototype.getItem, set=Storage.prototype.setItem, remove=Storage.prototype.removeItem;
 const state={reads:[],writes:[],readFailure:false,writeFailure:false};
 window.__rootStore={state,peek:()=>get.call(localStorage,key),seed:raw=>raw===null?remove.call(localStorage,key):set.call(localStorage,key,raw),reset:()=>{state.reads=[];state.writes=[];state.readFailure=false;state.writeFailure=false;}};
 Storage.prototype.getItem=function(k){if(this===localStorage&&k===key){state.reads.push({at:performance.now(),failed:state.readFailure});if(state.readFailure)throw new Error('ROOT receiver denied storage read');}return get.call(this,k);};
 Storage.prototype.setItem=function(k,v){if(this===localStorage&&k===key){state.writes.push({at:performance.now(),before:get.call(this,k),value:String(v),failed:state.writeFailure});if(state.writeFailure)throw new DOMException('ROOT receiver quota adapter','QuotaExceededError');}return set.call(this,k,v);};
}
export async function originalJourney(page, base, record, out) {
 await page.goto(base,{waitUntil:'networkidle'});
 assert.equal(await page.locator('#preview').isVisible(),false);
 assert.equal(await page.evaluate(()=>window.__rootStore.peek()),null);
 assert.deepEqual(await page.evaluate(()=>window.__rootStore.state.writes),[]);
 await page.locator('#find').click();
 assert.equal(await page.locator('#preview').isVisible(),true);
 assert.equal(await page.locator('#preview [name=windowDays]').inputValue(),'30');
 assert.equal(await page.locator('#preview [name=merchant]').inputValue(),'');
 assert.match(await page.locator('#src').innerText(),/fallback/);
 await page.locator('#paste').fill('Paper receipt without recognized fields <&> 東京');
 await page.locator('#find').click();
 assert.equal(await page.locator('#preview [name=windowDays]').inputValue(),'30');
 assert.equal(await page.evaluate(()=>window.__rootStore.peek()),null);
 assert.deepEqual(await page.evaluate(()=>window.__rootStore.state.writes),[]);
 record('B0 original blank/unparseable Find already exposes editable fallback',await page.locator('#preview').innerText());
 await page.screenshot({path:out+'/original-fallback.png',fullPage:true});
}
export async function receiptJourney({page,other,base,ui,oracle:O,record,out}) {
 const route=base+'manual-entry.html';
 const loc=k=>page.locator(ui[k]);
 const field=k=>page.locator(ui.fields[k]);
 const fill=async(d=O.draft)=>{for(const [k,v] of Object.entries(d))await field(k).fill(String(v));};
 const store=()=>page.evaluate(()=>({raw:window.__rootStore.peek(),...window.__rootStore.state}));
 const seed=async rows=>page.evaluate(raw=>window.__rootStore.seed(raw),typeof rows==='string'?rows:rows===null?null:JSON.stringify(rows));
 const review=async()=>{await loc('review').click();assert.equal(await loc('reviewPanel').isVisible(),true);};
 const currentDraft=async()=>Object.fromEntries(await Promise.all(Object.keys(O.draft).map(async k=>[k,await field(k).inputValue()])));
 const prepare=async(rows=O.existing)=>{await page.goto(route,{waitUntil:'networkidle'});await seed(rows);await page.reload({waitUntil:'networkidle'});await fill();await review();};
 const assertLiteralReview=async(d=O.draft,due=O.expected.due)=>{
  const t=await loc('reviewPanel').innerText();
  for(const v of [d.merchant,d.orderNo,d.total,d.orderDate,d.windowDays,due])assert.ok(t.includes(String(v)),'missing literal review field '+v);
  return t;
 };
 const assertSaved=rows=>{
  assert.ok(rows.length>=1);const row=rows.at(-1);
  for(const [k,v] of Object.entries(O.expected))if(k!=='due')assert.deepEqual(row[k],v,'saved '+k);
  assert.equal(typeof row.id,'string');assert.ok(row.id.length>0);
  assert.equal(typeof row.createdAt,'string');assert.ok(Number.isFinite(Date.parse(row.createdAt)));
  return row;
 };
 await page.goto(route,{waitUntil:'networkidle'});await seed(null);await page.reload({waitUntil:'networkidle'});
 assert.equal((await store()).raw,null);assert.deepEqual((await store()).writes,[]);
 await fill();await review();const reviewText=await assertLiteralReview();
 assert.equal((await store()).raw,null);assert.deepEqual((await store()).writes,[]);
 await page.screenshot({path:out+'/receipt-review-desktop.png',fullPage:true});
 record('C1 direct receipt review is literal, derives2026-11-08 and has no writes',{reviewText,draft:await currentDraft()});

 // Editing retires or disables the stale reviewed draft before another Save.
 await field('merchant').fill('Edited receipt 東京');
 const staleBlocked=!(await loc('reviewPanel').isVisible()) || !(await loc('save').isVisible()) || await loc('save').isDisabled();
 assert.equal(staleBlocked,true,'editing must retire or block old review');
 assert.equal((await store()).raw,null);assert.deepEqual((await store()).writes,[]);
 await fill();await review();await assertLiteralReview();
 await loc('cancelReview').click();
 assert.equal((await store()).raw,null);assert.deepEqual((await store()).writes,[]);
 record('C2 edit retires stale review and review-cancel writes nothing',true);
 await fill();await review();

 // A real second page changes current storage after review: one edit, one removal, one addition.
 await other.goto(base,{waitUntil:'networkidle'});
 const changed=[{...O.existing[0],merchant:'Existing A edited elsewhere',extension:{...O.existing[0].extension,edited:true}},O.concurrent];
 await other.evaluate(rows=>localStorage.setItem('returnby.v1',JSON.stringify(rows)),changed);
 await loc('save').click();
 let state=await store(), rows=JSON.parse(state.raw);
 assert.equal(state.writes.filter(w=>!w.failed).length,1);assert.equal(rows.length,3);assert.deepEqual(rows.slice(0,-1),changed);
 let saved=assertSaved(rows);assert.deepEqual(JSON.parse(state.writes.at(-1).before),changed);
 assert.ok(state.reads.length>0);
 // Real success must retire the review. Dispatching the old submit path may not append twice.
 const prevented=!(await loc('save').isVisible()) || await loc('save').isDisabled() || !(await loc('reviewPanel').isVisible());
 assert.equal(prevented,true,'success must retire reviewed save');
 await page.keyboard.press('Enter');
 assert.deepEqual(JSON.parse((await store()).raw),rows);
 record('C3 fresh real second-tab save preserves edit/removal/addition and extension fields',{preserved:changed,saved,reads:state.reads,writes:state.writes});
 await loc('tracker').click();assert.ok(page.url()===base || page.url()===base+'index.html');
 await page.reload({waitUntil:'networkidle'});
 assert.ok((await page.locator('body').innerText()).includes(O.expected.merchant));
 assert.ok((await page.locator('body').innerText()).toLowerCase().includes('user'));
 assert.deepEqual(JSON.parse(await page.evaluate(()=>window.__rootStore.peek())),rows);
 record('C4 ordinary tracker reload shows saved user receipt exactly once',{url:page.url(),id:saved.id});

 // Native browser read failure adapters: preserve current review/draft and actual storage.
 for(const kind of ['readFailure','malformedRead','writeFailure']){
  await prepare(O.existing);const draft=await currentDraft(), before=JSON.stringify(O.existing);
  await page.evaluate(()=>window.__rootStore.reset());
  if(kind==='malformedRead')await seed('{malformed root receiving');
  else await page.evaluate(k=>window.__rootStore.state[k]=true,kind);
  await loc('save').click();state=await store();
  assert.deepEqual(await currentDraft(),draft);
  assert.equal(await loc('reviewPanel').isVisible(),true);
  assert.ok((await loc('error').innerText()).trim().length>0);
  assert.equal(state.raw,kind==='malformedRead'?'{malformed root receiving':before);
  if(kind!=='writeFailure')assert.equal(state.writes.length,0);else{assert.equal(state.writes.length,1);assert.equal(state.writes[0].failed,true);}
  const failedState=state;
  // A deliberate retry obtains a later actual second-tab row set and appends only once.
  const retryRows=[O.existing[1],O.concurrent];
  await other.evaluate(rows=>localStorage.setItem('returnby.v1',JSON.stringify(rows)),retryRows);
  await page.evaluate(()=>{window.__rootStore.state.readFailure=false;window.__rootStore.state.writeFailure=false;});
  await loc('save').click();state=await store();rows=JSON.parse(state.raw);
  assert.equal(rows.length,3);assert.deepEqual(rows.slice(0,-1),retryRows);saved=assertSaved(rows);
  assert.equal(state.writes.filter(w=>!w.failed).length,1);
  record('C5 '+kind+' refuses mutation, retains review, then retries from fresh real store',{failedState,retrySaved:saved,preserved:retryRows});
 }

 // Candidate UI refuses invalid whole-day values without storage writes and retains a correctable draft.
 for(const windowDays of ['0','1.5']){
  await page.goto(route,{waitUntil:'networkidle'});await seed(O.existing);await page.reload({waitUntil:'networkidle'});
  await fill({...O.draft,windowDays});await loc('review').click();
  assert.deepEqual((await store()).writes,[]);assert.deepEqual(JSON.parse((await store()).raw),O.existing);
  assert.equal(await field('windowDays').inputValue(),windowDays);
  assert.equal(await loc('reviewPanel').isVisible(),false);
  record('C6 invalid UI window refuses review and persistence',windowDays);
 }
 await page.goto(route,{waitUntil:'networkidle'});await seed(null);await page.reload({waitUntil:'networkidle'});
 await page.setViewportSize({width:390,height:844});await fill();await review();await assertLiteralReview();
 assert.deepEqual((await store()).writes,[]);
 const geometry=await page.evaluate(()=>({viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth}));
 assert.ok(geometry.scrollWidth<=geometry.viewport,'phone page must not horizontally overflow');
 await page.screenshot({path:out+'/receipt-review-phone.png',fullPage:true});
 await loc('back').click();assert.ok(page.url()===base||page.url()===base+'index.html');
 assert.equal(await page.evaluate(()=>window.__rootStore.peek()),null);
 record('C7 phone direct reload and back route without save',{geometry,url:page.url()});
}
