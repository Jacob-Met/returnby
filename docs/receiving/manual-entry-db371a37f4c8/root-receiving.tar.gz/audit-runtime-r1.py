import pathlib,os,hashlib,json,datetime
R=pathlib.Path(__file__).resolve().parent;P=R.parent
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
M=P/'evidence/donor-manifest.json';m=json.loads(M.read_text());want={e['path']:e for e in m['files']}
receipt={'schema':'returnby-root-post-use-runtime-audit-v1','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(M),'roots':{},'limits':'Post-use full byte/set verification against independently preserved original donor admission. It does not claim a new pre-use full rehash.'}
for location in [m['donor'],m['copied']]:
 root=pathlib.Path(location);actual={}
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if rel.parts[0] in m['exclusions']:continue
  if p.is_symlink():actual[str(rel)]={'type':'symlink','target':os.readlink(p)}
  elif p.is_file():actual[str(rel)]={'type':'file','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':p.stat().st_mode&0o777}
 assert set(actual)==set(want),(location,'file set mismatch')
 for rel,e in want.items():assert actual[rel]=={k:v for k,v in e.items() if k!='path'},(location,rel)
 receipt['roots'][location]={'entries':len(actual),'bytes':sum(e.get('bytes',0) for e in actual.values()),'allAdmittedBytesSetModesLinksExact':True}
ad=json.loads((R/'RUNTIME-ADMISSION-r1.json').read_text())
receipt['candidateExact']=all(pin(R/'candidate-r1'/rel)==v and pin(P/'source'/rel)==v for rel,v in ad['files'].items());assert receipt['candidateExact']
receipt['sharedOriginalExact']={rel:(P/'original'/rel).read_bytes()==(R/'candidate-r1'/rel).read_bytes() for rel in ad['unchanged']};assert all(receipt['sharedOriginalExact'].values())
receipt['nodeBinary']=pin(pathlib.Path('/usr/bin/node'))
playwright=pathlib.Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8/source/node_modules/playwright/index.mjs');receipt['playwrightEntry']=pin(playwright)
receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (R/'RUNTIME-FINAL-AUDIT-r1.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='sharedOriginalExact'}));print(json.dumps({'receipt':pin(R/'RUNTIME-FINAL-AUDIT-r1.json')}))
