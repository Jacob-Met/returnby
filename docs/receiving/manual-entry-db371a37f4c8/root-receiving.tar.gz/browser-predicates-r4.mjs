import assert from 'node:assert/strict';
export function installStorageObserver() {
 const key='returnby.v1', get=Storage.prototype.getItem, set=Storage.prototype.setItem, remove=Storage.prototype.removeItem;
 const state={reads:[],writes:[],readFailure:false,writeFailure:false};
 window.__rootStore={state,peek:()=>get.call(localStorage,key),seed:raw=>raw===null?remove.call(localStorage,key):set.call(localStorage,key,raw),reset:()=>{state.reads=[];state.writes=[];state.readFailure=false;state.writeFailure=false;}};
 Storage.prototype.getItem=function(k){if(this===localStorage&&k===key){state.reads.push({at:performance.now(),failed:state.readFailure});if(state.readFailure)throw new Error('ROOT receiver denied storage read');}return get.call(this,k);};
 Storage.prototype.setItem=function(k,v){if(this===localStorage&&k===key){state.writes.push({at:performance.now(),before:get.call(this,k),value:String(v),failed:state.writeFailure});if(state.writeFailure)throw new DOMException('ROOT receiver quota adapter','QuotaExceededError');}return set.call(this,k,v);};
}
export async function originalJourney(page, base, record, out) {
 await page.goto(base,{waitUntil:'networkidle'});
 assert.equal(await page.locator('#preview').isVisible(),false);
 assert.equal(await page.evaluate(()=>window.__rootStore.peek()),null);
 assert.deepEqual(await page.evaluate(()=>window.__rootStore.state.writes),[]);
 await page.locator('#find').click();
 assert.equal(await page.locator('#preview').isVisible(),true);
 assert.equal(await page.locator('#preview [name=windowDays]').inputValue(),'30');
 assert.equal(await page.locator('#preview [name=merchant]').inputValue(),'');
 assert.match(await page.locator('#src').innerText(),/fallback/);
 await page.locator('#paste').fill('Paper receipt without recognized fields <&> 東京');
 await page.locator('#find').click();
 assert.equal(await page.locator('#preview [name=windowDays]').inputValue(),'30');
 assert.equal(await page.evaluate(()=>window.__rootStore.peek()),null);
 assert.deepEqual(await page.evaluate(()=>window.__rootStore.state.writes),[]);
 record('B0 original blank/unparseable Find already exposes editable fallback',await page.locator('#preview').innerText());
 await page.screenshot({path:out+'/original-fallback.png',fullPage:true});
}
export async function receiptJourney({page,other,base,ui,oracle:O,record,out}) {
 const route=base+'manual-entry.html';
 const loc=k=>page.locator(ui[k]);
 const field=k=>page.locator(ui.fields[k]);
 const fill=async(d=O.draft)=>{for(const [k,v] of Object.entries(d))await field(k).fill(String(v));};
 const store=()=>page.evaluate(()=>({raw:window.__rootStore.peek(),...window.__rootStore.state}));
 const seed=async rows=>page.evaluate(raw=>window.__rootStore.seed(raw),typeof rows==='string'?rows:rows===null?null:JSON.stringify(rows));
 const review=async()=>{await loc('review').click();assert.equal(await loc('reviewPanel').isVisible(),true);};
 const currentDraft=async()=>Object.fromEntries(await Promise.all(Object.keys(O.draft).map(async k=>[k,await field(k).inputValue()])));
 const prepare=async(rows=O.existing)=>{await page.goto(route,{waitUntil:'networkidle'});await seed(rows);await page.reload({waitUntil:'networkidle'});await fill();await review();};
 const assertLiteralReview=async(d=O.draft,due=O.expected.due)=>{
  const t=await loc('reviewPanel').innerText();
  for(const v of [d.merchant,d.orderNo,d.total,d.orderDate,d.windowDays,due])assert.ok(t.includes(String(v)),'missing literal review field '+v);
  return t;
 };
 const assertSaved=rows=>{
  assert.ok(rows.length>=1);const row=rows.at(-1);
  for(const [k,v] of Object.entries(O.expected))if(k!=='due')assert.deepEqual(row[k],v,'saved '+k);
  assert.equal(typeof row.id,'string');assert.ok(row.id.length>0);
  assert.equal(typeof row.createdAt,'string');assert.ok(Number.isFinite(Date.parse(row.createdAt)));
  return row;
 };
 // Continuation after settled C1-C4. The other tab must join this origin before native storage access.
 let state,rows,saved;await other.goto(base,{waitUntil:'networkidle'});

 // Native browser read failure adapters: preserve current review/draft and actual storage.
 for(const kind of ['readFailure','malformedRead','writeFailure']){
  await prepare(O.existing);const draft=await currentDraft(), before=JSON.stringify(O.existing);
  await page.evaluate(()=>window.__rootStore.reset());
  if(kind==='malformedRead')await seed('{malformed root receiving');
  else await page.evaluate(k=>window.__rootStore.state[k]=true,kind);
  await loc('save').click();state=await store();
  assert.deepEqual(await currentDraft(),draft);
  assert.equal(await loc('reviewPanel').isVisible(),true);
  assert.ok((await loc('error').innerText()).trim().length>0);
  assert.equal(state.raw,kind==='malformedRead'?'{malformed root receiving':before);
  if(kind!=='writeFailure')assert.equal(state.writes.length,0);else{assert.equal(state.writes.length,1);assert.equal(state.writes[0].failed,true);}
  const failedState=state;
  // A deliberate retry obtains a later actual second-tab row set and appends only once.
  const retryRows=[O.existing[1],O.concurrent];
  await other.evaluate(rows=>localStorage.setItem('returnby.v1',JSON.stringify(rows)),retryRows);
  await page.evaluate(()=>{window.__rootStore.state.readFailure=false;window.__rootStore.state.writeFailure=false;});
  await loc('save').click();state=await store();rows=JSON.parse(state.raw);
  assert.equal(rows.length,3);assert.deepEqual(rows.slice(0,-1),retryRows);saved=assertSaved(rows);
  assert.equal(state.writes.filter(w=>!w.failed).length,1);
  record('C5 '+kind+' refuses mutation, retains review, then retries from fresh real store',{failedState,retrySaved:saved,preserved:retryRows});
 }

 // Candidate UI refuses invalid whole-day values without storage writes and retains a correctable draft.
 for(const windowDays of ['0','1.5']){
  await page.goto(route,{waitUntil:'networkidle'});await seed(O.existing);await page.reload({waitUntil:'networkidle'});
  await fill({...O.draft,windowDays});await loc('review').click();
  assert.deepEqual((await store()).writes,[]);assert.deepEqual(JSON.parse((await store()).raw),O.existing);
  assert.equal(await field('windowDays').inputValue(),windowDays);
  assert.equal(await loc('reviewPanel').isVisible(),false);
  record('C6 invalid UI window refuses review and persistence',windowDays);
 }
 await page.goto(route,{waitUntil:'networkidle'});await seed(null);await page.reload({waitUntil:'networkidle'});
 await page.setViewportSize({width:390,height:844});await fill();await review();await assertLiteralReview();
 assert.deepEqual((await store()).writes,[]);
 const geometry=await page.evaluate(()=>({viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth}));
 assert.ok(geometry.scrollWidth<=geometry.viewport,'phone page must not horizontally overflow');
 await page.screenshot({path:out+'/receipt-review-phone.png',fullPage:true});
 await loc('back').click();assert.ok(page.url()===base||page.url()===base+'index.html');
 assert.equal(await page.evaluate(()=>window.__rootStore.peek()),null);
 record('C7 phone direct reload and back route without save',{geometry,url:page.url()});
}
