# Maintained intake fixture compatibility proposal

## Scope and cause

Only tests/helpers/storage-fixture.mjs changes: 20 added lines after the existing preview.dataset initialization. Production files, assertions, caller fixtures, generic Element behavior, and the separate editor dialog fixture are unchanged.

The retained first candidate maintained run has 28 failed / 173 passed tests across five failed and seven passed suites. Every first failure occurs when candidate/src/main.ts:138 accesses preview.elements.namedItem, before the existing storage and attribution assertions. The 201/201 baseline pass and both successful TypeScript/Vite gates remain root-owned evidence. This proposal does not relabel that first candidate gate as passing.

## Implementation rationale

The fixed Map contains precisely the five controls rendered by showPreview: merchant, orderDate, orderNo, total, and windowDays. All five can receive an EditError.field from validateOrderFields. Unknown namedItem requests return null; the adapter never manufactures a permissive fallback input. querySelectorAll supports the exact input selector used by the input handler and throws for an unsupported selector.

Each control has a live value getter and setter that resolves preview.fields on every access. This preserves whole-object replacement in draft(), submitted-policy review(), and combined-receiving find(), as well as merchant/window changes between refused-save retries. It never snapshots the original object or value.

setCustomValidity stores the message. checkValidity returns false while that message is nonempty. reportValidity returns the same validity and focuses a refusing input through the same document.activeElement tracked by the rest of the fixture. The application's input listener clears all five messages through querySelectorAll('input'). Focus on a valid report does not move.

This is an inert authored-field boundary for storage and attribution cases. Its custom-error-only check does not emulate native HTML type, min, step, value sanitization, interactive submission, or control replacement. Those constraints belong to the real browser receiving journey, whose independent proof remains separate. The comment at the adapter makes this limitation explicit rather than introducing an approximate numeric validator into the fixture.

The loading fixture wraps this fixture without changing controls. Combined and backup receiving callers reuse the generic Element constructor; keeping the adaptation local to preview preserves that behavior. The separate editor test fixture's dialog, querySelectorAll, and input mocks remain untouched.

## Validation and handoff

Node checks the exact proposed MJS bytes as an ECMAScript module through stdin with --input-type=module --check. The exact command, stdin hash, exit status, and raw stdout/stderr are retained under syntax-check/. No maintained suite, consumer proof, build, or native browser proof was rerun by this worker. Parent task owns the coordinated full maintained suite using this frozen fixture hash.

All preexisting assigned ZIP members are retained byte-for-byte, including the initial custody failure, restored baseline ICS bytes, and frozen candidate attempt-2 receipt with 14 artifacts. The append manifest records both prior member pins and new artifact pins. The root copy of the retained first maintained failure remains referenced by SHA-256 in PROPOSAL.json.
