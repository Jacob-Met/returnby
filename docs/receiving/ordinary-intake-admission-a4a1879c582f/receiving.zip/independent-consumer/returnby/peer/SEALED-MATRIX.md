# Independent ReturnBy admission/consumer matrix
Sealed from original retained sources before reading candidate implementation.
Authority: Jacob-Met/returnby #20 commit 7829e56e57ef91dfe8edd5853fd68d6c7890fac0, tree b28e7b706fe67fd4b34111badd581c6bdd2ed4a7. Current main 1e662c387be5f66f8499fac7ec443f58d2198379 has no backup/edit feature; its source-only intake witness is kept separate.

1. Preserve ordinary 30-day input, exact literal Unicode merchant/orderNo/total, generated ID/time and source attribution. No text trimming or normalization.
2. Preserve valid ordinary numeric controls: raw 1e2 -> 100, 30.0 -> 30, intentional blank -> 30. A browser badInput state or nonempty invalid/negative/fractional value must not fall through to 30. Existing saved-editor raw digit strictness stays unchanged.
3. Native leap boundary 2024-02-28 + 1 -> 2024-02-29 and year rollover 2026-12-31 + 1 -> 2027-01-01 remain exact through backup export/parse and native ICS.
4. Finite positive 1000000000 and 1000000000000 day values yield invalid native deadlines in the original consumer path and must be refused before new-order persistence in any proposal.
5. Native due 9999-12-31 passes original backup admission but its calendar next-day end is unsupported. A proposal must retain the editor's stricter next-day admission, rather than treating backup alone as sufficient.
6. Exact 4096-character text is allowed, 4097 refused; malformed Gregorian dates, fractional/negative days refuse; no new restrictions on already valid literals.
7. Refusal leaves saved rows and the user's input/draft intact. Valid saves retain the exact owner16 fresh-read/persist ordering. These UI/state claims require source review and later real browser receiving; a constructed-row probe does not establish them.

Local baseline execution is only a constructed-row consumer probe: unchanged retained deadline/ICS/backup modules, Node's built-in TypeScript transform, no policy stub. It is not an actual form gesture, storage Save, browser, Vite build, hosted gate, combined-app acceptance, deployment or new ownership claim.
