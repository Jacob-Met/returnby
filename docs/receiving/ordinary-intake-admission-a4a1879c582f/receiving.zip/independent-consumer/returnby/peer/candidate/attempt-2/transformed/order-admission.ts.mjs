import { dueDate } from 'data:text/javascript;base64,Y29uc3QgdG9EYXRlID0gKHMpPT57CiAgICBjb25zdCBbeSwgbSwgZF0gPSBzLnNwbGl0KCctJykubWFwKE51bWJlcik7CiAgICByZXR1cm4gbmV3IERhdGUoeSwgbSAtIDEsIGQpOwp9Owpjb25zdCBmbXQgPSAoZCk9PmAke2QuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoZC5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKX0tJHtTdHJpbmcoZC5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJyl9YDsKZXhwb3J0IGZ1bmN0aW9uIGR1ZURhdGUob3JkZXJEYXRlLCBkYXlzKSB7CiAgICBjb25zdCBkID0gdG9EYXRlKG9yZGVyRGF0ZSk7CiAgICBkLnNldERhdGUoZC5nZXREYXRlKCkgKyBkYXlzKTsKICAgIHJldHVybiBmbXQoZCk7Cn0KZXhwb3J0IGZ1bmN0aW9uIGRheXNMZWZ0KGR1ZSwgdG9kYXkpIHsKICAgIGNvbnN0IG1zID0gdG9EYXRlKGR1ZSkuZ2V0VGltZSgpIC0gdG9EYXRlKHRvZGF5KS5nZXRUaW1lKCk7CiAgICByZXR1cm4gTWF0aC5yb3VuZChtcyAvIDg2XzQwMF8wMDApOwp9CmV4cG9ydCBmdW5jdGlvbiBzdGF0dXMobGVmdCkgewogICAgaWYgKGxlZnQgPCAwKSByZXR1cm4gJ2V4cGlyZWQnOwogICAgaWYgKGxlZnQgPD0gMikgcmV0dXJuICd1cmdlbnQnOwogICAgaWYgKGxlZnQgPD0gNykgcmV0dXJuICdzb29uJzsKICAgIHJldHVybiAnb2snOwp9CmV4cG9ydCBjb25zdCB0b2RheUlTTyA9ICgpPT5mbXQobmV3IERhdGUoKSk7Cg==';
export class EditError extends Error {
    field;
    constructor(message, field){
        super(message), this.field = field;
    }
}
function isCalendarDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number(value.slice(0, 4)) < 1000) return false;
    const date = new Date(`${value}T00:00:00Z`);
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export function validateOrderFields(draft) {
    for (const [field, label] of [
        [
            'merchant',
            'Store'
        ],
        [
            'orderNo',
            'Order number'
        ],
        [
            'total',
            'Total'
        ]
    ]){
        if (draft[field].length > 4096) throw new EditError(`${label} must be no longer than 4,096 characters.`, field);
    }
    if (!isCalendarDate(draft.orderDate)) {
        throw new EditError('Choose a valid order date with a year from 1000 to 9999.', 'orderDate');
    }
    const days = Number(draft.windowDays);
    if (!/^\d+$/.test(draft.windowDays) || !Number.isSafeInteger(days) || days < 1 || days > 3_700_000) {
        throw new EditError('Enter a return window as a positive whole number of days.', 'windowDays');
    }
    const due = dueDate(draft.orderDate, days);
    if (!isCalendarDate(due)) {
        throw new EditError('The return window must end within the year 9999.', 'windowDays');
    }
    if (!isCalendarDate(dueDate(due, 1))) {
        throw new EditError('The return deadline must be before 9999-12-31 so its calendar reminder has a valid end date.', 'windowDays');
    }
    return {
        days,
        due
    };
}
