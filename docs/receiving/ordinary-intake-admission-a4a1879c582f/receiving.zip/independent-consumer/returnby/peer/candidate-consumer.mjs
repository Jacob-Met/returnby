import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {stripTypeScriptTypes} from 'node:module';
const hash=s=>createHash('sha256').update(s).digest('hex'),git=s=>createHash('sha1').update('blob '+Buffer.byteLength(s)+'\0').update(s).digest('hex');
const pin={'deadline.ts':'bcef920c0f9846b789b1a0aa01b833c7d99ba5d4','ics.ts':'58c873a116ed6b265864cb3e7d5b0dd27fd81544','backup.ts':'bdd86ce50c723abf8f1d305d4fdf63353510eba8'};
const original={},transform={};for(const p of [...Object.keys(pin),'order-admission.ts']){original[p]=readFileSync(new URL('./source/'+p,import.meta.url),'utf8');if(pin[p])assert.equal(git(original[p]),pin[p]);else assert.equal(hash(original[p]),'6251cd1e8334bf4fd15aeb5ed95ee7d4022fd1578f283134b9f449132cfc40f1');transform[p]=stripTypeScriptTypes(original[p],{mode:'transform',sourceMap:false});}
const uri=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64'),d=uri(transform['deadline.ts']);
for(const p of ['backup.ts','order-admission.ts']){assert.equal((transform[p].match(/from '\.\/deadline'/g)||[]).length,1);transform[p]=transform[p].replace("from './deadline'","from '"+d+"'");}
for(const[p,s]of Object.entries(transform))writeFileSync(new URL('./transformed/'+p+'.mjs',import.meta.url),s);
const {validateOrderFields,EditError}=await import(uri(transform['order-admission.ts']));
const {buildIcs}=await import(uri(transform['ics.ts'])),{exportBackup,parseBackup}=await import(uri(transform['backup.ts']));
const start=new Date().toISOString(),stamp=new Date('2026-10-08T22:00:00.000Z');
const receipt={scope:'pure candidate admission -> unchanged #20 native consumers; no UI/form/Save/storage/browser/Vite proof',base:'7829e56e57ef91dfe8edd5853fd68d6c7890fac0',node:process.version,tz:process.env.TZ,start,source:Object.fromEntries(Object.entries(original).map(([p,s])=>[p,{sha256:hash(s),git_blob:git(s)}])),transform:Object.fromEntries(Object.entries(transform).map(([p,s])=>[p,hash(s)])),groups:[],artifacts:{}};
const put=(p,s)=>{writeFileSync(new URL('./output/'+p,import.meta.url),s);receipt.artifacts[p]={bytes:Buffer.byteLength(s),sha256:hash(s)};};
const common={id:'admission-peer-1',merchant:' Café 雪 <literal> ',orderNo:'#R,"A"',total:'€17,20 literal',createdAt:'2026-10-08T21:00:00.000Z',windowSource:'user'};
function admit(date,raw){const days=Number(raw)||30;const draft=Object.freeze({merchant:common.merchant,orderNo:common.orderNo,total:common.total,orderDate:date,windowDays:String(days)});const before=JSON.stringify(draft);const accepted=validateOrderFields(draft);assert.equal(JSON.stringify(draft),before);return {draft,accepted,row:{...common,orderDate:date,windowDays:accepted.days}};}
const valid=[];
for(const[label,date,raw,expectedDue,baseline]of [['ordinary-literal','2026-10-08','30','2026-11-07','ordinary-literal'],['scientific-numeric','2026-10-08','1e2','2027-01-16','scientific-numeric'],['blank-fallback','2026-10-08','','2026-11-07','blank-fallback'],['leap-day','2024-02-28','1','2024-02-29','leap-day'],['year-rollover','2026-12-31','1','2027-01-01','year-rollover'],['whole-decimal-alias','2026-10-08','30.0','2026-11-07','ordinary-literal']]){
 const{accepted,row}=admit(date,raw);assert.equal(accepted.due,expectedDue);
 const json=exportBackup([row],stamp),ics=buildIcs({...row,due:accepted.due},stamp);assert.deepEqual(parseBackup(json),[row]);
 assert.equal(json,readFileSync(new URL('./baseline/'+baseline+'.json',import.meta.url),'utf8'));
 assert.equal(ics,readFileSync(new URL('./baseline/'+baseline+'.ics',import.meta.url),'utf8'));
 put(label+'.json',json);put(label+'.ics',ics);valid.push({label,raw,days:accepted.days,due:accepted.due,exactOriginalBackupAndRawIcs:true});
}
receipt.groups.push({name:'candidate-admits-original-exact-valid-consumer-bytes',pass:true,cases:valid});
const refused=[];
for(const[date,raw]of [['2026-10-08','1000000000'],['2026-10-08','1000000000000'],['9999-12-30','1']]){let error;try{admit(date,raw);}catch(e){assert(e instanceof EditError);assert.equal(e.field,'windowDays');error={name:e.name,field:e.field,message:e.message};}assert(error);refused.push({date,raw,error});}
receipt.groups.push({name:'candidate-refuses-all-three-original-counterexamples-before-consumers',pass:true,cases:refused});
{
 const {accepted,row}=admit('9999-12-29','1');assert.deepEqual(accepted,{days:1,due:'9999-12-30'});
 const backup=exportBackup([row],stamp);assert.deepEqual(parseBackup(backup),[row]);const ics=buildIcs({...row,due:accepted.due},stamp);
 assert(ics.includes('DTSTART;VALUE=DATE:99991230'));assert(ics.includes('DTEND;VALUE=DATE:99991231'));put('adjacent-valid-boundary.json',backup);put('adjacent-valid-boundary.ics',ics);
 receipt.groups.push({name:'candidate-retains-adjacent-valid-calendar-boundary',pass:true,days:1,due:accepted.due,end:'99991231'});
}
receipt.end=new Date().toISOString();receipt.groupCount=receipt.groups.length;receipt.pass=receipt.groups.every(x=>x.pass);
put('RECEIPT.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({pass:receipt.pass,groups:receipt.groupCount,scope:receipt.scope,source:receipt.source}));
