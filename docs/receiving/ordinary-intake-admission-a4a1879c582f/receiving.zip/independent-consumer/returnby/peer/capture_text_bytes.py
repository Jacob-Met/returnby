def capture_text_bytes(path):
    """Preserve UTF-8 artifact bytes, including CRLF, when passing through JSON."""
    return path.read_bytes().decode('utf-8')
