import { dueDate } from './deadline';
export const MAX_BACKUP_BYTES = 5 * 1024 * 1024;
export const MAX_BACKUP_ORDERS = 10_000;
const ORDER_KEYS = [
    'id',
    'merchant',
    'orderNo',
    'total',
    'orderDate',
    'windowDays',
    'windowSource',
    'createdAt'
];
const encoder = new TextEncoder();
const SIZE_TIMESTAMP = '2000-01-01T00:00:00.000Z';
export class BackupError extends Error {
}
function object(value, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new BackupError(`${label} must be an object.`);
    return value;
}
function onlyKeys(value, keys, label) {
    if (Object.keys(value).some((key)=>!keys.includes(key))) throw new BackupError(`${label} contains unsupported fields.`);
}
function text(value, label, limit = 4096) {
    if (typeof value !== 'string' || value.length > limit) throw new BackupError(`${label} must be text of at most ${limit} characters.`);
    return value;
}
function isDate(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || Number(value.slice(0, 4)) < 1000) return false;
    const date = new Date(`${value}T00:00:00Z`);
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function timestamp(value, label) {
    const s = text(value, label, 35);
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(s) || !isDate(s.slice(0, 10)) || !Number.isFinite(Date.parse(s)) || Number(s.slice(11, 13)) > 23) {
        throw new BackupError(`${label} must be a valid timestamp with a timezone.`);
    }
    return s;
}
function order(value, index, strict) {
    const label = `Order ${index + 1}`;
    const row = object(value, label);
    if (strict) onlyKeys(row, ORDER_KEYS, label);
    const id = text(row.id, `${label} ID`, 128);
    if (!/^[A-Za-z0-9][A-Za-z0-9_.:-]*$/.test(id)) throw new BackupError(`${label} has an invalid ID.`);
    if (!isDate(row.orderDate)) throw new BackupError(`${label} has an invalid order date.`);
    if (!Number.isSafeInteger(row.windowDays) || row.windowDays < 1 || row.windowDays > 3_700_000 || !isDate(dueDate(row.orderDate, row.windowDays))) throw new BackupError(`${label} has an invalid return window.`);
    if (![
        'policy',
        'default',
        'user'
    ].includes(row.windowSource)) throw new BackupError(`${label} has an invalid window source.`);
    return {
        id,
        merchant: text(row.merchant, `${label} store`),
        orderNo: row.orderNo === undefined ? '' : text(row.orderNo, `${label} number`),
        total: row.total === undefined ? '' : text(row.total, `${label} total`),
        orderDate: row.orderDate,
        windowDays: row.windowDays,
        windowSource: row.windowSource,
        createdAt: timestamp(row.createdAt, `${label} creation time`)
    };
}
function orders(value, strict = true) {
    if (!Array.isArray(value) || value.length > MAX_BACKUP_ORDERS) throw new BackupError(`Expected at most ${MAX_BACKUP_ORDERS.toLocaleString('en-US')} saved orders.`);
    const seen = new Set();
    return value.map((value, index)=>{
        const row = order(value, index, strict);
        if (seen.has(row.id)) throw new BackupError(`Order ${index + 1} repeats an ID in this list.`);
        seen.add(row.id);
        return row;
    });
}
function document(rows, exportedAt) {
    return {
        schema: 'returnby.backup',
        version: 1,
        exportedAt,
        orders: rows
    };
}
function fits(output) {
    return encoder.encode(output).byteLength <= MAX_BACKUP_BYTES;
}
function portable(rows, message) {
    if (!fits(JSON.stringify(document(rows, SIZE_TIMESTAMP)) + '\n')) throw new BackupError(message);
}
export function exportBackup(current, now = new Date()) {
    const doc = document(orders(current, false), now.toISOString());
    let output = JSON.stringify(doc, null, 2) + '\n';
    if (!fits(output)) output = JSON.stringify(doc) + '\n';
    if (!fits(output)) throw new BackupError('This backup is larger than the 5 MiB import limit.');
    return output;
}
export function parseBackup(input) {
    if (encoder.encode(input).byteLength > MAX_BACKUP_BYTES) throw new BackupError('Choose a backup no larger than 5 MiB.');
    let parsed;
    try {
        parsed = JSON.parse(input);
    } catch  {
        throw new BackupError('This file is not valid JSON. Choose a ReturnBy backup.');
    }
    const doc = object(parsed, 'Backup');
    if (doc.schema !== 'returnby.backup' || doc.version !== 1) throw new BackupError('This backup format or version is not supported.');
    onlyKeys(doc, [
        'schema',
        'version',
        'exportedAt',
        'orders'
    ], 'Backup');
    timestamp(doc.exportedAt, 'Backup export time');
    const rows = orders(doc.orders);
    portable(rows, 'The normalized saved details would exceed the 5 MiB backup limit.');
    return rows;
}
export function planImport(current, incoming) {
    const saved = orders(current);
    const imported = orders(incoming);
    const byId = new Map(saved.map((row)=>[
            row.id,
            row
        ]));
    const rows = imported.map((row)=>{
        const old = byId.get(row.id);
        const changedFields = old ? ORDER_KEYS.filter((key)=>old[key] !== row[key]) : [];
        return {
            order: row,
            action: !old ? 'add' : changedFields.length ? 'conflict' : 'skip',
            changedFields
        };
    });
    const additions = rows.filter((row)=>row.action === 'add').map((row)=>row.order);
    if (saved.length + additions.length > MAX_BACKUP_ORDERS) throw new BackupError(`The combined tracker would exceed ${MAX_BACKUP_ORDERS.toLocaleString('en-US')} orders.`);
    const conflicts = rows.filter((row)=>row.action === 'conflict').length;
    const next = conflicts ? saved : [
        ...saved,
        ...additions
    ];
    if (!conflicts && additions.length) portable(next, 'The combined tracker would exceed the 5 MiB backup limit.');
    return {
        rows,
        added: additions.length,
        skipped: rows.filter((row)=>row.action === 'skip').length,
        conflicts,
        snapshot: JSON.stringify(saved),
        next
    };
}
