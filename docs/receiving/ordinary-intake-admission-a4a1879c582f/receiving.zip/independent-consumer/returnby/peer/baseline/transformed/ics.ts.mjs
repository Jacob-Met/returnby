const esc = (s)=>s.replace(/\\/g, '\\\\').replace(/\r\n|\r|\n/g, '\\n').replace(/[,;]/g, (c)=>'\\' + c).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '\ufffd');
const encoder = new TextEncoder();
function fold(line) {
    let output = '', bytes = 0;
    for (const character of line){
        const size = encoder.encode(character).byteLength;
        if (bytes + size > 75) {
            output += '\r\n ';
            bytes = 1;
        }
        output += character;
        bytes += size;
    }
    return output;
}
function eventLines(o, ts) {
    const d = o.due.replace(/-/g, '');
    const end = new Date(+o.due.slice(0, 4), +o.due.slice(5, 7) - 1, +o.due.slice(8, 10) + 1);
    const e = `${end.getFullYear()}${String(end.getMonth() + 1).padStart(2, '0')}${String(end.getDate()).padStart(2, '0')}`;
    const title = esc(`Return deadline: ${o.merchant || 'order'}${o.orderNo ? ' #' + o.orderNo : ''}`);
    return [
        'BEGIN:VEVENT',
        `UID:${esc(o.id)}@returnby`,
        `DTSTAMP:${ts}`,
        `DTSTART;VALUE=DATE:${d}`,
        `DTEND;VALUE=DATE:${e}`,
        `SUMMARY:${title}`,
        'BEGIN:VALARM',
        'ACTION:DISPLAY',
        `DESCRIPTION:${title}`,
        'TRIGGER:-P3D',
        'END:VALARM',
        'END:VEVENT'
    ];
}
export function buildIcsCalendar(reminders, stamp = new Date()) {
    const ts = stamp.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    return [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//ReturnBy//EN',
        'CALSCALE:GREGORIAN',
        ...reminders.flatMap((reminder)=>eventLines(reminder, ts)),
        'END:VCALENDAR',
        ''
    ].map(fold).join('\r\n');
}
export function buildIcs(o, stamp = new Date()) {
    return buildIcsCalendar([
        o
    ], stamp);
}
