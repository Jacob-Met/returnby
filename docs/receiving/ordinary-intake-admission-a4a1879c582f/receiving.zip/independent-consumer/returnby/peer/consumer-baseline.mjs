import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { stripTypeScriptTypes } from 'node:module';
const sha256=s=>createHash('sha256').update(s).digest('hex');
const git=s=>createHash('sha1').update('blob '+Buffer.byteLength(s)+'\0').update(s).digest('hex');
const expected={'deadline.ts':'bcef920c0f9846b789b1a0aa01b833c7d99ba5d4','ics.ts':'58c873a116ed6b265864cb3e7d5b0dd27fd81544','backup.ts':'bdd86ce50c723abf8f1d305d4fdf63353510eba8'};
const sources={},transforms={};
for(const [p,b]of Object.entries(expected)){sources[p]=readFileSync(new URL('./source/'+p,import.meta.url),'utf8');assert.equal(git(sources[p]),b);transforms[p]=stripTypeScriptTypes(sources[p],{mode:'transform',sourceMap:false});}
const data=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
const deadlineURL=data(transforms['deadline.ts']);
assert.equal((transforms['backup.ts'].match(/from '\.\/deadline'/g)||[]).length,1);
const linkedBackup=transforms['backup.ts'].replace("from './deadline'","from '"+deadlineURL+"'");
for(const [p,s]of Object.entries(transforms))writeFileSync(new URL('./transformed/'+p+'.mjs',import.meta.url),s);
writeFileSync(new URL('./transformed/backup-linked.mjs',import.meta.url),linkedBackup);
const {dueDate}=await import(deadlineURL),{buildIcs}=await import(data(transforms['ics.ts'])),{exportBackup,parseBackup}=await import(data(linkedBackup));
const start=new Date().toISOString(),stamp=new Date('2026-10-08T22:00:00.000Z');
const receipt={scope:'constructed-row native consumer baseline only; no actual UI Save/browser/Vite',base:'7829e56e57ef91dfe8edd5853fd68d6c7890fac0',node:process.version,tz:process.env.TZ,start,source:Object.fromEntries(Object.keys(sources).map(p=>[p,{git_blob:git(sources[p]),sha256:sha256(sources[p])}])),transform:{api:"node:module.stripTypeScriptTypes(mode:'transform')",hashes:Object.fromEntries(Object.entries(transforms).map(([p,s])=>[p,sha256(s)])),backupLink:'sole dependency specifier replaced with exact native deadline data URL',linkedBackupSha256:sha256(linkedBackup)},groups:[],artifacts:{}};
const literal={id:'admission-peer-1',merchant:' Café 雪 <literal> ',orderNo:'#R,"A"',total:'€17,20 literal',createdAt:'2026-10-08T21:00:00.000Z',windowSource:'user'};
const put=(p,s)=>{writeFileSync(new URL('./output/'+p,import.meta.url),s);receipt.artifacts[p]={bytes:Buffer.byteLength(s),sha256:sha256(s)};};
const normal=(label,date,raw,expectedDue)=>{
 // Exact ordinary-handler numeric expression; this is a constructed row, not a DOM event.
 const days=Number(raw)||30,row={...literal,orderDate:date,windowDays:days},before=JSON.stringify(row);
 const due=dueDate(date,days);assert.equal(due,expectedDue);
 const backup=exportBackup([row],stamp);assert.deepEqual(parseBackup(backup),[row]);
 const ics=buildIcs({...row,due},stamp);assert(ics.includes('DTSTART;VALUE=DATE:'+due.replaceAll('-','')));
 assert.match(ics,/DTEND;VALUE=DATE:\d{8}\r\n/);assert.equal(JSON.stringify(row),before);
 put(label+'.json',backup);put(label+'.ics',ics);
 receipt.groups.push({name:label,pass:true,raw,days,due,backupRoundtrip:true});return row;
};
normal('ordinary-literal','2026-10-08','30','2026-11-07');
normal('scientific-numeric','2026-10-08','1e2','2027-01-16');
normal('blank-fallback','2026-10-08','','2026-11-07');
normal('leap-day','2024-02-28','1','2024-02-29');
normal('year-rollover','2026-12-31','1','2027-01-01');
const overflow=[];
for(const days of [1000000000,1000000000000]){const row={...literal,orderDate:'2026-10-08',windowDays:days},due=dueDate(row.orderDate,days);assert.equal(due,'NaN-NaN-NaN');const ics=buildIcs({...row,due},stamp);assert(ics.includes('DTSTART;VALUE=DATE:NaNNaNNaN'));assert(ics.includes('DTEND;VALUE=DATE:NaNNaNNaN'));let error;try{exportBackup([row],stamp);}catch(e){error={name:e.name,message:e.message};}assert.match(error.message,/invalid return window/);put('overflow-'+days+'.ics',ics);overflow.push({days,due,backupError:error});}
receipt.groups.push({name:'overflow-rejected-by-native-backup',pass:true,observed:overflow});
{
 const row={...literal,orderDate:'9999-12-30',windowDays:1},due=dueDate(row.orderDate,1);
 assert.equal(due,'9999-12-31');const backup=exportBackup([row],stamp);assert.deepEqual(parseBackup(backup),[row]);
 const ics=buildIcs({...row,due},stamp);assert(ics.includes('DTEND;VALUE=DATE:100000101'));
 put('terminal-date.json',backup);put('terminal-date.ics',ics);
 receipt.groups.push({name:'terminal-day-backup-is-weaker-than-calendar-admission',pass:true,due,backupAdmitted:true,end:ics.match(/DTEND;VALUE=DATE:([^\r]+)/)[1]});
}
{
 const row={...literal,merchant:'雪'.repeat(4096),orderDate:'2026-10-08',windowDays:30},backup=exportBackup([row],stamp);assert.deepEqual(parseBackup(backup),[row]);
 let error;try{exportBackup([{...row,merchant:row.merchant+'X'}],stamp);}catch(e){error={name:e.name,message:e.message};}
 assert.match(error.message,/at most 4096/);
 receipt.groups.push({name:'text-byte-preservation-and-native-character-boundary',pass:true,characters:4096,utf8Bytes:Buffer.byteLength(row.merchant),refusal:error});
}
receipt.end=new Date().toISOString();receipt.pass=receipt.groups.every(x=>x.pass);receipt.groupCount=receipt.groups.length;
put('RECEIPT.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({pass:receipt.pass,groups:receipt.groupCount,source:receipt.source,scope:receipt.scope}));
