# ReturnBy owner application

## Subject and behavior

Apply `RECEIVING.patch` with `SOURCE-MANIFEST.json` to receiving source `7829e56e57ef91dfe8edd5853fd68d6c7890fac0`, canonical tree `b28e7b706fe67fd4b34111badd581c6bdd2ed4a7`. Verify the three existing beforeimages and absence of `src/order-admission.ts`. This is the complete receiving graph containing backup, editor and calendar consumers; matching filenames from another graph are insufficient.

The packet contains three production changes and one inert fixture adaptation:

- `src/order-admission.ts` extracts the existing editor field validator, `EditDraft` and `EditError`.
- `src/edit.ts` delegates validation and reexports the same type and error constructor. `EditConflict` retains that constructor identity. The editor's decimal-digit syntax and policy, identity and conflict handling remain intact.
- `src/main.ts` checks native number validity, then shared admission before policy lookup, fresh-store read, UUID/time generation and persistence. Errors use native custom validity and focus. Any intake input clears all custom messages, so correcting the order date can resolve a window error.
- `tests/helpers/storage-fixture.mjs` adds known preview controls with live field getters/setters, `elements.namedItem`, the supported `input` query and custom-validity methods. Live getters preserve whole-object field replacement and retries. This inert fixture does not model native number/date/type/min/step constraints; maintained assertions remain unchanged.

Keep reviewed merchant, order number and total text literal, including whitespace. Retain the shared consumer limits: 4,096 characters, Gregorian dates in years 1000–9999, safe positive whole windows up to 3,700,000, and four-digit due/end dates. Preserve the distinction between native `badInput` and a genuinely blank optional control: blank means 30 days; valid numeric forms such as `1e2` and `30.0` retain their numerical meaning.

## Exact application or later composition

After checking the manifest's beforeimages in the owner-controlled receiving directory:

```sh
git apply --check --whitespace=error /absolute/path/to/RECEIVING.patch
git apply --whitespace=error /absolute/path/to/RECEIVING.patch
sha256sum src/order-admission.ts src/edit.ts src/main.ts tests/helpers/storage-fixture.mjs
```

Compare all resulting sizes, SHA256 values and Git blob identities with the manifest. The 8,269-byte patch concatenates the exact 6,908-byte production patch and 1,361-byte fixture patch across four disjoint file sections; retain the original components alongside it.

If the owner has composed later changes, inspect the affected spans. Integrate the validator import, intake error clearing, native-number guard and pre-persistence admission/error handling while preserving surrounding owner parser/replacement hooks, submitted-policy behavior, fresh-store handling, persistence and draft retirement. Apply the editor extraction and fixture controls with the same local-span discipline. Resolve context mismatches in owned source instead of replacing whole files. Give composed bytes their own identity and qualification; original whole-file pins apply only to exact-base application.

## Native build and maintained suite

Use existing dependencies matched to the receiving lockfile. From the applied directory:

```sh
RETURNBY_NODE=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node
"$RETURNBY_NODE" ./node_modules/typescript/bin/tsc --noEmit
"$RETURNBY_NODE" ./node_modules/vite/bin/vite.js build
"$RETURNBY_NODE" ./node_modules/vitest/vitest.mjs run --maxWorkers=1
```

Record commands, exits, stdout/stderr and source bindings. Identify the inert `.mjs` fixture separately from the compiled product graph. Use the final verification/handoff receipt to identify executed qualification; use actual browser evidence for form acceptance, downloads and storage behavior.

## Frozen native consumer witness

Use the driver and original build receipts identified in `SOURCE-MANIFEST.json`, with the original browser README. Materialize separate `base` and `candidate` directories, each containing `BUILD-RECEIPT.json`, all 44/45 receipt-bound source inputs, and the complete six-file `dist` from `build_files[].archive_member`. Include shared public captures and favicon.

The frozen candidate browser receipt requires the original **3,025-byte base storage fixture**. The packet's **4,007-byte fixture** is a separate maintained-test adaptation. Select historical browser inputs by required SHA/size, using only the three candidate production overlays. Exact owner application and historical browser reproduction therefore use distinct fixture selections. For a later composed product, bind and review new source/build receipts under their own identity instead of reusing original pins.

Run the exact witness in one owned temporary invocation using the existing Node `v24.19.0`, Playwright `1.62.1` and pinned Chromium; replace placeholders with real absolute paths:

```sh
RETURNBY_NODE=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node
env RETURNBY_SUBJECTS=/dev/<owned>/subjects \
  RETURNBY_WORK=/dev/<owned>/runtime \
  RETURNBY_EVIDENCE=/dev/<owned>/evidence \
  RETURNBY_PLAYWRIGHT=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs \
  RETURNBY_CHROME=/workspace/scratch/a4a1879c582f/t95-receiving/browser/chromium \
  "$RETURNBY_NODE" /absolute/path/to/check_native_admission_receiving.mjs
```

The driver creates `TMPDIR` under its owned runtime and uses `--disable-dev-shm-usage`. Keep the evidence directory fresh. Capture exit/stdout/stderr and retain the complete receipt and original downloads before cleanup, including the first failure if one occurs. Native Save, Backup/file import and calendar controls, with native Date intact, supply the consumer witness. The final verification/handoff receipt records the executed result for the exact bound subjects.
