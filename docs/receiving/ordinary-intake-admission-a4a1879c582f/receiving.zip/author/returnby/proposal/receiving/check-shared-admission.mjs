import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve, extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { registerHooks, stripTypeScriptTypes } from 'node:module';

const proposed = resolve(process.argv[2]);
const baseline = resolve(process.argv[3]);
registerHooks({
  resolve(specifier, context, next) {
    if (specifier.startsWith('.') && context.parentURL?.endsWith('.ts') && !extname(specifier)) {
      return next(new URL(specifier + '.ts', context.parentURL).href, context);
    }
    return next(specifier, context);
  },
  load(url, context, next) {
    if (url.startsWith(pathToFileURL(proposed + '/').href) && url.endsWith('.ts')) {
      return { format: 'module', source: stripTypeScriptTypes(readFileSync(new URL(url), 'utf8'),
        { mode: 'transform', sourceUrl: url }), shortCircuit: true };
    }
    return next(url, context);
  }
});
const { validateOrderFields, EditError } = await import(pathToFileURL(resolve(proposed, 'src/order-admission.ts')));
const { dueDate } = await import(pathToFileURL(resolve(proposed, 'src/deadline.ts')));
const results = [];
const check = (name, run) => { run(); results.push({ name, status: 'PASS' }); };
const draft = () => ({ merchant: '  Fictional <store> 雪  ', orderNo: ' #001 ', total: 'USD 20.00',
  orderDate: '2026-10-08', windowDays: '30' });
const refuses = (value, field, message) => {
  assert.throws(() => validateOrderFields(value), error =>
    error instanceof EditError && error.field === field && (!message || error.message === message));
};
try {
  check('extraction retains exact original type, error, date predicate, validation and editor suffix', () => {
    const original = readFileSync(resolve(baseline, 'src/edit.ts'), 'utf8');
    const shared = readFileSync(resolve(proposed, 'src/order-admission.ts'), 'utf8');
    const editor = readFileSync(resolve(proposed, 'src/edit.ts'), 'utf8');
    for (const [begin, end] of [
      ['export type EditDraft', 'export class EditConflict'],
      ['function isCalendarDate', '/** Review one saved order'],
      ['  for (const [field, label]', '  // An unrelated correction']
    ]) assert.ok(shared.includes(original.slice(original.indexOf(begin), original.indexOf(end))), begin);
    assert.equal(editor.slice(editor.indexOf('  // An unrelated correction')),
      original.slice(original.indexOf('  // An unrelated correction')));
    const priorMain = readFileSync(resolve(baseline, 'src/main.ts'), 'utf8');
    const nextMain = readFileSync(resolve(proposed, 'src/main.ts'), 'utf8');
    assert.equal(nextMain.slice(nextMain.indexOf('function render()')),
      priorMain.slice(priorMain.indexOf('function render()')));
    const start = 'function showPreview()', end = "\npreview.addEventListener('submit'";
    const oldPreview = priorMain.slice(priorMain.indexOf(start), priorMain.indexOf(end)).trimEnd();
    assert.ok(nextMain.includes(oldPreview));
  });
  check('accepted ordinary fields preserve native due and caller text without mutation', () => {
    const value = Object.freeze(draft()), before = JSON.stringify(value);
    const result = validateOrderFields(value);
    assert.deepEqual(result, { days: 30, due: '2026-11-07' });
    assert.equal(result.due, dueDate(value.orderDate, result.days));
    assert.equal(JSON.stringify(value), before);
  });
  check('minimum calendar range and final reminder-compatible deadline are admitted', () => {
    assert.deepEqual(validateOrderFields({ ...draft(), orderDate: '1000-01-01', windowDays: '1' }),
      { days: 1, due: '1000-01-02' });
    assert.deepEqual(validateOrderFields({ ...draft(), orderDate: '9999-12-29', windowDays: '1' }),
      { days: 1, due: '9999-12-30' });
    refuses({ ...draft(), orderDate: '9999-12-30', windowDays: '1' }, 'windowDays',
      'The return deadline must be before 9999-12-31 so its calendar reminder has a valid end date.');
  });
  check('each text error retains original field-specific EditError message and precedence', () => {
    for (const [field, label] of [['merchant', 'Store'], ['orderNo', 'Order number'], ['total', 'Total']]) {
      assert.doesNotThrow(() => validateOrderFields({ ...draft(), [field]: 'x'.repeat(4096) }));
      refuses({ ...draft(), [field]: 'x'.repeat(4097), orderDate: '' }, field,
        label + ' must be no longer than 4,096 characters.');
    }
  });
  check('existing editor lexical refusal remains strict while admitted intake numeric values are canonical', () => {
    for (const raw of ['1e2', '30.0', '']) refuses({ ...draft(), windowDays: raw }, 'windowDays');
    for (const [raw, expected] of [['1e2', 100], ['30.0', 30], ['', 30]]) {
      const normalized = String(raw === '' ? 30 : Number(raw));
      assert.equal(validateOrderFields({ ...draft(), windowDays: normalized }).days, expected);
    }
    // This checks the explicit normalization value, not browser input or Save.
  });
  check('huge/nonfinite/fractional/zero/negative windows and malformed dates refuse', () => {
    for (const windowDays of ['1000000000', '1000000000000', 'Infinity', 'NaN', '1.5', '0', '-1']) {
      refuses({ ...draft(), windowDays }, 'windowDays');
    }
    for (const orderDate of ['', '0999-12-31', '2025-02-29', '2026-13-01']) {
      refuses({ ...draft(), orderDate }, 'orderDate');
    }
  });
  console.log(JSON.stringify({ schema: 'returnby.isolated-admission.pure-receiving.v1', status: 'PASS',
    node: process.version, execution: 'Actual retained TypeScript transformed in memory by node:module; complete shared-helper→deadline graph only.',
    checks: results, fullEditorRuntime: 'UNRUN: policy graph unavailable', viteBuild: 'UNRUN', browser: 'UNRUN',
    ownership: 'Local proposed source; public reservation and owner coordination pending.' }, null, 2));
} catch (error) {
  console.log(JSON.stringify({ schema: 'returnby.isolated-admission.pure-receiving.v1', status: 'FAIL',
    checks: results, error: { message: error.message, stack: error.stack } }, null, 2));
  process.exitCode = 1;
}
