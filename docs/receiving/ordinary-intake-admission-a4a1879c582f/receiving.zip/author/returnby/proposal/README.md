# Isolated ReturnBy intake admission proposal

This is local proposed source against the owned #20 receiving base7829e56e57ef91dfe8edd5853fd68d6c7890fac0. It is not an estate reservation, accepted owner change, integration or deployment. Public coordination/access and the complete Vite/browser graph remain unavailable.

The shared order-admission module contains the exact existing EditDraft, EditError, date predicate and validation block from edit.ts. The editor imports and re-exports the same new shared constructor/type and delegates validation. The historical policy attribution, planEdit and sourceDescription suffix remains byte-identical.

Ordinary Save captures unchanged text fields and normalizes only the numerical window for this strict shared validator. Valid native numeric meanings such as1e2→100 and30.0→30 remain accepted. Because the existing optional blank window means30 days, the proposal intentionally retains blank→30. An invalid numeric native control is refused by its own validity check; zero/fractional/negative/nonfinite/oversized values cannot become a fabricated30-day default.

Admission precedes lookup, fresh tracker read, identity/time generation and persistence. A field-specific EditError sets native custom validity, reports and focuses that input, without altering the input value, saved orders or displayed tracker. Any intake input change clears custom messages across the intake because correcting orderDate may also resolve a window error. Existing native type/min/step constraints remain active.

The proposal does not change Parse, Sample, Ctrl+Enter, showPreview, persistence, policy lookup, parser, backup schema, calendar serialization, or existing saved rows. #31's stated replacement scope is preserved; its implementation source was not retained, so full composition compatibility is unproven.

Files:
- src/order-admission.ts — extracted pure validation, dependent only on unchanged deadline.ts.
- src/edit.ts — compatibility re-exports and one delegation before unchanged editor suffix.
- src/main.ts — intake preflight and native error clearing/presentation.
- src/deadline.ts is an unchanged receiving dependency, not a proposed change.

The standalone pure receiver transforms actual retained TypeScript in memory with Node24's node:module API. It has a complete shared-validator→deadline runtime graph. It does not stub policy or execute the incomplete editor/main graph. Full editor runtime, Vite build, actual native number/date controls and the Save/error/resubmit workflow remain UNRUN.

Run with Node24:
node returnby/proposal/receiving/check-shared-admission.mjs returnby/proposal returnby/source/receiving-7829e56

The receiving script's normalization-value assertions do not claim browser or Save acceptance. Original cached sources, the sealed preimplementation oracle and the exact patch are retained alongside the proposal.
