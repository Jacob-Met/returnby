# ReturnBy consumer admission oracle — sealed before implementation

Scope: independent source-only consumer review by estate-a4a1879c582f/estate_evidence. Gap and ownership discovery remains with source_discovery; actual browser admission baseline belongs to publication_review. No new implementation, saved-record mutation or runtime probe is represented here.

Authority:
- Current main 1e662c387be5f66f8499fac7ec443f58d2198379, tree503ea217dc35f54aa7c9dbd1f92217544ad6dbc9.
- Owned #20 receiving source7829e56e57ef91dfe8edd5853fd68d6c7890fac0. The backup and edit modules exist at this receiving source; the complete current-main tree has neither module. Do not describe the backup as currently deployed.
- Exact per-file Git identities are in SOURCE-MANIFEST.json.

Sealed expectations, transmitted to root and both workers before any implementation:
1. A newly admitted ordinary purchase retains its intended merchant, order-number and total text without unrelated normalization; each saved field is within the native4096-character consumer bounds.
2. The order date is an actual Gregorian YYYY-MM-DD with year1000–9999, as existing backup/edit admission defines.
3. Return-window days are a safe positive whole number no greater than3,700,000. Native edit additionally requires decimal-digit draft syntax; no new syntax claim about ordinary intake has been adopted.
4. The unchanged native dueDate result and its next-day calendar end are valid four-digit dates. Backup admission alone is weaker than edit: due9999-12-31 passes backup's date test but edit rejects it because its next-day reminder end crosses the year boundary.
5. An accepted record preserves generated identity/creation time and existing store-policy/default/user attribution semantics. Existing stored records are not silently rewritten or repaired.
6. Refusal preserves the prior saved bytes, editable intake and displayed tracker. Successful ordinary/leap/year-rollover cases retain native deadline results; at the owned receiving source they must also preserve order data through exportBackup then parseBackup.

Witness quality:
- The source-grounded simple candidate is the finite safe integer window1000000000 with an otherwise ordinary valid order. Current input has type=number,min=1 and no maximum; submit uses Number(value)||30 and persists it. It is an inference from source that this can reach an unrepresentable deadline.
- The browser receiver must establish actual native form validity and a real Save action before claiming the defect. A synthetic submit that bypasses form validation is insufficient.
- Current deadline/ICS consumption is the primary product witness. Prospective owned backup refusal is a separate receiving compatibility consequence.
- Invalid dates rejected by the native date control must not be used as evidence that ordinary users can save them. Do not add unsupported text restrictions, change local-calendar arithmetic, broaden backup schema, or claim owner takeover.

No native numerical or browser result is claimed by this oracle. GitHub reads later returned403 rate limit; source discovery is paused rather than bypassed.
