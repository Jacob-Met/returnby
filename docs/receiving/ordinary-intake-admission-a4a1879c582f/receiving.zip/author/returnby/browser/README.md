# Frozen ReturnBy native ordinary-admission receiver

This is one author-prepared native browser receiving driver for the independent browser reviewer. It does not change production source, build configuration, source adapters, the existing browser installation, ownership, refs, workflows or the proposed source freeze. The author has not launched Chromium. All native outcomes remain UNRUN at this freeze.

## Exact subject

Base ancestry is source7829e56e57ef91dfe8edd5853fd68d6c7890fac0, canonical treeb28e7b706fe67fd4b34111badd581c6bdd2ed4a7, the owner #20 receiving subject. This is proposed receiving behavior, not a claim about deployed current main.

The candidate is the same complete graph with only the three reviewed overlay files:

- src/main.ts: e5e63342bd6aefdb93ff497e73d61448e3dfae8231a83d722dec63ca87c4871c
- src/edit.ts: 324b8b4d51275296a3000f10ee0efc2248741326b1651ef2c659ec3db97f9302
- src/order-admission.ts: 6251cd1e8334bf4fd15aeb5ed95ee7d4022fd1578f283134b9f449132cfc40f1

Actual Vite-build receipt pins:

- base: ecc3e1d8de9bffbd2a09a1ea7bf16f16b43aaa640584c476586bc193b490ca3b
- candidate: f48e89594fef7ad7e36e27cbe7b83650acfa2b8aa3f7916f2ceb7a36feaa66dd

The driver verifies every source-file byte count, SHA256 and Git blob (44 baseline, 45 candidate); the exact receipt, unchanged source_after list and successful build result; and the entire six-file dist inventory. It serves those original dist bytes, records hashes for every response, and repeats source/build verification after the attempt. CSS and JS adapters, source transpilation, source substitution and fixture changes are excluded by the exact built-byte inventory. The original maintained candidate test failure is explicitly retained as test_exit_code1 in the input binding; this browser run does not relabel the inert-fixture run as passing.

## Native scope and claim limits

The single baseline history starts from an empty disposable context, enters fictional confirmation text and the normal date2026-10-03/window1000000000, captures native validity and all reviewed strings, then clicks the visible Save button. A native constraint refusal or failure to admit is retained and stops the run. There is no replacement baseline history, synthetic submit, direct storage injection or invalid-event bypass. If admitted, the exact saved bytes, retired intake and rendered NaN deadline are observed, then the unchanged Backup control must produce its actual invalid-window diagnostic with no object-URL allocation or download event during the bounded500ms observation.

The candidate uses the identical draft in another empty context. It must refuse with native window custom validity/focus, unchanged storage null, exact paste/field retention and unchanged tracker. Correcting window to30 must clear validity and permit native Save, followed immediately by an actual strict Backup download.

A second draft exercises the interdependent error:9999-12-01 plus30 reaches the prohibited terminal deadline; native Save must refuse on the window and retain the first saved record. Correcting only orderDate to9999-11-30 must clear the window custom error, then native Save must retain exact text (including spaces, Unicode and markup characters), the earlier record, and a valid due9999-12-30. The unchanged per-card reminder control must download an actual ICS with start99991230 and end99991231. This is an unchanged consumer witness, not a civil-date extension or calendar-app import claim.

The intake-only numerical phases implement root's explicit additional request. Typing the incomplete exponent e with the keyboard must create actual Chromium badInput with an empty value string; visible Save must be blocked before submit, preserving state. Clearing it with keyboard selection/Backspace must produce a truly blank valid optional control and native Save30. Actual scientific1e2 Save100 and decimal30.0 Save30 are separate successful native histories. The decimal case also observes attribution to a submitted Northwind merchant, even though the original parser preview was Contoso. These are browser observations, not helpers presented as form acceptance.

The final actual Backup file (all five admitted records) is fed unchanged to the product's file input in a fresh empty context. Native preview and Import must restore byte-exact stored JSON, including generated IDs, native creation timestamps, original reviewed text and policy/default/user attribution. No pure exportBackup/parseBackup/deadline function is called by the driver. Leap/date/helper coverage and the existing full editor suite remain separate evidence; this is not a broad repetition of the original receiving runner.

## Instrumentation and evidence

The runner follows the actual owner runner's disposable contexts, loopback server, visible controls, real download capture and before/after source checks. Read-only document capture listeners record trusted clicks/submits and invalid events. Explicit snapshot calls to native checkValidity are tagged probe=true, so they cannot be confused with the actual Save validation path. The only native function wrappers are transparent Storage.setItem and URL.createObjectURL observers; they delegate the original functions with original receiver/arguments and never inject refusals or substitute return values. The driver does not wrap storage reads, crypto, FormData, HTMLFormControlsCollection, values or any product helper. It makes no zero-read or zero-UUID-allocation claim.

Date is fully native. There is no page.clock, fake Date or fixed browser time. The new contexts use the declared UTC timezone and en-US locale. No screenshots are required: evidence retains full raw storage, exact editable strings, native validity flags/messages/focus, form/tracker HTML and text, trusted event observations, saved-write bytes, object-URL metadata and original download bytes. This bounds the reviewer's reserve usage while retaining the causal native evidence.

browser-receipt.json is fsynced before each phase and in every phase's finally path, including first assertion or launch failure. The first failing phase captures current DOM/storage where available. Every download is saved separately, fsynced and re-read for byte/hash equality. The wrapper must retain the entire evidence directory plus process stdout/stderr/exit and materialization preflight even if the driver fails. If it fails before it can create the evidence directory, stdout/stderr and the wrapper's exception remain the evidence. Do not discard or rerun a failed attempt; review the retained result first.

## Existing execution environment

- Node: /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node, exactlyv24.19.0.
- Playwright import: /opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs (installed1.62.1); the driver pins this file and the installed package and playwright-core entrypoint/package bytes.
- Chromium: /workspace/scratch/a4a1879c582f/t95-receiving/browser/chromium, SHA25653a15d6c3a3d27dfb54c4ba60278b1683136f70cf1e67e989da7dfbd3d451ef0.
- Launch includes --disable-dev-shm-usage. Set RETURNBY_WORK to the reviewer's fresh owned /dev directory; the driver puts TMPDIR/profile support and downloads under it. Scratch and /dev/shm are full. No install, network probe or browser download is attempted.

Materialize inputs in a separate fresh owned directory with this structure:

    subjects/base/BUILD-RECEIPT.json
    subjects/base/<all44 source_files paths>
    subjects/base/dist/<all6 build_files paths>
    subjects/candidate/BUILD-RECEIPT.json
    subjects/candidate/<all45 source_files paths>
    subjects/candidate/dist/<all6 build_files paths>

Read the root native capsule's first LF-delimited JSON header, take exactly zip_bytes as the ZIP, verify its SHA256 against the header and the root's latest acknowledged pin, and run ZIP CRC verification. The root capsule at this driver freeze was receiving-reserve-returnby-native.bin, ZIP380890, SHA2569aba2ac473c07def722258b2b64d03e22d10a3c4f09bae14b6d9aa37265c1657, allocation727510. Root may retain later additional evidence; the exact input receipt hashes above remain mandatory.

For each subject, copy its build/<subject>/BUILD-RECEIPT.json. For each receipt.source_files entry, use candidate/<path> only for the three candidate overlay entries present in the ZIP; otherwise use base/<path>. Verify bytes/SHA256/Git blob before copying. For every receipt.build_files entry, copy its archive_member verbatim to dist/<entry.path>, verifying size/hash. The two public captures and favicon are shared base/public members, so extracting only build/<subject>/dist is incomplete. Do not use the separately adapted test fixture as a browser source input. Never rebuild or transcode during receiving.

Execute only after independent source/method review, once, from within the reviewer's owned temporary invocation, with stdout/stderr captured and all bytes checkpointed to that reviewer's reserve before cleanup:

    RETURNBY_SUBJECTS=/dev/<owned>/subjects
    RETURNBY_WORK=/dev/<owned>/runtime
    RETURNBY_EVIDENCE=/dev/<owned>/evidence
    RETURNBY_PLAYWRIGHT=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs
    RETURNBY_CHROME=/workspace/scratch/a4a1879c582f/t95-receiving/browser/chromium
    /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /dev/<owned>/check_native_admission_receiving.mjs

These are environment assignments for the wrapper's subprocess environment, not separate unexported shell settings. Only the independent browser reviewer owns Chromium execution and the resulting receipt. The author's check is syntax-only; no browser outcome is claimed here.
