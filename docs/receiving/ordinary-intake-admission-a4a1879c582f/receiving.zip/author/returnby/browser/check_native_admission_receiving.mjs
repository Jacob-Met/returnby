// Receive the frozen ordinary-admission proposal through real, unchanged Vite builds.
// Method reference: owner20/tools/check_actions_backup_calendar_receiving.mjs.
// Fictional orders, native controls, disposable loopback contexts; no source adapters.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, open, readFile, readdir } from 'node:fs/promises';
import { createServer } from 'node:http';
import { extname, resolve, sep, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const SOURCE_REF = '7829e56e57ef91dfe8edd5853fd68d6c7890fac0';
const SOURCE_TREE = 'b28e7b706fe67fd4b34111badd581c6bdd2ed4a7';
const RECEIPT_PINS = {
  base: 'ecc3e1d8de9bffbd2a09a1ea7bf16f16b43aaa640584c476586bc193b490ca3b',
  candidate: 'f48e89594fef7ad7e36e27cbe7b83650acfa2b8aa3f7916f2ceb7a36feaa66dd',
};
const CHROME_PIN = '53a15d6c3a3d27dfb54c4ba60278b1683136f70cf1e67e989da7dfbd3d451ef0';
const PLAYWRIGHT_ROOT = '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const PLAYWRIGHT_PINS = {
  'playwright/package.json': 'ca170ec143a88ed3043ac953eb3b2377b2b97304104f4e1e23316684ce2c35af',
  'playwright/index.mjs': 'a0f5715ea22354f922791a9c53dc012d5d5c067ff9cc4cd35ffb7cd272071a9f',
  'playwright-core/package.json': '07c47543631fef9508760365dee9fbe958c562093ec8d122543949ed231f233f',
  'playwright-core/index.mjs': '3d36e2132d3c8b62397d23f0bb4177336aaee503203ae2a2c90fbeb5bf3317dd',
};
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const gitBlob = bytes => createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
const errorValue = error => ({ name: error?.name, message: String(error?.message ?? error), stack: error?.stack });
const utc = () => new Date().toISOString();
const envPath = name => { assert(process.env[name], `${name} must name an owned, materialized directory`); return resolve(process.env[name]); };
// Set evidence first so input/launch failures can be retained. The wrapper must also
// retain stderr/exit status if this directory itself cannot be created.
const out = envPath('RETURNBY_EVIDENCE');
await mkdir(out, { recursive: true });
assert.deepEqual(await readdir(out), [], 'Use a fresh evidence directory; never overwrite an earlier attempt');
await mkdir(resolve(out, 'downloads'));
const report = {
  schema: 'returnby.native-admission-receiving.v1', status: 'running', started_at: utc(),
  source_ref: SOURCE_REF, source_tree: SOURCE_TREE,
  candidate_is_isolated_overlay: true, integrated_or_deployed: false,
  browser_date: 'Native Date; no clock installation, fixed time, fake timestamp or timezone arithmetic adapter',
  browser_scope: 'Desktop headless Chromium, locale en-US, timezone UTC; no physical device or calendar-app import claim',
  method_reference: { path: 'base/tools/check_actions_backup_calendar_receiving.mjs', sha256: '86e233c2262c2aa7718ede5ca8900003ae6b9eba463eaaf0b0e22c923e649b2a' },
  observation_method: 'Trusted click/submit and native invalid events; checkValidity probes explicitly tagged. Storage.setItem and URL.createObjectURL wrappers delegate original functions without faults. No read, UUID, FormData, elements, input-value, deadline, Date, or product-function overrides.',
  phases: [], contexts: [], downloads: [], served_requests: [], external_requests: [],
  application_errors: [], console_errors: [], capture_errors: [], artifacts: [], cleanup_errors: [],
};
const contexts = new Set(), servers = [], subjects = new Map(), downloadJobs = new Map(), downloadBodies = new Map();
let browser, activePage, failure;
async function durableWrite(path, bytes) {
  const handle = await open(path, 'w');
  try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
}
async function checkpoint() { await durableWrite(resolve(out, 'browser-receipt.json'), JSON.stringify(report, null, 2) + '\n'); }
async function shaFile(path) { const hash = createHash('sha256'); for await (const chunk of createReadStream(path)) hash.update(chunk); return hash.digest('hex'); }
function child(root, path) { const result = resolve(root, path); assert(result.startsWith(root + sep), `Outside subject: ${path}`); return result; }
async function files(root, relative = '') {
  const result = [];
  for (const entry of await readdir(resolve(root, relative), { withFileTypes: true })) {
    const path = relative ? `${relative}/${entry.name}` : entry.name;
    if (entry.isDirectory()) result.push(...await files(root, path));
    else { assert(entry.isFile(), `Unexpected non-file in dist: ${path}`); const bytes = await readFile(child(root, path)); result.push({ path, bytes: bytes.length, sha256: sha256(bytes) }); }
  }
  return result.sort((a, b) => a.path.localeCompare(b.path));
}
async function verifySubject(root, subject) {
  const receiptBytes = await readFile(resolve(root, 'BUILD-RECEIPT.json'));
  assert.equal(sha256(receiptBytes), RECEIPT_PINS[subject], `${subject}: exact actual-build receipt`);
  const receipt = JSON.parse(receiptBytes);
  assert.equal(receipt.schema, 'returnby.actual-native-build.v1'); assert.equal(receipt.subject, subject);
  assert.equal(receipt.source_ref, SOURCE_REF); assert.equal(receipt.source_tree, SOURCE_TREE);
  assert.equal(receipt.build_exit_code, 0); assert.equal(receipt.source_unchanged, true);
  assert.deepEqual(receipt.source_after, receipt.source_files);
  assert.equal(receipt.source_files.length, subject === 'base' ? 44 : 45);
  for (const entry of receipt.source_files) {
    const bytes = await readFile(child(root, entry.path));
    assert.equal(bytes.length, entry.bytes, `${subject}:${entry.path} byte count`);
    assert.equal(sha256(bytes), entry.sha256, `${subject}:${entry.path} SHA256`);
    assert.equal(gitBlob(bytes), entry.git_blob, `${subject}:${entry.path} Git blob`);
  }
  const build = resolve(root, 'dist'), inventory = await files(build);
  const expected = receipt.build_files.map(({ path, bytes, sha256 }) => ({ path, bytes, sha256 })).sort((a, b) => a.path.localeCompare(b.path));
  assert.equal(expected.length, 6); assert.deepEqual(inventory, expected, `${subject}: all original Vite dist bytes, with no added adapters`);
  const bodies = new Map(await Promise.all(inventory.map(async entry => [entry.path, await readFile(child(build, entry.path))])));
  return { root, build, receipt, bodies, binding: { subject, build_receipt_sha256: sha256(receiptBytes), source_ref: receipt.source_ref, source_tree: receipt.source_tree, source_overlay: receipt.source_overlay, source_files: receipt.source_files, build_files: receipt.build_files, maintained_test_exit_code: receipt.test_command.exit_code } };
}
async function serve(subject, input) {
  const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png' };
  const server = createServer((request, response) => {
    const entry = { subject, at: utc(), method: request.method, url: request.url };
    report.served_requests.push(entry);
    try {
      const path = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname.slice(1)) || 'index.html';
      const bytes = input.bodies.get(path);
      assert(bytes && ['GET', 'HEAD'].includes(request.method), 'Not an exact local build file');
      entry.path = path; entry.status = 200; entry.bytes = bytes.length; entry.sha256 = sha256(bytes);
      response.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream', 'Content-Length': bytes.length, 'Cache-Control': 'no-store' });
      response.end(request.method === 'HEAD' ? undefined : bytes);
    } catch (error) { entry.status = 404; entry.error = String(error.message); response.writeHead(404); response.end('Missing exact local build asset'); }
  });
  await new Promise((done, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', done); });
  servers.push(server);
  return `http://127.0.0.1:${server.address().port}`;
}
function observeNative() {
  const log = window.__returnbyReceiving = { phase: 'open', probing: false, events: [], writes: [], objectURLs: [] };
  const flags = input => Object.fromEntries(['badInput', 'customError', 'patternMismatch', 'rangeOverflow', 'rangeUnderflow', 'stepMismatch', 'tooLong', 'tooShort', 'typeMismatch', 'valid', 'valueMissing'].map(key => [key, input.validity[key]]));
  const detail = target => ({ id: target?.id || '', name: target?.name || '', text: target?.textContent || '' });
  document.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target.closest('button, summary') : null;
    if (target) log.events.push({ type: 'click', phase: log.phase, trusted: event.isTrusted, target: detail(target), at: performance.now() });
  }, true);
  document.addEventListener('submit', event => {
    log.events.push({ type: 'submit', phase: log.phase, trusted: event.isTrusted, form: event.target.id, submitter: detail(event.submitter), defaultPreventedAtCapture: event.defaultPrevented, at: performance.now() });
  }, true);
  document.addEventListener('submit', event => {
    log.events.push({ type: 'submit-bubble', phase: log.phase, trusted: event.isTrusted, form: event.target.id, defaultPrevented: event.defaultPrevented, at: performance.now() });
  });
  document.addEventListener('invalid', event => {
    const input = event.target;
    if (input instanceof HTMLInputElement && input.closest('#preview')) log.events.push({ type: 'invalid', phase: log.phase, probe: log.probing, trusted: event.isTrusted, field: input.name, value: input.value, validity: flags(input), validationMessage: input.validationMessage, at: performance.now() });
  }, true);
  document.addEventListener('input', event => {
    if (event.target instanceof HTMLInputElement && event.target.closest('#preview')) log.events.push({ type: 'input', phase: log.phase, trusted: event.isTrusted, field: event.target.name, at: performance.now() });
  }, true);
  const write = Storage.prototype.setItem, allocate = URL.createObjectURL;
  Storage.prototype.setItem = function(key, value) {
    if (key !== 'returnby.v1') return Reflect.apply(write, this, arguments);
    const entry = { phase: log.phase, value, accepted: false, at: performance.now() }; log.writes.push(entry);
    try { const result = Reflect.apply(write, this, arguments); entry.accepted = true; return result; }
    catch (error) { entry.error = { name: error.name, message: error.message }; throw error; }
  };
  URL.createObjectURL = function(blob) {
    const result = Reflect.apply(allocate, this, arguments);
    log.objectURLs.push({ phase: log.phase, url: result, type: blob.type, bytes: blob.size, at: performance.now() });
    return result;
  };
}
async function snapshot(page) {
  return page.evaluate(() => {
    const log = window.__returnbyReceiving, form = document.querySelector('#preview');
    const inputState = input => ({ value: input.value, valueAsNumber: String(input.valueAsNumber), type: input.type, min: input.min, max: input.max, step: input.step, required: input.required, willValidate: input.willValidate, validationMessage: input.validationMessage, validity: Object.fromEntries(['badInput', 'customError', 'patternMismatch', 'rangeOverflow', 'rangeUnderflow', 'stepMismatch', 'tooLong', 'tooShort', 'typeMismatch', 'valid', 'valueMissing'].map(key => [key, input.validity[key]])) });
    const fields = Object.fromEntries([...form.querySelectorAll('input')].map(input => [input.name, inputState(input)]));
    let formCheckValidity = null;
    log.probing = true;
    try { if (!form.hidden) formCheckValidity = form.checkValidity(); } finally { log.probing = false; }
    return {
      at: new Date().toISOString(), url: location.href, title: document.title,
      storage: { raw: localStorage.getItem('returnby.v1'), keys: Object.keys(localStorage).sort() },
      paste: document.querySelector('#paste').value,
      preview: { hidden: form.hidden, noValidate: form.noValidate, outerHTML: form.outerHTML, values: Object.fromEntries(Object.entries(fields).map(([name, field]) => [name, field.value])), fields, formCheckValidity },
      focus: { id: document.activeElement?.id || '', name: document.activeElement?.name || '', tag: document.activeElement?.tagName || '' },
      tracker: { html: document.querySelector('#list').innerHTML, text: document.querySelector('#list').textContent, counts: Object.fromEntries(['tracked-count', 'soon-count', 'expired-count'].map(id => [id, document.querySelector(`#${id}`).textContent])), cards: [...document.querySelectorAll('#list .card')].map(card => ({ id: card.querySelector('[data-edit]')?.dataset.edit, due: card.querySelector('.return-by')?.textContent, text: card.textContent, html: card.outerHTML })) },
      storageError: { hidden: document.querySelector('#storage-error').hidden, text: document.querySelector('#storage-error').textContent },
      backup: { open: document.querySelector('.backup-panel details').open, hidden: document.querySelector('#backup-message').hidden, message: document.querySelector('#backup-message').textContent, role: document.querySelector('#backup-message').getAttribute('role'), previewHidden: document.querySelector('#backup-preview').hidden, summary: document.querySelector('#backup-summary').textContent, rows: [...document.querySelectorAll('#backup-rows li')].map(row => row.textContent), applyDisabled: document.querySelector('#backup-apply').disabled },
      observations: { events: log.events, writes: log.writes, objectURLs: log.objectURLs },
    };
  });
}
async function phase(name, action) {
  report.active_phase = name;
  const entry = { name, status: 'running', started_at: utc() }; report.phases.push(entry);
  if (activePage && !activePage.isClosed()) await activePage.evaluate(value => { window.__returnbyReceiving.phase = value; }, name);
  await checkpoint();
  try { await action(entry); entry.status = 'pass'; }
  catch (error) {
    entry.status = 'fail'; entry.failure = errorValue(error);
    if (activePage && !activePage.isClosed()) {
      try { entry.failure_state = await snapshot(activePage); } catch (captureError) { entry.failure_state_error = errorValue(captureError); }
    }
    throw error;
  } finally { entry.ended_at = utc(); await checkpoint(); }
}
async function captureDownload(download, label) {
  const number = report.downloads.length + 1;
  const suggestedFilename = download.suggestedFilename();
  const name = `${String(number).padStart(2, '0')}-${suggestedFilename.replace(/[^A-Za-z0-9_.-]/g, '_')}`;
  const entry = { number, context: label, phase: report.active_phase, at: utc(), suggestedFilename, url: download.url(), path: `downloads/${name}` };
  report.downloads.push(entry);
  try {
    const failed = await download.failure(); assert.equal(failed, null, `Native download failed: ${failed}`);
    const sourcePath = await download.path(); assert(sourcePath, 'Native download provided no file');
    const bytes = await readFile(sourcePath);
    await durableWrite(resolve(out, entry.path), bytes);
    const retained = await readFile(resolve(out, entry.path)); assert.deepEqual(retained, bytes);
    entry.bytes = bytes.length; entry.sha256 = sha256(bytes); entry.retained_sha256 = sha256(retained); entry.status = 'captured';
    downloadBodies.set(download, bytes); report.artifacts.push({ path: entry.path, bytes: entry.bytes, sha256: entry.sha256 });
  } catch (error) { entry.status = 'capture-failed'; entry.failure = errorValue(error); report.capture_errors.push(entry.failure); }
}
async function newPage(subject, label) {
  const input = subjects.get(subject);
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true, locale: 'en-US', timezoneId: 'UTC', serviceWorkers: 'block' });
  contexts.add(ctx); report.contexts.push({ label, subject, origin: input.origin, storageStateSupplied: false });
  await ctx.route('**/*', route => {
    const url = route.request().url();
    if (new URL(url).origin === input.origin) return route.continue();
    report.external_requests.push({ context: label, url }); return route.abort();
  });
  await ctx.addInitScript(observeNative);
  ctx.on('page', page => {
    page.on('pageerror', error => report.application_errors.push({ context: label, phase: report.active_phase, ...errorValue(error) }));
    page.on('console', message => { if (message.type() === 'error') report.console_errors.push({ context: label, phase: report.active_phase, message: message.text() }); });
    page.on('download', download => { const job = captureDownload(download, label); downloadJobs.set(download, job); });
  });
  const page = await ctx.newPage(); activePage = page; page.setDefaultTimeout(10000);
  await page.goto(input.origin, { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(value => { window.__returnbyReceiving.phase = value; }, report.active_phase);
  return { ctx, page };
}
async function closeContext(ctx) { await ctx.close(); contexts.delete(ctx); if (activePage?.isClosed()) activePage = undefined; }
const PASTE = 'From: Contoso Electronics <orders@example.test>\nOrder #CT-48131\nOrder placed October 3, 2026\nSubtotal: $50.00\nShipping: $5.00\nTotal: $55.00\nFictional private paste token RETURNBY_NATIVE_DRAFT_ONLY';
const normalFields = { merchant: 'Contoso Electronics', orderDate: '2026-10-03', orderNo: 'NATIVE-HUGE', total: '$55.00', windowDays: '1000000000' };
const field = (page, name) => page.locator(`#preview [name=${name}]`);
async function draft(page, values) {
  await page.locator('#paste').fill(PASTE); await page.locator('#find').click();
  assert.equal(await field(page, 'total').inputValue(), '$55.00');
  assert.equal(await field(page, 'orderDate').inputValue(), '2026-10-03');
  assert.equal(await field(page, 'windowDays').inputValue(), '15');
  for (const [name, value] of Object.entries(values)) await field(page, name).fill(value);
}
const rows = state => JSON.parse(state.storage.raw || '[]');
const since = (before, after, type) => after.observations.events.slice(before.observations.events.length).filter(event => event.type === type);
function assertNativeSave(before, after, submits) {
  const clicks = since(before, after, 'click').filter(event => event.target.text === 'Save deadline to tracker');
  assert.equal(clicks.length, 1); assert.equal(clicks[0].trusted, true, 'Real visible Save click');
  const events = since(before, after, 'submit').filter(event => event.form === 'preview');
  assert.equal(events.length, submits);
  for (const event of events) assert.equal(event.trusted, true, 'Native submit event');
  if (submits) assert(since(before, after, 'submit-bubble').some(event => event.form === 'preview' && event.defaultPrevented), 'Product submit listener ran');
}
function assertRetained(before, after) {
  assert.equal(after.storage.raw, before.storage.raw, 'Exact saved bytes retained');
  assert.deepEqual(after.storage.keys, before.storage.keys);
  assert.equal(after.paste, before.paste, 'Exact pasted confirmation retained');
  assert.deepEqual(after.preview.values, before.preview.values, 'All reviewed field strings retained');
  assert.equal(after.preview.hidden, false); assert.deepEqual(after.tracker, before.tracker, 'Displayed tracker retained');
  assert.deepEqual(after.observations.writes, before.observations.writes, 'No observed storage.setItem attempt');
  assert.deepEqual(after.observations.objectURLs, before.observations.objectURLs, 'No observed object URL allocation');
}
function assertSaved(before, after, expected) {
  const previous = rows(before), current = rows(after);
  assert.equal(current.length, previous.length + 1); assert.deepEqual(current.slice(0, -1), previous, 'Every earlier saved record retained');
  const order = current.at(-1);
  for (const name of ['merchant', 'orderNo', 'total', 'orderDate']) assert.equal(order[name], before.preview.values[name], `${name}: exact reviewed text`);
  assert.equal(order.windowDays, expected.days); assert.equal(order.windowSource, expected.source);
  assert.match(order.id, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
  assert(!previous.some(row => row.id === order.id)); assert.match(order.createdAt, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/); assert(Number.isFinite(Date.parse(order.createdAt)));
  const writes = after.observations.writes.slice(before.observations.writes.length);
  assert.equal(writes.length, 1); assert.equal(writes[0].accepted, true); assert.equal(writes[0].value, after.storage.raw);
  assert.equal(after.preview.hidden, true); assert.equal(after.paste, ''); assert.equal(after.storageError.hidden, true);
  assert.equal(after.tracker.counts['tracked-count'], String(current.length));
  assert.equal(after.tracker.cards.find(card => card.id === order.id)?.due, `RETURN BY ${expected.due}`);
  assertNativeSave(before, after, 1);
  return order;
}
async function clickSave(page) { await page.locator('#preview button[type=submit]').click(); return snapshot(page); }
async function openBackup(page) { if (!await page.locator('.backup-panel details').evaluate(node => node.open)) await page.locator('#backup-heading').click(); }
async function download(page, action) {
  const [file] = await Promise.all([page.waitForEvent('download', { timeout: 10000 }), action()]);
  assert(downloadJobs.has(file)); await downloadJobs.get(file); assert(downloadBodies.has(file), 'Actual downloaded bytes retained');
  return downloadBodies.get(file);
}
function assertReadOnly(before, after) { assert.equal(after.storage.raw, before.storage.raw); assert.deepEqual(after.observations.writes, before.observations.writes); }
async function backupDownload(page, entry) {
  await openBackup(page); entry.before = await snapshot(page);
  const bytes = await download(page, () => page.locator('#backup-export').click());
  entry.after = await snapshot(page); entry.download_sha256 = sha256(bytes); entry.download_bytes = bytes.length;
  assertReadOnly(entry.before, entry.after); assert.equal(entry.after.backup.role, 'status');
  assert.match(entry.after.backup.message, /^Backup download requested\./);
  const document = JSON.parse(bytes.toString('utf8'));
  assert.equal(document.schema, 'returnby.backup'); assert.equal(document.version, 1);
  assert.deepEqual(document.orders, rows(entry.before)); assert(!bytes.includes(Buffer.from('RETURNBY_NATIVE_DRAFT_ONLY')));
  return bytes;
}

await checkpoint();
try {
  await phase('01-exact-source-and-vite-build-preflight', async entry => {
    assert.equal(process.version, 'v24.19.0');
    const subjectRoot = envPath('RETURNBY_SUBJECTS'), runtime = envPath('RETURNBY_WORK');
    assert(runtime.startsWith('/dev/') && !runtime.startsWith('/dev/shm/'), 'Use an owned /dev runtime, not full scratch or shared memory');
    assert(!runtime.startsWith(subjectRoot + sep) && !out.startsWith(subjectRoot + sep), 'Evidence/runtime must not modify subject input trees');
    await mkdir(runtime, { recursive: true }); await mkdir(resolve(runtime, 'tmp'), { recursive: true }); await mkdir(resolve(runtime, 'downloads'), { recursive: true });
    process.env.TMPDIR = resolve(runtime, 'tmp');
    report.runtime = { node: process.version, subject_root: subjectRoot, work: runtime, evidence: out, TMPDIR: process.env.TMPDIR };
    report.driver_sha256 = sha256(await readFile(fileURLToPath(import.meta.url)));
    report.inputs = {};
    for (const subject of ['base', 'candidate']) {
      const input = await verifySubject(resolve(subjectRoot, subject), subject); subjects.set(subject, input); report.inputs[subject] = input.binding;
    }
    const playwrightPath = resolve(process.env.RETURNBY_PLAYWRIGHT || `${PLAYWRIGHT_ROOT}/playwright/index.mjs`);
    assert.equal(playwrightPath, `${PLAYWRIGHT_ROOT}/playwright/index.mjs`, 'Use the exact existing Playwright import');
    for (const [path, expected] of Object.entries(PLAYWRIGHT_PINS)) assert.equal(await shaFile(resolve(PLAYWRIGHT_ROOT, path)), expected, `Existing Playwright ${path}`);
    const chrome = resolve(process.env.RETURNBY_CHROME || '/workspace/scratch/a4a1879c582f/t95-receiving/browser/chromium');
    assert.equal(await shaFile(chrome), CHROME_PIN, 'Exact existing Chromium binary');
    report.browser_input = { path: chrome, sha256: CHROME_PIN, playwright_import: playwrightPath, playwright_pins: PLAYWRIGHT_PINS };
    for (const [subject, input] of subjects) input.origin = await serve(subject, input);
    entry.source_files_verified = { base: 44, candidate: 45 }; entry.dist_files_verified = { base: 6, candidate: 6 };
    // Import/launch follows exact subject verification. No package installation occurs.
    const { chromium } = await import(pathToFileURL(playwrightPath).href);
    browser = await chromium.launch({ headless: true, executablePath: chrome, args: ['--disable-dev-shm-usage'], downloadsPath: resolve(runtime, 'downloads') });
    report.browser_version = browser.version();
  });
  let base, candidate, boundaryOrder, finalRaw, finalBackup;
  await phase('02-baseline-single-native-huge-window-save', async entry => {
    base = await newPage('base', 'baseline'); entry.initial = await snapshot(base.page);
    assert.equal(entry.initial.storage.raw, null); assert.deepEqual(entry.initial.storage.keys, []);
    await draft(base.page, normalFields); entry.before = await snapshot(base.page);
    assert.equal(entry.before.paste, PASTE); assert.deepEqual(entry.before.preview.values, normalFields);
    entry.numeric_precondition = { raw: '1000000000', number: Number('1000000000'), finite: Number.isFinite(Number('1000000000')), safeInteger: Number.isSafeInteger(Number('1000000000')) };
    entry.after = await clickSave(base.page);
    if (!entry.before.preview.formCheckValidity) { report.baseline_outcome = 'native-constraints-refused; candidate not run'; assertRetained(entry.before, entry.after); assertNativeSave(entry.before, entry.after, 0); throw Error('Baseline native constraints refused the planned history. No forced admission or replacement witness.'); }
    if (rows(entry.after).length !== 1) { report.baseline_outcome = 'ordinary-save-did-not-admit; candidate not run'; throw Error('The planned baseline did not admit exactly one record. Stop without substitute history.'); }
    assertSaved(entry.before, entry.after, { days: 1000000000, source: 'user', due: 'NaN-NaN-NaN' });
    report.baseline_outcome = 'native-save-admitted-unrepresentable-deadline; strict-consumer-check-pending';
  });
  await phase('03-baseline-actual-strict-backup-refusal', async entry => {
    await openBackup(base.page); entry.before = await snapshot(base.page);
    const downloadCount = report.downloads.length;
    await base.page.locator('#backup-export').click();
    await base.page.waitForTimeout(500); // Bounded observation of the synchronous native export gesture.
    entry.after = await snapshot(base.page); entry.no_download_observation_ms = 500;
    assertReadOnly(entry.before, entry.after); assert.equal(entry.after.backup.hidden, false); assert.equal(entry.after.backup.role, 'alert');
    assert.equal(entry.after.backup.message, 'Order 1 has an invalid return window.');
    assert.equal(report.downloads.length, downloadCount); assert.deepEqual(entry.after.observations.objectURLs, entry.before.observations.objectURLs);
    report.baseline_outcome = 'reproduced: ordinary native Save admitted1000000000, dueNaN-NaN-NaN, strict Backup refused';
    await closeContext(base.ctx);
  });
  await phase('04-candidate-same-native-huge-draft-refused-and-retained', async entry => {
    candidate = await newPage('candidate', 'candidate'); entry.initial = await snapshot(candidate.page);
    assert.equal(entry.initial.storage.raw, null); assert.deepEqual(entry.initial.storage.keys, []);
    await draft(candidate.page, normalFields); entry.before = await snapshot(candidate.page);
    assert.equal(entry.before.paste, PASTE); assert.deepEqual(entry.before.preview.values, normalFields);
    assert.equal(entry.before.preview.formCheckValidity, true); assert.equal(entry.before.preview.fields.windowDays.validity.customError, false);
    entry.after = await clickSave(candidate.page);
    assertNativeSave(entry.before, entry.after, 1); assertRetained(entry.before, entry.after);
    assert.equal(entry.after.preview.fields.windowDays.validity.customError, true); assert.equal(entry.after.preview.formCheckValidity, false);
    assert.equal(entry.after.preview.fields.windowDays.validationMessage, 'Enter a return window as a positive whole number of days.');
    assert.equal(entry.after.focus.name, 'windowDays');
    assert(since(entry.before, entry.after, 'invalid').some(event => !event.probe && event.field === 'windowDays' && event.validity.customError), 'Product native reportValidity observation');
  });
  await phase('05-native-window-correction-and-save', async entry => {
    entry.before_correction = await snapshot(candidate.page);
    await field(candidate.page, 'windowDays').fill('30'); entry.before = await snapshot(candidate.page);
    assert.equal(entry.before.preview.fields.windowDays.validity.customError, false); assert.equal(entry.before.preview.formCheckValidity, true);
    assert.equal(entry.before.paste, entry.before_correction.paste); assert.equal(entry.before.storage.raw, null);
    entry.after = await clickSave(candidate.page);
    entry.saved_order = assertSaved(entry.before, entry.after, { days: 30, source: 'user', due: '2026-11-02' });
  });
  await phase('06-first-success-actual-strict-backup-download', async entry => { await backupDownload(candidate.page, entry); });
  await phase('07-terminal-calendar-end-refusal-retains-earlier-tracker', async entry => {
    await draft(candidate.page, { merchant: '  Fictional Café <&> "Eli"  ', orderDate: '9999-12-01', orderNo: '  BOUNDARY <&>  ', total: '  USD 55.00 <&>  ', windowDays: '30' });
    entry.before = await snapshot(candidate.page); assert.equal(entry.before.preview.formCheckValidity, true);
    entry.after = await clickSave(candidate.page); assertNativeSave(entry.before, entry.after, 1); assertRetained(entry.before, entry.after);
    assert.equal(entry.after.preview.fields.windowDays.validity.customError, true); assert.equal(entry.after.focus.name, 'windowDays');
    assert.equal(entry.after.preview.fields.windowDays.validationMessage, 'The return deadline must be before 9999-12-31 so its calendar reminder has a valid end date.');
  });
  await phase('08-native-date-correction-clears-window-message-and-saves', async entry => {
    entry.before_correction = await snapshot(candidate.page);
    await field(candidate.page, 'orderDate').fill('9999-11-30'); entry.before = await snapshot(candidate.page);
    assert.equal(entry.before.preview.fields.windowDays.validity.customError, false); assert.equal(entry.before.preview.fields.windowDays.validationMessage, ''); assert.equal(entry.before.preview.formCheckValidity, true);
    assert.equal(entry.before.preview.values.windowDays, entry.before_correction.preview.values.windowDays); assert.equal(entry.before.storage.raw, entry.before_correction.storage.raw);
    entry.after = await clickSave(candidate.page);
    boundaryOrder = assertSaved(entry.before, entry.after, { days: 30, source: 'default', due: '9999-12-30' }); entry.saved_order = boundaryOrder;
  });
  await phase('09-native-bad-input-is-blocked-before-submit', async entry => {
    await draft(candidate.page, { ...normalFields, orderNo: 'NATIVE-BLANK', windowDays: '' });
    await field(candidate.page, 'windowDays').press('e'); entry.before = await snapshot(candidate.page);
    // This must be observed in Chromium. Never assign an invalid value or bypass validation.
    entry.after = await clickSave(candidate.page); assertRetained(entry.before, entry.after); assertNativeSave(entry.before, entry.after, 0);
    assert.equal(entry.before.preview.values.windowDays, ''); assert.equal(entry.before.preview.fields.windowDays.validity.badInput, true);
    assert.equal(entry.before.preview.fields.windowDays.validity.customError, false); assert.equal(entry.before.preview.formCheckValidity, false);
    assert(since(entry.before, entry.after, 'invalid').some(event => !event.probe && event.field === 'windowDays' && event.validity.badInput));
  });
  await phase('10-clear-bad-input-to-native-blank-and-save-default30', async entry => {
    entry.before_clear = await snapshot(candidate.page);
    await field(candidate.page, 'windowDays').press('Control+A'); await field(candidate.page, 'windowDays').press('Backspace');
    entry.before = await snapshot(candidate.page);
    assert.equal(entry.before.preview.values.windowDays, ''); assert.equal(entry.before.preview.fields.windowDays.validity.badInput, false); assert.equal(entry.before.preview.formCheckValidity, true);
    assert.equal(entry.before.storage.raw, entry.before_clear.storage.raw);
    entry.after = await clickSave(candidate.page); entry.saved_order = assertSaved(entry.before, entry.after, { days: 30, source: 'user', due: '2026-11-02' });
  });
  await phase('11-native-scientific-number-save100', async entry => {
    await draft(candidate.page, { ...normalFields, merchant: 'Fictional Numeric Shop', orderNo: 'NATIVE-SCIENTIFIC', windowDays: '1e2' });
    entry.before = await snapshot(candidate.page); assert.equal(entry.before.preview.values.windowDays, '1e2'); assert.equal(entry.before.preview.formCheckValidity, true);
    entry.after = await clickSave(candidate.page); entry.saved_order = assertSaved(entry.before, entry.after, { days: 100, source: 'user', due: '2027-01-11' });
  });
  await phase('12-native-decimal-number-save30-with-submitted-store-policy', async entry => {
    await draft(candidate.page, { ...normalFields, merchant: '  Northwind Outfitters  ', orderNo: 'NATIVE-DECIMAL', windowDays: '30.0' });
    entry.before = await snapshot(candidate.page); assert.equal(entry.before.preview.values.windowDays, '30.0'); assert.equal(entry.before.preview.formCheckValidity, true);
    entry.after = await clickSave(candidate.page); entry.saved_order = assertSaved(entry.before, entry.after, { days: 30, source: 'policy', due: '2026-11-02' });
    finalRaw = entry.after.storage.raw;
  });
  await phase('13-actual-calendar-download-for-corrected-end-bound', async entry => {
    entry.before = await snapshot(candidate.page);
    const bytes = await download(candidate.page, () => candidate.page.locator(`[data-ics="${boundaryOrder.id}"]`).click());
    entry.after = await snapshot(candidate.page); entry.download_bytes = bytes.length; entry.download_sha256 = sha256(bytes); assertReadOnly(entry.before, entry.after);
    const content = bytes.toString('utf8').replace(/\r\n[ \t]/g, '');
    assert.equal((content.match(/BEGIN:VEVENT\r\n/g) || []).length, 1);
    assert(content.includes(`UID:${boundaryOrder.id}@returnby\r\n`));
    assert(content.includes('DTSTART;VALUE=DATE:99991230\r\n')); assert(content.includes('DTEND;VALUE=DATE:99991231\r\n'));
    entry.observed_due = '9999-12-30'; entry.observed_calendar_end = '9999-12-31';
  });
  await phase('14-final-actual-strict-backup-download', async entry => { finalBackup = await backupDownload(candidate.page, entry); assert.equal(entry.after.storage.raw, finalRaw); });
  await phase('15-actual-backup-file-preview-and-restore-in-fresh-context', async entry => {
    const restored = await newPage('candidate', 'strict-backup-roundtrip'); entry.initial = await snapshot(restored.page);
    assert.equal(entry.initial.storage.raw, null); assert.deepEqual(entry.initial.storage.keys, []);
    await openBackup(restored.page);
    await restored.page.locator('#backup-file').setInputFiles({ name: 'actual-native-returnby-backup.json', mimeType: 'application/json', buffer: finalBackup });
    await restored.page.locator('#backup-preview').waitFor({ state: 'visible', timeout: 10000 });
    entry.preview = await snapshot(restored.page); entry.selected_file_sha256 = sha256(finalBackup);
    assert.equal(entry.preview.storage.raw, null); assert.equal(entry.preview.observations.writes.length, 0); assert.equal(entry.preview.backup.applyDisabled, false);
    assert.equal(entry.preview.backup.summary, '5 to add · 0 already saved · 0 conflicting'); assert.equal(entry.preview.backup.rows.length, 5);
    await restored.page.locator('#backup-apply').click(); entry.after = await snapshot(restored.page);
    assert.equal(entry.after.backup.message, 'Imported 5 orders. Skipped 0 already saved.');
    assert.equal(entry.after.storage.raw, finalRaw, 'Strict actual export/file-parse/commit roundtrip retains exact saved bytes');
    assert.equal(entry.after.observations.writes.length, 1); assert.equal(entry.after.observations.writes[0].accepted, true);
    assert.deepEqual(rows(entry.after), JSON.parse(finalRaw)); assert.equal(entry.after.tracker.counts['tracked-count'], '5');
    const sourceAfter = await snapshot(candidate.page); entry.original_context_after = sourceAfter; assert.equal(sourceAfter.storage.raw, finalRaw);
    await closeContext(restored.ctx); activePage = candidate.page;
  });
  await phase('16-native-run-integrity', async entry => {
    await Promise.all([...downloadJobs.values()]);
    assert.deepEqual(report.application_errors, []); assert.deepEqual(report.console_errors, []); assert.deepEqual(report.external_requests, []); assert.deepEqual(report.capture_errors, []);
    assert(report.served_requests.every(request => request.status === 200), 'Only exact build files were requested');
    assert.equal(report.downloads.length, 4); assert(report.downloads.every(download => download.status === 'captured'));
    for (const [subject, input] of subjects) {
      const checked = await verifySubject(input.root, subject); assert.deepEqual(checked.binding, input.binding);
      const served = report.served_requests.filter(request => request.subject === subject && request.status === 200);
      for (const request of served) assert.equal(request.sha256, input.receipt.build_files.find(file => file.path === request.path)?.sha256);
    }
    entry.source_and_build_unchanged = true; entry.native_downloads_captured = 4; entry.accepted_records_roundtripped = 5;
    report.candidate_outcome = 'same native huge-window Save refused; native correction, cross-field correction, blank and numeric meanings admitted; strict Backup roundtrip and end-bound calendar download observed';
  });
} catch (error) { failure = error; report.failure = errorValue(error); }
finally {
  await Promise.all([...downloadJobs.values()]);
  for (const ctx of contexts) { try { await ctx.close(); } catch (error) { report.cleanup_errors.push(errorValue(error)); } }
  if (browser) { try { await browser.close(); } catch (error) { report.cleanup_errors.push(errorValue(error)); } }
  for (const server of servers) { try { server.closeAllConnections(); await new Promise((done, reject) => server.close(error => error ? reject(error) : done())); } catch (error) { report.cleanup_errors.push(errorValue(error)); } }
  if (subjects.size) {
    report.postflight = {};
    for (const [subject, input] of subjects) {
      try { const checked = await verifySubject(input.root, subject); assert.deepEqual(checked.binding, input.binding); report.postflight[subject] = 'all source/build bytes unchanged'; }
      catch (error) { report.postflight[subject] = errorValue(error); if (!failure) { failure = error; report.failure = errorValue(error); } }
    }
  }
  if (!failure && (report.capture_errors.length || report.cleanup_errors.length)) { failure = Error('Native evidence capture or cleanup failed'); report.failure = errorValue(failure); }
  report.status = failure ? 'fail' : 'pass'; report.ended_at = utc(); delete report.active_phase; await checkpoint();
  console.log(JSON.stringify({ status: report.status, receipt: resolve(out, 'browser-receipt.json'), driver_sha256: report.driver_sha256, baseline_outcome: report.baseline_outcome, candidate_outcome: report.candidate_outcome, failure: report.failure }, null, 2));
}
if (failure) { console.error(failure.stack || failure); process.exitCode = 1; }
