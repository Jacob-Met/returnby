import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
aliases=json.loads((root/'EVIDENCE-ALIASES.json').read_text())['aliases']
planned=[]
for name,record in aliases.items():
    dest=(root/name).resolve();src=(root/record['member']).resolve()
    if root not in dest.parents or root not in src.parents:raise RuntimeError('Path outside extracted archive')
    body=src.read_bytes()
    if len(body)!=record['bytes'] or hashlib.sha256(body).hexdigest()!=record['sha256']:raise RuntimeError('Source hash mismatch: '+name)
    if dest.exists():
        if dest.read_bytes()!=body:raise RuntimeError('Existing file differs: '+name)
    else:planned.append((dest,body))
for dest,body in planned:
    dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as stream:stream.write(body)
print('Recreated',len(planned),'exact evidence aliases; verified',len(aliases),'logical paths.')
