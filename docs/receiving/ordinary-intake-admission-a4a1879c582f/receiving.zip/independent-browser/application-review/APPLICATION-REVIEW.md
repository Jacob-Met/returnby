# ReturnBy owner application — independent receiving review

**Accepted for the exact #20 receiving base.** The 8,269-byte patch applies in memory with exact context and coordinates to all four pinned afterimages. No blocking discrepancy was found. The resulting source-only Git tree is `584d04643c7ade03ded7d59db481731464c36d3f`.

## Exact application

The patch SHA-256 is `60c2ecaeb8ebb177006015316bf44d139b84b42ef43e47ae45aef283ba6226bd`. Its exact 6,908-byte production component and 1,361-byte inert-fixture component match the native archive. The four file sections contain **six actual `@@` hunks**, totaling **101 insertions and 44 deletions**. Every beforeimage size, SHA-256 and Git blob matches both the manifest and preserved native bytes. The new validator file is absent from the base.

| Path | Before bytes | After bytes | Git blob after |
| --- | ---: | ---: | --- |
| `src/order-admission.ts` | absent | 1748 | `fcc5ad1761f4d2125549554f1c2835854d5e98c5` |
| `src/edit.ts` | 4075 | 2749 | `fd83cef629ee35af4d8979b170855f16e9b5175f` |
| `src/main.ts` | 9935 | 11059 | `4b7a909c30c06271932f4887e4b783a6b27395d1` |
| `tests/helpers/storage-fixture.mjs` | 3025 | 4007 | `2728b24ae06d05bc8a9da3a59a48f5e45c7e4aa3` |

## Canonical source tree

The complete cached base has 227 recursive entries: 191 leaves and 36 subtrees. Independent canonical Git serialization reconstructs `b28e7b706fe67fd4b34111badd581c6bdd2ed4a7` and matches every one of the 36 stored subtree IDs. The cache's top-level `sha` echoes the source ref `7829e56e57ef91dfe8edd5853fd68d6c7890fac0`; it is not the reconstructed root tree ID.

The final tree `584d04643c7ade03ded7d59db481731464c36d3f` contains 192 leaves and 36 subtrees. Exactly 188 old leaves and 33 old subtrees remain unchanged. Only the root, `src`, `tests` and `tests/helpers` tree objects change. `SOURCE-TREE.json` retains the full candidate leaf/subtree map, unchanged-path lists, and raw base64 Git bodies for the four changed trees before and after application. Directory sort keys include a trailing slash, as Git requires.

All 44 preserved baseline build inputs and both workflow inputs were rehashed against the cached tree. The remaining baseline leaf identities are preserved from the complete cache; this review does not claim fresh retrieval of their contents.

## Behavioral review

The existing editor draft type, error constructor source, calendar predicate and admission checks are extracted intact. The editor preserves its policy choice, identity and conflict handling. The shared `EditError` import/reexport retains constructor identity.

Native intake checks number validity and then shared admission before policy lookup, fresh-store read, UUID/time generation or persistence. Blank optional windows retain the 30-day fallback; accepted native numeric forms retain their numerical meaning. Merchant, order number and total remain literal. The shared length, Gregorian-date, safe whole-window, due-date and calendar-end limits are preserved. Input edits clear every custom message, allowing a date correction to resolve a window error.

The final fixture adds five live preview controls, `namedItem`, the supported input query and custom-validity methods. Its getters follow whole-object field replacement. It does not simulate native type/min/step/date validity. Existing maintained assertions and other fixture/storage behavior remain byte-exact.

## Existing executed qualification and its limits

| Evidence | Preserved result | Fixture selection |
| --- | --- | --- |
| Baseline maintained suite | 201 passed, 0 failed | Original 3,025-byte fixture |
| Historical three-file candidate suite | 173 passed, 28 failed; missing inert `preview.elements.namedItem` | Original 3,025-byte fixture |
| Final maintained suite | 201 passed, 0 failed | Final 4,007-byte fixture |
| Native browser witness | One execution, 16 of 16 phases passed, no recorded browser/error arrays | Original 3,025-byte fixture |

Both original TypeScript/Vite build receipts and their complete source/dist bindings were rechecked. The frozen browser inputs match the original 44/45 source records and driver. The final maintained-suite receipt matches all 45 composed source inputs. The fixture-only adaptation changes no production or dist bytes. Reproducing the historical browser receipt must therefore use its original 3,025-byte fixture; applying the complete owner packet uses the 4,007-byte fixture. The original failed suite evidence remains preserved.

This review applies to receiving base #20. Later main composition requires its own source identity and qualification. It makes no adoption, commit, merge, Actions, deployment or current-main claim. No test, build or browser check was rerun for this review, and no network/API or source/ref mutation occurred.

## Metadata and custody

The author's `all_four_hunks_reconstructed_in_memory_to_qualified_afterimages` boolean uses “hunks” for the four file sections. The exact patch contains six hunks; the immutable review records that correction without rewriting the packet. This naming issue does not change application bytes or afterimages.

The three packet files remain in the author envelope. This independent JSON review, this Markdown review and the complete tree record are appended to the reviewer envelope after SHA-256/CRC validation and compressed-size preflight. Every prior ZIP member and its local compressed record is retained, followed by an in-place flush, fsync and readback verification. Detailed member hashes and predecessor custody appear in `APPLICATION-REVIEW.json`.
