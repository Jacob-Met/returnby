ReturnBy ordinary new-order admission: one planned baseline history

Target the exact owner #20 receiving subject 7829e56e57ef91dfe8edd5853fd68d6c7890fac0, tree b28e7b706fe67fd4b34111badd581c6bdd2ed4a7. This is a proposed integration subject; current main1e662c387be5f66f8499fac7ec443f58d2198379 has no backup/editor. Do not describe the proposed strict-backup behavior as shipped behavior.

Use the original complete TS/HTML/CSS dependency graph, transformed only with existing Node24 stripTypeScriptTypes and documented CSS/JSON module adapters. Retain original and served bytes/hashes. The maintained Vite build/bundle gate remains unrun.

Start one disposable native browser context with empty local storage. Enter a fictional confirmation and open the ordinary review form. Enter a valid normal order date and the positive finite safe integer window string1000000000. Before Save, capture the original paste, all reviewed field strings, native checkValidity/validity details, and raw saved storage. Use the actual visible submit button, never synthetic submit dispatch. Observe the actual native Save event and capture any storage write, saved bytes, rendered due/card, paste and form retirement state. If native constraints refuse, preserve that outcome and stop; do not force admission.

If Save actually admits the record, invoke the unchanged #20 Backup export control and record its actual diagnostic/download behavior together with exact before/after stored bytes. No direct store injection, schema substitution, invalid-event bypass, product edits, broad suite or deployment claim is allowed. The question is whether ordinary Save admits a record its existing strict consumer cannot export; this remains a hypothesis until the complete native flow executes.

Keep missing source bytes explicit. Do not replace the owner20 graph with current-main variants merely because filenames match. Exact Git-blob-equal cached bytes may be reused with provenance. No further GitHub probing while root's read pause remains in effect.
