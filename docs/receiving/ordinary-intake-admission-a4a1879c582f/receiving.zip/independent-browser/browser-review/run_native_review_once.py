import datetime, hashlib, io, json, os, pathlib, shutil, signal, subprocess, tempfile, time, traceback, zipfile
ROOT = pathlib.Path('/workspace/scratch/a4a1879c582f')
RESERVE = ROOT / 'receiving-reserve-named-author.bin'
NATIVE = ROOT / 'receiving-reserve-returnby-native.bin'
NATIVE_PIN = '7a67bbdd768109bee5e1b3a17e085b129259ba06724751565e7eebc3db8e9089'
DRIVER_MEMBER = 'browser-review/driver/revision-2/check_native_admission_receiving.mjs'
DRIVER_PIN = '563d4dfaa9f56a0c0fe97c3bd7bd12918d50ee0dca6b83c1eb1837c06ea2a45b'
RECEIPTS = {'base':'ecc3e1d8de9bffbd2a09a1ea7bf16f16b43aaa640584c476586bc193b490ca3b','candidate':'f48e89594fef7ad7e36e27cbe7b83650acfa2b8aa3f7916f2ceb7a36feaa66dd'}
OVERLAYS = {'src/main.ts','src/edit.ts','src/order-admission.ts'}
PREFIX = 'browser-review/attempt-1/'
NODE = '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def jb(value): return (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode()
def capsule(path, expected=None):
    raw=path.read_bytes(); line,padded=raw.split(b'\n',1); header=json.loads(line); body=padded[:header['zip_bytes']]
    assert sha(body)==header['sha256'], 'Capsule SHA mismatch'
    if expected is not None: assert header['sha256']==expected, 'Capsule changed from acknowledged pin'
    assert not any(padded[len(body):]), 'Nonzero reserved padding'
    archive=zipfile.ZipFile(io.BytesIO(body)); assert archive.testzip() is None
    assert len(archive.namelist())==len(set(archive.namelist()))
    return header,{n:archive.read(n) for n in archive.namelist()},len(raw)
def append(additions):
    old,members,capacity=capsule(RESERVE)
    for name,data in additions.items():
        assert name not in members, 'Never overwrite retained evidence: '+name
        members[name]=data
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in members.items(): archive.writestr(name,data)
    body=output.getvalue(); header={'schema':old['schema'],'zip_bytes':len(body),'sha256':sha(body)}
    prefix=(json.dumps(header,sort_keys=True)+'\n').encode()
    assert len(prefix)+len(body)<=capacity, 'Evidence exceeds assigned reserve; retain owned temporary directory'
    with RESERVE.open('r+b') as f:
        f.write(prefix+body+b'\0'*(capacity-len(prefix)-len(body))); f.flush(); os.fsync(f.fileno())
    checked,actual,length=capsule(RESERVE,header['sha256']); assert length==capacity and actual==members
    return {'header':checked,'allocation_bytes':capacity,'members':len(members),'fsync_and_readback_verified':True}
def checked_write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
    assert path.read_bytes()==data
def safe_path(root,relative):
    path=root/relative
    assert path.resolve().is_relative_to(root.resolve()) and path.resolve()!=root.resolve()
    return path
started=stamp(); own_header,own_members,_=capsule(RESERVE)
assert not any(name.startswith(PREFIX) for name in own_members), 'Attempt-1 already exists; no automatic replay'
driver=own_members[DRIVER_MEMBER]; assert sha(driver)==DRIVER_PIN
temp=pathlib.Path(tempfile.mkdtemp(prefix='returnby-browser-review-',dir='/dev'))
evidence=temp/'evidence'; evidence.mkdir(); subjects=temp/'subjects'; runtime=temp/'runtime'
stdout_path=temp/'process.stdout.txt'; stderr_path=temp/'process.stderr.txt'
material={'schema':'returnby.native-browser-materialization.v1','started_at':started,'status':'running','subjects':{},'source_selection':'Only three candidate src overlays; all other original source inputs use base, including3025B storage fixture'}
execution={'schema':'returnby.native-browser-wrapper-execution.v1','started_at':started,'attempt':1,'native_driver_spawned':False,'owned_temp':str(temp),'driver_sha256':DRIVER_PIN}
proc=None; keep_temp=True; extras={}
try:
    input_header,input_members,_=capsule(NATIVE,NATIVE_PIN); material['input_capsule']=input_header
    for subject in ['base','candidate']:
        target=subjects/subject; member=f'build/{subject}/BUILD-RECEIPT.json'; data=input_members[member]
        assert sha(data)==RECEIPTS[subject]; receipt=json.loads(data); checked_write(target/'BUILD-RECEIPT.json',data)
        source_records=[]; build_records=[]
        for entry in receipt['source_files']:
            source_member=('candidate/' if subject=='candidate' and entry['path'] in OVERLAYS else 'base/')+entry['path']
            body=input_members[source_member]
            assert len(body)==entry['bytes'] and sha(body)==entry['sha256']
            assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==entry['git_blob']
            checked_write(safe_path(target,entry['path']),body)
            source_records.append({**entry,'archive_member':source_member})
        for entry in receipt['build_files']:
            body=input_members[entry['archive_member']]
            assert len(body)==entry['bytes'] and sha(body)==entry['sha256']
            checked_write(safe_path(target/'dist',entry['path']),body); build_records.append(entry)
        material['subjects'][subject]={'build_receipt_sha256':sha(data),'source_files':source_records,'build_files':build_records}
    material['status']='pass'; material['ended_at']=stamp()
    driver_path=temp/'check_native_admission_receiving.mjs'; checked_write(driver_path,driver)
    environment=os.environ.copy()
    environment.update({'RETURNBY_SUBJECTS':str(subjects),'RETURNBY_WORK':str(runtime),'RETURNBY_EVIDENCE':str(evidence),'RETURNBY_PLAYWRIGHT':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs','RETURNBY_CHROME':str(ROOT/'t95-receiving/browser/chromium')})
    execution['command']=[NODE,str(driver_path)]
    execution['task_environment']={name:environment[name] for name in ['RETURNBY_SUBJECTS','RETURNBY_WORK','RETURNBY_EVIDENCE','RETURNBY_PLAYWRIGHT','RETURNBY_CHROME']}
    intent={**execution,'input_capsule':input_header,'review_receipt_sha256':sha(own_members['browser-review/DRIVER-REVIEW.json']),'intent':'Exactly one frozen driver invocation; retain first failure and never replay automatically'}
    print(json.dumps({'checkpoint':'execution-intent',**append({PREFIX+'EXECUTION-INTENT.json':jb(intent)})}),flush=True)
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        proc=subprocess.Popen(execution['command'],cwd=temp,env=environment,stdout=stdout,stderr=stderr,start_new_session=True)
        execution['native_driver_spawned']=True; execution['driver_pid']=proc.pid
        deadline=time.monotonic()+180
        while True:
            try:
                proc.wait(timeout=min(30,max(0.1,deadline-time.monotonic()))); break
            except subprocess.TimeoutExpired:
                phase_name='receipt pending'
                try: phase_name=json.loads((evidence/'browser-receipt.json').read_bytes()).get('active_phase','finalizing')
                except Exception: pass
                print(json.dumps({'running':True,'active_phase':phase_name,'owned_driver_pid':proc.pid}),flush=True)
                if time.monotonic()>=deadline:
                    execution['timeout_seconds']=180
                    os.killpg(proc.pid,signal.SIGTERM)
                    try: proc.wait(timeout=10)
                    except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait(timeout=10)
                    raise TimeoutError('The one owned driver invocation exceeded180seconds; it was stopped without replay')
        stdout.flush(); stderr.flush(); os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
    execution['exit_code']=proc.returncode
    execution['status']='pass' if proc.returncode==0 else 'fail'
except BaseException as error:
    execution['status']='fail'; execution['wrapper_failure']={'name':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
    if material['status']=='running': material['status']='fail'; material['failure']=execution['wrapper_failure']
    if proc is not None and proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try: proc.wait(timeout=10)
        except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait(timeout=10)
    if proc is not None: execution['exit_code']=proc.returncode
finally:
    execution['ended_at']=stamp(); material.setdefault('ended_at',execution['ended_at'])
    extras[PREFIX+'MATERIALIZATION.json']=jb(material)
    extras[PREFIX+'EXECUTION.json']=jb(execution)
    extras[PREFIX+'process.stdout.txt']=stdout_path.read_bytes() if stdout_path.exists() else b''
    extras[PREFIX+'process.stderr.txt']=stderr_path.read_bytes() if stderr_path.exists() else b''
    for path in sorted(evidence.rglob('*')):
        if path.is_file(): extras[PREFIX+'evidence/'+path.relative_to(evidence).as_posix()]=path.read_bytes()
    manifest={'schema':'returnby.native-browser-attempt-artifacts.v1','attempt':1,'retained_at':stamp(),'files':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in extras.items()}}
    extras[PREFIX+'ARTIFACTS.json']=jb(manifest)
    receipt=None
    if (evidence/'browser-receipt.json').exists():
        try: receipt=json.loads((evidence/'browser-receipt.json').read_bytes())
        except Exception: pass
    try:
        checkpoint=append(extras); keep_temp=False
        print(json.dumps({'checkpoint':'all-native-evidence-retained',**checkpoint}),flush=True)
    except BaseException as error:
        print(json.dumps({'checkpoint_failure':str(error),'retained_temp':str(temp),'driver_status':execution.get('status')}),flush=True)
        raise
    if not keep_temp:
        cleanup={'schema':'returnby.native-browser-owned-cleanup.v1','owned_temp':str(temp),'at':stamp(),'status':'running'}
        try: shutil.rmtree(temp); cleanup['status']='pass'; cleanup['exists_after']=temp.exists()
        except BaseException as error: cleanup['status']='fail'; cleanup['error']=str(error)
        final_checkpoint=append({PREFIX+'CLEANUP.json':jb(cleanup)})
        print(json.dumps({'status':execution.get('status'),'driver_exit_code':execution.get('exit_code'),'browser_status':receipt.get('status') if receipt else None,'browser_version':receipt.get('browser_version') if receipt else None,'baseline_outcome':receipt.get('baseline_outcome') if receipt else None,'candidate_outcome':receipt.get('candidate_outcome') if receipt else None,'first_failure':receipt.get('failure') if receipt else execution.get('wrapper_failure'),'phase_statuses':[(phase['name'],phase['status']) for phase in receipt.get('phases',[])] if receipt else [],'native_downloads':[{k:entry.get(k) for k in ['number','path','bytes','sha256','status']} for entry in receipt.get('downloads',[])] if receipt else [],'cleanup':cleanup,'final_checkpoint':final_checkpoint}),flush=True)
