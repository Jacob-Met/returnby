# Independent ReturnBy native receiving result

**Accepted for the exact isolated proposal.** One native Chromium invocation passed all 16 phases. The planned baseline counterexample was reproduced and the candidate passed the same input plus the focused correction and consumer checks. No browser retry occurred.

## Subject and method

The receiving baseline is source `7829e56e57ef91dfe8edd5853fd68d6c7890fac0`, tree `b28e7b706fe67fd4b34111badd581c6bdd2ed4a7`. The candidate is the reviewed three-file overlay. This is the proposed owner20 graph; it is not a claim about deployed current main.

Independent custody bound all 44 baseline source/test/config/asset files to the cached Git tree, reconstructed the root and 36 subtrees, and verified the 45-file candidate plus each six-file Vite build inventory. The independently reviewed 40,163-byte revision2 driver was executed unchanged. It served real Vite output and used actual native controls, Save clicks, storage and downloads. Date was native. Only forwarding storage-write/object-URL observers and read-only event/state capture were added.

Native execution ran from 2026-10-08T23:15:06.175Z to 23:15:10.780Z under Node24.19.0 and Chromium153.0.8010.0, desktop headless, en-US, UTC. There were three empty disposable contexts: baseline, candidate, and actual Backup restoration.

## Baseline counterexample

Starting with null storage, the ordinary form accepted the native number value `1000000000` for the normal date `2026-10-03`. Its native form validity was true and `noValidate` was false. The actual trusted Save click produced a trusted submit, one accepted storage write, a saved order with window1000000000, an emptied paste, a hidden review form and `RETURN BY NaN-NaN-NaN`.

The stored JSON was 231 UTF-8 bytes, SHA256 `5fc98b856a5cc22b3f78ddc630d3a4cb052283f5c76af98a16665ea0d6da84b3`. Clicking the unchanged Backup export control showed the actual alert **Order 1 has an invalid return window.** Its before/after stored JSON was exact, no object URL was allocated, and no download event occurred during the sealed 500ms observation. This is a retained product counterexample within the receiving baseline, not a failing browser invocation.

## Candidate results

| Native action | Observed result |
|---|---|
| Save the identical huge-window draft | The actual submit reached the candidate validator. It set and reported window custom validity, focused that input, retained null storage, all field strings, the 196-byte fictional paste and the displayed tracker. No storage-write attempt or object URL was observed. |
| Correct the window to30 | The input event cleared custom validity. Save created exactly one order due2026-11-02, then the unchanged strict Backup downloaded the actual408-byte file. |
| Save9999-12-01 plus30days | Refused on the window because the calendar event end would leave the accepted date range. Earlier saved JSON, paste and all reviewed fields stayed exact. |
| Correct only the date to9999-11-30 | The date input cleared the window error without changing the window. Save retained the earlier order and added a record due9999-12-30, preserving spaces, Unicode and markup characters. The actual459-byte ICS has DTSTART99991230 and DTEND99991231. |
| Type incomplete exponent `e` | Native `.value` was empty but `badInput` was true. The trusted Save click produced a native invalid event and no submit; existing storage and draft stayed exact. |
| Clear the bad input using the keyboard | The genuinely blank optional input was valid and Save admitted30days. For the submitted Contoso merchant, that is `windowSource:user` because its store policy is15days. |
| Save native `1e2` | The browser retained that input string and exposed numeric100. The saved record has100days and due2027-01-11. |
| Save native `30.0` after changing the merchant to Northwind | The saved record has30days, `windowSource:policy`, and exact submitted merchant whitespace. |
| Download the final Backup and select that actual file in a fresh context | Native preview showed5 to add,0 already saved,0 conflicting and made no write. Actual Import restored the five-record stored JSON string exactly, retaining IDs, creation timestamps, reviewed text and attribution. |

The final stored JSON string has a 1,163-byte UTF-8 encoding, SHA256 `6d15ad7d8c023c96b390b56f657d9e6e3e48c049126e07047061db55ec78ca87`. The original and restored contexts matched byte for byte under that encoding. The final actual Backup is1,644bytes, SHA256 `bf45e58f3225fe4fafd0dcc29e69b391842f88a0034c99a9ba30e7f8079dc775`. All three original download files are retained without transcoding.

## Integrity and preserved history

All 16 phases passed. Nine app HTTP requests received the exact pinned built HTML, JavaScript or CSS with status200. Application errors, console errors, external app requests, capture errors and cleanup errors were empty. Source/build inventories stayed unchanged after execution. The owned temporary directory was removed after evidence checkpoint and readback. No other browser run is needed for this scope.

The original maintained candidate result remains a distinct retained failure: root reports173/201 with28inert fixture failures at `preview.elements.namedItem`. Root separately reports201/201 after a20-line fixture-only adaptation with original assertions and production unchanged. This browser run used the original3,025-byte fixture required by the original build receipt and did not rerun or relabel either maintained result.

The initial author driver was syntax-checked only. Static review corrected two download-count constants from4 to3 before any browser execution; that first source remains retained in the author capsule. There was no failed native attempt, discarded outcome or replay.

## Evidence and scope

The authoritative raw browser receipt is `browser-review/attempt-1/evidence/browser-receipt.json`:933,698bytes, SHA256 `836e38eb68d2d28517e5418e2dac761c5317e9a70736b43bf9e8b278b1120145`. It retains exact native validity, focus, form/tracker HTML, field values, paste, raw stored JSON, trusted/probe-tagged events, writes and download descriptors. The attempt also retains original download bytes, stdout, empty stderr, materialization receipt, execution receipt and artifact manifest. `browser-review/RECEIVING-RESULT.json` provides the structured independent qualification and all pins.

Acceptance is limited to the pinned isolated proposal and these native observations. It does not establish later owner composition, physical-device behavior, calendar-app import or deployed behavior. Existing integrator ownership and adoption gates remain unchanged. This reviewer performed no source/donor edits, installs, GitHub calls or external mutations.
