from pathlib import Path
from datetime import date, timedelta
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
ROOT.joinpath('fixtures').mkdir(exist_ok=True)
ROOT.joinpath('evidence').mkdir(exist_ok=True)
NOW = '2026-10-08T12:00:00.000Z'
ORDERS = [
    {'id': 'fixture-due', 'merchant': 'Fictional Northline Outfitters', 'orderNo': 'DUE-011', 'total': '$41.50', 'orderDate': '2026-09-11', 'windowDays': 30, 'windowSource': 'user', 'createdAt': '2026-09-11T09:15:00.000Z'},
    {'id': 'fixture-expired', 'merchant': 'Fictional Paper & Pine', 'orderNo': 'OLD-001', 'total': '$23.75', 'orderDate': '2026-09-01', 'windowDays': 30, 'windowSource': 'default', 'createdAt': '2026-09-01T08:00:00.000Z'},
    {'id': 'fixture-later', 'merchant': 'Fictional Harbor Goods', 'orderNo': 'LATER-031', 'total': '$87.20', 'orderDate': '2026-10-01', 'windowDays': 30, 'windowSource': 'policy', 'createdAt': '2026-10-01T11:30:00.000Z'},
]

def write(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    path = ROOT / name
    path.write_bytes(data)
    return {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

fixtures = [write('fixtures/approved-v1.json', {'schema': 'returnby.backup', 'version': 1, 'exportedAt': NOW, 'orders': ORDERS})]
expectations = {
    'schema': 'returnby.lifecycle-independent-contract.v1',
    'source_base': '7829e56e57ef91dfe8edd5853fd68d6c7890fac0',
    'source_tree': 'b28e7b706fe67fd4b34111badd581c6bdd2ed4a7',
    'producer_claim': 4573,
    'independent_scope': 'Actual isolated browser controls, storage-boundary fault injection and real file downloads. No product source changes or unit-oracle rerun.',
    'fixed_now': NOW,
    'orders': ORDERS,
    'due_dates': {o['id']: str(date.fromisoformat(o['orderDate']) + timedelta(days=o['windowDays'])) for o in ORDERS},
    'days_left': {o['id']: (date.fromisoformat(o['orderDate']) + timedelta(days=o['windowDays']) - date(2026, 10, 8)).days for o in ORDERS},
    'draft': {'paste': 'FICTIONAL UNSAVED EMAIL: do not persist this draft. Order date 2026-10-06. Order DRAFT-ONLY.', 'merchant': 'Fictional Draft Only', 'orderDate': '2026-10-06', 'orderNo': 'DRAFT-ONLY', 'total': '$19.00', 'windowDays': '21'},
    'invariants': [
        'Complete stores only a valid completedAt addition while preserving original identity and reviewed fields.',
        'Open, Due soon and Expired views/counters exclude completed orders; Completed history retains them.',
        'Completed history has no urgency label, elapsed progress bar, countdown or calendar action; reviewed values remain readable.',
        'Edit/Remove stay available on completed cards. A completed edit changes only reviewed fields and preserves completedAt.',
        'Reopen removes completedAt while preserving ID, createdAt, reviewed fields, original date calculation and calendar identity.',
        'Completed and reopened results persist across real page reloads in the private browser context.',
        'A failed storage write changes neither displayed lifecycle nor stored bytes and preserves the separate paste/review draft.',
        'A stale Complete/Reopen refuses mutation of a changed target; a refreshed deliberate action can succeed without losing unrelated current rows.',
        'A reminder selection completed in another tab is refused before download; reloaded selection excludes completed rows.',
        'An already rendered single-order reminder cannot export a record completed in another tab.',
        'Actual v2 backup download preserves completedAt; restoring that downloaded file in a fresh context preserves every approved field.',
        'Legacy v1 imports remain active. Same-ID status disagreement blocks import; malformed completion markers refuse import/loading without writes.',
        'No external network/account/provider activity. Injected read/write failures and clocks affect only owned private fixture contexts.',
    ],
    'baseline_observation': 'Use actual frozen production build and physical backup file selection. Record saved rows, current counts, absence of Complete/history, real backup and calendar exports. Candidate controls are prepared before any candidate source read.',
    'limits': ['No claim of continuous cross-tab synchronization or transactional concurrent writes.', 'Previously imported external calendar files cannot be recalled.', 'No calendar-provider import or live user storage is exercised.'],
}
fixtures.append(write('fixtures/expectations.json', expectations))
print(json.dumps({'fixtures': fixtures, 'due_dates': expectations['due_dates'], 'days_left': expectations['days_left']}, indent=2))
