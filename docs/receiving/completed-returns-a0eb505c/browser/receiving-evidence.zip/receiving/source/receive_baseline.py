from pathlib import Path
import datetime
import json
import time
import traceback

from browser_common import ROOT, EXPECT, serve, private_browser, import_backup, by_id, stored_orders, prepare_draft, draft_state, real_download, parse_calendar, baseline_calendar_identity, counters, save_json, tree_files

output = ROOT / 'evidence/baseline-browser'
output.mkdir(exist_ok=False)
build = ROOT / 'baseline-build'
before = tree_files(build)
events = {}
result = {'schema': 'returnby.lifecycle-independent-baseline.v1', 'source_commit': EXPECT['source_base'], 'source_tree': EXPECT['source_tree'], 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'build_files': before, 'events': events}
start = time.monotonic()

try:
    with serve(build) as url, private_browser(url, 'baseline', events) as (context, page):
        import_backup(page, ROOT / 'fixtures/approved-v1.json', 3)
        assert by_id(stored_orders(page)) == by_id(EXPECT['orders'])
        assert counters(page) == {'tracked': '3', 'soon': '1', 'expired': '1'}
        draft = prepare_draft(page)
        filters = page.locator('.filter-row button').all_inner_texts()
        buttons = page.locator('#list button').all_inner_texts()
        complete = [name for name in buttons if 'complete' in name.lower()]
        history = [name for name in filters if 'complete' in name.lower()]
        assert not complete and not history
        assert page.locator('#list [role=progressbar]').count() == 3
        result['gap_observation'] = {'completion_buttons': complete, 'completed_history_filters': history, 'existing_filters': filters, 'saved_order_count': 3, 'counters': counters(page), 'progress_indicators': 3, 'implication': 'No public action can retain a completed return in quiet history; all saved fixture deadlines remain in the active tracker.'}
        result['backup_download'] = real_download(page, '#backup-export', output / 'baseline-approved-backup.json')
        backup = json.loads(Path(result['backup_download']['path']).read_text())
        assert backup['schema'] == 'returnby.backup' and backup['version'] == 1
        assert by_id(backup['orders']) == by_id(EXPECT['orders'])
        assert EXPECT['draft']['paste'] not in Path(result['backup_download']['path']).read_text()
        page.locator('#calendar-open').click()
        assert page.locator('#calendar-choices input:checked').count() == 3
        result['calendar_download'] = real_download(page, '#calendar-download', output / 'baseline-all-reminders.ics')
        calendar = parse_calendar(result['calendar_download']['path'])
        assert len(calendar) == 3
        result['calendar_identity'] = baseline_calendar_identity(calendar)
        assert draft_state(page) == draft
        assert by_id(stored_orders(page)) == by_id(EXPECT['orders'])
        page.locator('.ledger-panel').screenshot(path=str(output / 'baseline-active-tracker.png'))
        result['draft_preserved'] = True
    assert not events['page_errors'] and not events['external_requests']
    assert tree_files(build) == before
    result['result'] = 'PASS: independently observed existing lifecycle gap and preserved baseline exports'
except Exception:
    result['result'] = 'FAIL: receiver or baseline expectation'
    result['traceback'] = traceback.format_exc()
    raise
finally:
    result['completed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['elapsed_seconds'] = round(time.monotonic() - start, 3)
    receipt = save_json(output / 'baseline-receiving.json', result)
    print(json.dumps({'result': result['result'], 'receipt': receipt, 'elapsed_seconds': result['elapsed_seconds']}))
