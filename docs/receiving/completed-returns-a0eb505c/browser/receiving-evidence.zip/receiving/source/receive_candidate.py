from pathlib import Path
import copy
import datetime
import json
import re
import time
import traceback

from browser_common import ROOT, EXPECT, KEY, serve, private_browser, open_backup, import_backup, by_id, stored_orders, storage_text, card, prepare_draft, draft_state, real_download, parse_calendar, counters, save_json, tree_files

PIN = 'ca27fec63ff50256f1092c38453e05a527da8bce'
TREE = '8a27965e1b51946d9f49a1d5c1dfaabbf2f39037'
BUILD = ROOT / 'candidate-ca27-build'
OUTPUT = ROOT / 'evidence/candidate-ca27-attempt1'
OUTPUT.mkdir(exist_ok=False)
BASELINE = json.loads((ROOT / 'evidence/baseline-browser/baseline-receiving.json').read_text())
BEFORE = tree_files(BUILD)
CASES = []
PORTABLE = {}

def expect_focus(page, element_id):
    assert page.evaluate('document.activeElement.id') == element_id

def expect_saved(page, expected):
    assert by_id(stored_orders(page)) == by_id(expected)

def expect_summary(page, opened, soon, expired, completed):
    assert counters(page) == {'tracked': str(opened), 'soon': str(soon), 'expired': str(expired)}
    assert page.locator('#completed-count').inner_text() == str(completed)

def fault(page, name, value):
    page.evaluate('([name, value]) => { window.__receiverFixture[name] = value; }', [name, value])

def expect_refusal(page, events, action):
    count = len(events['download_events'])
    action()
    page.locator('#storage-error').wait_for(state='visible')
    expect_focus(page, 'storage-error')
    page.wait_for_timeout(100)
    assert len(events['download_events']) == count
    return page.locator('#storage-error').inner_text()

def complete(page, order_id, keyboard=False):
    control = page.locator(f'[data-complete="{order_id}"]')
    if keyboard:
        control.focus()
        control.press('Enter')
    else:
        control.click()
    expect_focus(page, 'completion-feedback')
    assert by_id(stored_orders(page))[order_id]['completedAt'] == EXPECT['fixed_now']

def reopen(page, order_id):
    page.locator(f'[data-reopen="{order_id}"]').click()
    expect_focus(page, 'completion-feedback')
    assert 'completedAt' not in by_id(stored_orders(page))[order_id]

def edit_total(page, order_id, total):
    page.locator(f'[data-edit="{order_id}"]').click()
    page.locator('#edit-dialog').wait_for(state='visible')
    page.locator('#edit-total').fill(total)
    page.locator('#edit-save').click()
    page.locator('#edit-dialog').wait_for(state='hidden')

def assert_events(path, expected_ids):
    events = parse_calendar(path)
    assert len(events) == len(expected_ids)
    assert {event['UID'][0] for event in events} == {BASELINE['calendar_identity'][key] for key in expected_ids}
    for key in expected_ids:
        event = next(e for e in events if e['UID'][0] == BASELINE['calendar_identity'][key])
        assert event['DTSTART;VALUE=DATE'] == [EXPECT['due_dates'][key].replace('-', '')]
        assert event.get('TRIGGER') == ['-P3D']
    return events

def lifecycle(context, page, details, events, folder):
    import_backup(page, ROOT / 'fixtures/approved-v1.json', 3)
    expect_saved(page, EXPECT['orders'])
    draft = prepare_draft(page)
    assert page.locator('#filter-all').inner_text() == 'Open'
    expect_summary(page, 3, 1, 1, 0)
    complete(page, 'fixture-due', keyboard=True)
    expect_summary(page, 2, 0, 1, 1)
    assert card(page, 'fixture-due').count() == 0
    complete(page, 'fixture-expired')
    expect_summary(page, 1, 0, 0, 2)
    expected = copy.deepcopy(EXPECT['orders'])
    for row in expected:
        if row['id'] != 'fixture-later':
            row['completedAt'] = EXPECT['fixed_now']
    expect_saved(page, expected)
    for selected in ['due', 'expired']:
        page.locator('#filter-' + selected).click()
        assert page.locator('#list > li.card').count() == 0
    page.locator('#filter-all').click()
    assert page.locator('#list > li.card').count() == 1
    assert card(page, 'fixture-later').count() == 1
    page.locator('#filter-completed').click()
    assert page.locator('#list > li.card').count() == 2
    assert page.locator('#list [role=progressbar], #list .days-left, #list [data-ics]').count() == 0
    assert page.locator('#list .status-tag').all_inner_texts() == ['COMPLETED', 'COMPLETED']
    for key in ['fixture-due', 'fixture-expired']:
        row = by_id(expected)[key]
        text = card(page, key).inner_text()
        for field in ['merchant', 'orderNo', 'total', 'orderDate']:
            assert row[field] in text
        assert EXPECT['due_dates'][key] in text and str(row['windowDays']) in text
        assert card(page, key).get_by_role('button', name='Edit details', exact=True).count() == 1
        assert card(page, key).get_by_role('button', name='Remove', exact=True).count() == 1
    assert draft_state(page) == draft
    page.locator('[data-edit="fixture-due"]').click()
    assert page.locator('#edit-total').input_value() == '$41.50'
    page.locator('#edit-cancel').click()
    expect_saved(page, expected)
    edit_total(page, 'fixture-due', '$42.75')
    by_id(expected)['fixture-due']['total'] = '$42.75'
    expect_saved(page, expected)
    assert '$42.75' in card(page, 'fixture-due').inner_text()
    assert draft_state(page) == draft
    details['completed_snapshot'] = copy.deepcopy(expected)
    details['history_desktop'] = str(folder / 'completed-history-desktop.png')
    page.locator('.ledger-panel').screenshot(path=details['history_desktop'])
    page.set_viewport_size({'width': 390, 'height': 844})
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    details['history_phone'] = str(folder / 'completed-history-390.png')
    page.locator('.ledger-panel').screenshot(path=details['history_phone'])
    page.set_viewport_size({'width': 1280, 'height': 920})
    details['backup'] = real_download(page, '#backup-export', folder / 'completed-reviewed-backup.json')
    portable = json.loads(Path(details['backup']['path']).read_text())
    assert portable['schema'] == 'returnby.backup' and portable['version'] == 2
    assert by_id(portable['orders']) == by_id(expected)
    assert EXPECT['draft']['paste'] not in Path(details['backup']['path']).read_text()
    PORTABLE.update({'path': details['backup']['path'], 'orders': copy.deepcopy(expected)})
    reopen(page, 'fixture-due')
    del by_id(expected)['fixture-due']['completedAt']
    expect_saved(page, expected)
    expect_summary(page, 2, 1, 0, 1)
    assert card(page, 'fixture-due').count() == 0
    page.locator('#filter-due').click()
    assert card(page, 'fixture-due').count() == 1
    assert '2026-10-11' in card(page, 'fixture-due').inner_text()
    assert draft_state(page) == draft
    page.reload(wait_until='networkidle')
    expect_saved(page, expected)
    expect_summary(page, 2, 1, 0, 1)
    details['persisted_after_reload'] = stored_orders(page)
    details['milestones'] = ['keyboard completion and focus', 'active urgency exclusion', 'literal retained history', 'completed editor preservation', '390px layout', 'actual v2 backup', 'reopen identity/deadline persistence']

def portable_status(context, page, details, events, folder):
    assert PORTABLE, 'Prerequisite actual lifecycle backup was not produced'
    draft = prepare_draft(page)
    open_backup(page)
    page.locator('#backup-file').set_input_files(PORTABLE['path'])
    page.locator('#backup-preview').wait_for(state='visible')
    text_rows = page.locator('#backup-rows li').all_inner_texts()
    assert len(text_rows) == 3
    for row in PORTABLE['orders']:
        text = next(text for text in text_rows if row['merchant'] in text)
        assert ('completed' if 'completedAt' in row else 'open') in text.lower()
    before = storage_text(page)
    fault(page, 'failWrite', True)
    page.locator('#backup-apply').click()
    assert page.locator('#backup-preview').is_visible()
    assert 'refused' in page.locator('#backup-message').inner_text()
    assert storage_text(page) == before
    assert draft_state(page) == draft
    fault(page, 'failWrite', False)
    page.locator('#backup-apply').click()
    page.locator('#backup-preview').wait_for(state='hidden')
    expect_saved(page, PORTABLE['orders'])
    expect_summary(page, 1, 0, 0, 2)
    assert draft_state(page) == draft
    details['roundtrip'] = real_download(page, '#backup-export', folder / 'restored-completed-backup.json')
    restored = json.loads(Path(details['roundtrip']['path']).read_text())
    assert restored['version'] == 2 and by_id(restored['orders']) == by_id(PORTABLE['orders'])
    page.locator('#backup-file').set_input_files(PORTABLE['path'])
    page.locator('#backup-preview').wait_for(state='visible')
    assert '3 already saved' in page.locator('#backup-summary').inner_text()
    assert page.locator('#backup-apply').is_disabled()
    page.locator('#backup-cancel').click()
    conflict = copy.deepcopy(restored)
    del by_id(conflict['orders'])['fixture-due']['completedAt']
    conflict_path = folder / 'same-id-status-conflict.json'
    save_json(conflict_path, conflict)
    unchanged = storage_text(page)
    page.locator('#backup-file').set_input_files(str(conflict_path))
    page.locator('#backup-preview').wait_for(state='visible')
    assert '1 conflicting' in page.locator('#backup-summary').inner_text()
    assert 'completedAt' in page.locator('#backup-rows').inner_text()
    assert page.locator('#backup-apply').is_disabled()
    assert storage_text(page) == unchanged
    page.locator('#backup-cancel').click()
    invalid = copy.deepcopy(restored)
    invalid['orders'][0]['completedAt'] = None
    invalid_path = folder / 'invalid-completion-marker.json'
    save_json(invalid_path, invalid)
    page.locator('#backup-file').set_input_files(str(invalid_path))
    page.wait_for_function("!document.querySelector('#backup-message').hidden && !document.querySelector('#backup-message').textContent.includes('Reading backup')")
    assert page.locator('#backup-preview').is_hidden()
    assert page.locator('#backup-message').get_attribute('role') == 'alert'
    assert storage_text(page) == unchanged
    assert draft_state(page) == draft
    details['preview_statuses'] = text_rows
    details['invalid_marker_message'] = page.locator('#backup-message').inner_text()
    details['milestones'] = ['actual file restoration', 'status preview', 'failed import preserves draft/preview', 'full approved-field roundtrip', 'same-ID status conflict', 'invalid marker refusal']

def write_refusals(context, page, details, events, folder):
    import_backup(page, ROOT / 'fixtures/approved-v1.json', 3)
    draft = prepare_draft(page)
    original = storage_text(page)
    fault(page, 'failWrite', True)
    details['complete_error'] = expect_refusal(page, events, lambda: page.locator('[data-complete="fixture-due"]').click())
    assert storage_text(page) == original and draft_state(page) == draft
    expect_summary(page, 3, 1, 1, 0)
    assert card(page, 'fixture-due').count() == 1
    details['read_only_backup_during_write_failure'] = real_download(page, '#backup-export', folder / 'backup-during-refused-completion.json')
    assert by_id(json.loads(Path(details['read_only_backup_during_write_failure']['path']).read_text())['orders']) == by_id(EXPECT['orders'])
    fault(page, 'failWrite', False)
    complete(page, 'fixture-due')
    completed = storage_text(page)
    page.locator('#filter-completed').click()
    fault(page, 'failWrite', True)
    details['reopen_error'] = expect_refusal(page, events, lambda: page.locator('[data-reopen="fixture-due"]').click())
    assert storage_text(page) == completed and draft_state(page) == draft
    expect_summary(page, 2, 0, 1, 1)
    assert card(page, 'fixture-due').count() == 1
    fault(page, 'failWrite', False)
    reopen(page, 'fixture-due')
    expect_saved(page, EXPECT['orders'])
    assert draft_state(page) == draft
    details['fault_counts'] = page.evaluate('({refusedWrites:__receiverFixture.refusedWrites, successfulWrites:__receiverFixture.successfulWrites})')
    assert details['fault_counts'] == {'refusedWrites': 2, 'successfulWrites': 3}
    details['milestones'] = ['Complete persist-before-UI', 'backup works without writes', 'Reopen persist-before-UI', 'deliberate retry succeeds once']

def stale_actions(context, page, details, events, folder):
    import_backup(page, ROOT / 'fixtures/approved-v1.json', 3)
    draft = prepare_draft(page)
    other = context.new_page()
    other.goto(page.url, wait_until='networkidle')
    edit_total(other, 'fixture-due', '$99.99')
    fresh = storage_text(other)
    details['stale_complete_error'] = expect_refusal(page, events, lambda: page.locator('[data-complete="fixture-due"]').click())
    assert storage_text(page) == fresh
    assert 'completedAt' not in by_id(stored_orders(page))['fixture-due']
    assert by_id(stored_orders(page))['fixture-due']['total'] == '$99.99'
    assert draft_state(page) == draft
    prepare_draft(other)
    other.locator('#preview [name=merchant]').fill('Fictional Neighbor Added')
    other.locator('#preview [name=orderNo]').fill('OTHER-NEW')
    other.locator('#preview button[type=submit]').click()
    latest = stored_orders(other)
    extra = [row for row in latest if row['id'] not in by_id(EXPECT['orders'])]
    assert len(extra) == 1
    complete(page, 'fixture-due')
    expected = copy.deepcopy(latest)
    by_id(expected)['fixture-due']['completedAt'] = EXPECT['fixed_now']
    expect_saved(page, expected)
    assert by_id(stored_orders(page))[extra[0]['id']] == extra[0]
    page.locator('#filter-completed').click()
    other.reload(wait_until='networkidle')
    other.locator('#filter-completed').click()
    reopen(other, 'fixture-due')
    reopened = storage_text(other)
    details['stale_reopen_error'] = expect_refusal(page, events, lambda: page.locator('[data-reopen="fixture-due"]').click())
    assert storage_text(page) == reopened
    assert 'completedAt' not in by_id(stored_orders(page))['fixture-due']
    assert by_id(stored_orders(page))[extra[0]['id']] == extra[0]
    assert draft_state(page) == draft
    details['unrelated_order_retained'] = extra[0]
    details['final_orders'] = stored_orders(page)
    details['milestones'] = ['real second-tab edit', 'stale Complete refused', 'fresh Complete retains unrelated add', 'real second-tab reopen', 'stale Reopen refused']

def calendar_lifecycle(context, page, details, events, folder):
    import_backup(page, ROOT / 'fixtures/approved-v1.json', 3)
    draft = prepare_draft(page)
    other = context.new_page()
    other.goto(page.url, wait_until='networkidle')
    page.locator('#calendar-open').click()
    page.locator('#calendar-select-none').click()
    due_choice = page.locator('#calendar-choices label').filter(has_text='Fictional Northline Outfitters').locator('input')
    due_choice.check()
    complete(other, 'fixture-due')
    saved = storage_text(other)
    count = len(events['download_events'])
    page.locator('#calendar-download').click()
    page.locator('#calendar-message').wait_for(state='visible')
    expect_focus(page, 'calendar-message')
    page.wait_for_timeout(100)
    assert len(events['download_events']) == count
    assert storage_text(page) == saved
    details['stale_selection_message'] = page.locator('#calendar-message').inner_text()
    page.locator('#calendar-reload').click()
    due_choice = page.locator('#calendar-choices label').filter(has_text='Fictional Northline Outfitters').locator('input')
    assert due_choice.is_disabled() and not due_choice.is_checked()
    page.locator('#calendar-select-all').click()
    assert page.locator('#calendar-choices input:checked').count() == 2
    details['active_only_download'] = real_download(page, '#calendar-download', folder / 'active-only-after-completion.ics')
    assert_events(details['active_only_download']['path'], ['fixture-expired', 'fixture-later'])
    assert page.locator('[data-ics="fixture-due"]').count() == 1, 'Required stale single-reminder card was unexpectedly refreshed'
    details['stale_single_message'] = expect_refusal(page, events, lambda: page.locator('[data-ics="fixture-due"]').click())
    assert storage_text(page) == saved
    assert card(page, 'fixture-due').count() == 0
    assert draft_state(page) == draft
    other.locator('#filter-completed').click()
    reopen(other, 'fixture-due')
    page.reload(wait_until='networkidle')
    page.locator('#filter-due').click()
    details['reopened_single_download'] = real_download(page, '[data-ics="fixture-due"]', folder / 'reopened-original-deadline.ics')
    assert_events(details['reopened_single_download']['path'], ['fixture-due'])
    expect_saved(page, EXPECT['orders'])
    details['milestones'] = ['stale selected reminder refused', 'completed choice disabled', 'actual active-only calendar', 'stale single reminder refused', 'reopen preserves actual calendar UID/date/alarm']

def invalid_stored_marker(context, page, details, events, folder):
    import_backup(page, ROOT / 'fixtures/approved-v1.json', 3)
    original = storage_text(page)
    malformed = json.loads(original)
    malformed[0]['completedAt'] = None
    malformed_text = json.dumps(malformed, separators=(',', ':'))
    fixture = save_json(folder / 'private-malformed-storage.json', malformed)
    other = context.new_page()
    other.goto(page.url, wait_until='networkidle')
    other.evaluate('([key, value]) => localStorage.setItem(key, value)', [KEY, malformed_text])
    page.reload(wait_until='networkidle')
    page.locator('#storage-error').wait_for(state='visible')
    assert page.locator('#storage-retry').is_visible()
    assert page.locator('#list > li.card').count() == 0
    assert counters(page) == {'tracked': '—', 'soon': '—', 'expired': '—'}
    assert page.locator('#completed-count').inner_text() == '—'
    assert storage_text(page) == malformed_text
    details['load_error'] = page.locator('#storage-error').inner_text()
    other.evaluate('([key, value]) => localStorage.setItem(key, value)', [KEY, original])
    page.locator('#storage-retry').click()
    expect_saved(page, EXPECT['orders'])
    expect_summary(page, 3, 1, 1, 0)
    assert page.locator('#storage-error').is_hidden()
    details['malformed_private_fixture'] = fixture
    details['milestones'] = ['present invalid marker refuses loading', 'raw malformed bytes retained', 'existing retry control recovers valid private fixture']

def run_case(name, callback, base_url):
    folder = OUTPUT / name
    folder.mkdir()
    events = {}
    details = {}
    row = {'name': name, 'events': events, 'details': details}
    CASES.append(row)
    start = time.monotonic()
    try:
        with private_browser(base_url, name, events) as (context, page):
            try:
                callback(context, page, details, events, folder)
            except Exception:
                details['failure_body'] = page.locator('body').inner_text()
                details['failure_focus'] = page.evaluate('document.activeElement.id')
                page.screenshot(path=str(folder / 'failure.png'), full_page=True)
                raise
        assert not events['page_errors'] and not events['external_requests']
        row['result'] = 'PASS'
    except Exception:
        row['result'] = 'FAIL'
        row['traceback'] = traceback.format_exc()
    row['elapsed_seconds'] = round(time.monotonic() - start, 3)
    save_json(folder / 'case.json', row)
    print(json.dumps({'case': name, 'result': row['result'], 'elapsed_seconds': row['elapsed_seconds']}), flush=True)

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
with serve(BUILD) as base_url:
    for name, callback in [('lifecycle', lifecycle), ('portable-status', portable_status), ('write-refusals', write_refusals), ('stale-actions', stale_actions), ('calendar-lifecycle', calendar_lifecycle), ('invalid-stored-marker', invalid_stored_marker)]:
        run_case(name, callback, base_url)
assert tree_files(BUILD) == BEFORE
result = {'schema': 'returnby.lifecycle-independent-browser.v1', 'source_commit': PIN, 'source_tree': TREE, 'started_at': started, 'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': round(time.monotonic() - start, 3), 'cases': CASES, 'passed': sum(row['result'] == 'PASS' for row in CASES), 'failed': sum(row['result'] == 'FAIL' for row in CASES), 'build_files': BEFORE, 'source_unchanged': True, 'control_files': [row for row in tree_files(ROOT / 'source') if '__pycache__' not in row['path']], 'expectations_file': str(ROOT / 'fixtures/expectations.json'), 'limits': EXPECT['limits']}
receipt = save_json(OUTPUT / 'browser-receiving.json', result)
print(json.dumps({'passed': result['passed'], 'failed': result['failed'], 'receipt': receipt}), flush=True)
raise SystemExit(1 if result['failed'] else 0)
