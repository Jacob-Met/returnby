from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import hashlib
import json
import shutil
import tempfile
import threading

from playwright.sync_api import sync_playwright

CHROME = '/root/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome'
ROOT = Path(__file__).resolve().parents[1]
EXPECT = json.loads((ROOT / 'fixtures/expectations.json').read_text())
KEY = 'returnby.v1'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    path.write_bytes(data)
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}

def tree_files(root):
    return [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
            for p in sorted(Path(root).rglob('*')) if p.is_file()]

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass

@contextmanager
def serve(build):
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(build)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}/'
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)

BOOTSTRAP = """
(() => {
  const NativeDate = Date;
  const fixture = window.__receiverFixture = {
    now: NativeDate.parse('2026-10-08T12:00:00.000Z'), failRead: false, failWrite: false,
    refusedReads: 0, refusedWrites: 0, successfulWrites: 0
  };
  class FixtureDate extends NativeDate {
    constructor(...args) { super(...(args.length ? args : [fixture.now])); }
    static now() { return fixture.now; }
  }
  window.Date = FixtureDate;
  const originalGet = Storage.prototype.getItem;
  const originalSet = Storage.prototype.setItem;
  Storage.prototype.getItem = function(key) {
    if (key === 'returnby.v1' && fixture.failRead) {
      fixture.refusedReads++;
      throw new DOMException('Private receiver injected storage read refusal', 'SecurityError');
    }
    return originalGet.call(this, key);
  };
  Storage.prototype.setItem = function(key, value) {
    if (key === 'returnby.v1' && fixture.failWrite) {
      fixture.refusedWrites++;
      throw new DOMException('Private receiver injected storage write refusal', 'QuotaExceededError');
    }
    const result = originalSet.call(this, key, value);
    if (key === 'returnby.v1') fixture.successfulWrites++;
    return result;
  };
})();
"""

@contextmanager
def private_browser(base_url, label, events):
    profile = Path(tempfile.mkdtemp(prefix='returnby-' + label + '-a0eb-'))
    events.update({'profile': str(profile), 'page_errors': [], 'external_requests': [], 'download_events': [], 'profile_removed': False})
    try:
        with sync_playwright() as runtime:
            context = runtime.chromium.launch_persistent_context(
                str(profile), executable_path=CHROME, headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage', '--disable-background-networking'],
                viewport={'width': 1280, 'height': 920}, timezone_id='UTC', accept_downloads=True,
            )
            context.add_init_script(BOOTSTRAP)
            def route(request_route):
                url = request_route.request.url
                if url.startswith(base_url):
                    request_route.continue_()
                else:
                    events['external_requests'].append(url)
                    request_route.abort()
            context.route('**/*', route)
            def bind(page):
                page.on('pageerror', lambda error: events['page_errors'].append(str(error)))
                page.on('download', lambda download: events['download_events'].append(download.suggested_filename))
            context.on('page', bind)
            for page in context.pages:
                bind(page)
            try:
                page = context.pages[0] if context.pages else context.new_page()
                page.goto(base_url, wait_until='networkidle')
                events['user_agent'] = page.evaluate('navigator.userAgent')
                yield context, page
            finally:
                context.close()
    finally:
        assert profile.name.startswith('returnby-' + label + '-a0eb-') and profile.parent == Path(tempfile.gettempdir())
        shutil.rmtree(profile)
        events['profile_removed'] = not profile.exists()

def open_backup(page):
    details = page.locator('#backup-heading').locator('..')
    if not details.get_attribute('open') and details.get_attribute('open') is None:
        page.locator('#backup-heading').click()

def import_backup(page, path, expected_count):
    open_backup(page)
    page.locator('#backup-file').set_input_files(str(path))
    page.locator('#backup-preview').wait_for(state='visible')
    text = page.locator('#backup-summary').inner_text()
    assert f'{expected_count} to add' in text, text
    page.locator('#backup-apply').click()
    page.locator('#backup-preview').wait_for(state='hidden')
    assert f'Imported {expected_count}' in page.locator('#backup-message').inner_text()

def storage_text(page):
    return page.evaluate('(key) => localStorage.getItem(key)', KEY)

def stored_orders(page):
    return json.loads(storage_text(page) or '[]')

def by_id(orders):
    result = {row['id']: row for row in orders}
    assert len(result) == len(orders), 'Duplicate stored ID'
    return result

def card(page, order_id):
    return page.locator(f'#list [data-edit="{order_id}"]').locator('xpath=ancestor::li[1]')

def draft_state(page):
    return {'paste': page.locator('#paste').input_value(), 'visible': page.locator('#preview').is_visible(),
            'fields': page.locator('#preview input').evaluate_all('(inputs) => Object.fromEntries(inputs.map(input => [input.name, input.value]))')}

def prepare_draft(page):
    draft = EXPECT['draft']
    page.locator('#paste').fill(draft['paste'])
    page.locator('#find').click()
    for field in ['merchant', 'orderDate', 'orderNo', 'total', 'windowDays']:
        page.locator(f'#preview [name="{field}"]').fill(draft[field])
    return draft_state(page)

def real_download(page, selector, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with page.expect_download(timeout=10000) as pending:
        page.locator(selector).click()
    download = pending.value
    assert download.failure() is None
    download.save_as(path)
    data = path.read_bytes()
    assert data
    return {'path': str(path), 'suggested_filename': download.suggested_filename, 'bytes': len(data), 'sha256': digest(data)}

def parse_calendar(path):
    data = Path(path).read_text()
    unfolded = data.replace('\n ', '').replace('\n\t', '')
    events = []
    for part in unfolded.split('BEGIN:VEVENT')[1:]:
        fields = {}
        for line in part.split('END:VEVENT', 1)[0].strip().splitlines():
            if ':' in line:
                key, value = line.split(':', 1)
                fields.setdefault(key, []).append(value)
        events.append(fields)
    return events

def counters(page):
    return {name: page.locator('#' + name + '-count').inner_text() for name in ['tracked', 'soon', 'expired']}

def baseline_calendar_identity(events):
    result = {}
    for order in EXPECT['orders']:
        matches = [event for event in events if order['id'] in event.get('UID', [''])[0]]
        assert len(matches) == 1, (order['id'], events)
        event = matches[0]
        assert event['DTSTART;VALUE=DATE'] == [EXPECT['due_dates'][order['id']].replace('-', '')]
        assert event.get('TRIGGER') == ['-P3D']
        result[order['id']] = event['UID'][0]
    return result
