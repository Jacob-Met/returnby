from pathlib import Path
import datetime
import hashlib
import json
import shutil
import sqlite3
import stat
import sys

ROOT = Path('/srv/hamon-estate/returnby-completion-browser-a0eb505c')
CUSTODY = Path('/var/lib/hamon/custody/returnby-completion-browser-independent-20261008-a0eb')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_new(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with Path(path).open('xb') as handle:
        handle.write(data)
    return hashlib.sha256(data).hexdigest()

pins = {
    'fixtures/approved-v1.json': '472a5e09a39518f1d285189b677489984172ab0d3ec698d5466900c066240b62',
    'fixtures/expectations.json': 'd58c789136507191da721828729c71c97b9c166ac6d81f2ede754582eacb3845',
    'evidence/pre-candidate-input-binding.json': '63590ec7c2a6b35e12f51a2a7660d0b27bb02d1f53b683d8d79fd26e8da359bf',
    'evidence/baseline-browser/baseline-receiving.json': 'ef92d0564a7d5bcb11b36b17094f96b59f3ec63027ec10d42c9b349f92439be6',
    'evidence/candidate-ca27-attempt1/browser-receiving.json': '91438128e2cac48244aaf7614e8dae5e737dd99bebbd59c89f2d02da29e6eb3e',
    'evidence/candidate-ca27-attempt2/browser-receiving.json': '7acb2184dd61a539658ef4f0ce78feadb4ef7ba8a15334b48392cc9398fa3f6e',
    'evidence/successor-readme-source-binding.json': 'ec3ec197d2ade7ede7822c1d166ac1cfbd95a40d22b9ff8a142b157c4b12863b',
    'source/receive_candidate.py': '2e8901444269e179640e474564b0a04e92c0c04b7f82942ca3e0676b21aafd2b',
    'source/receive_candidate_r2.py': '25cf7ae641ac63f86b2c3ebd61679d68a2ca76b81dc8e52956c361cf00046f30',
}
for name, expected in pins.items():
    assert sha(ROOT / name) == expected, name
assert not CUSTODY.exists(), 'Custody already exists; reconcile instead of repeating the seal'
first = json.loads((ROOT / 'evidence/candidate-ca27-attempt1/browser-receiving.json').read_text())
second = json.loads((ROOT / 'evidence/candidate-ca27-attempt2/browser-receiving.json').read_text())
baseline = json.loads((ROOT / 'evidence/baseline-browser/baseline-receiving.json').read_text())
assert (first['passed'], first['failed'], second['passed'], second['failed']) == (4, 2, 2, 0)
qualified = [case for case in first['cases'] if case['result'] == 'PASS'] + second['cases']
assert len(qualified) == 6 and len({case['name'] for case in qualified}) == 6
assert all(case['result'] == 'PASS' for case in qualified)
for case in first['cases'] + second['cases']:
    assert case['events']['profile_removed']
    assert not case['events']['external_requests'] and not case['events']['page_errors']
assert baseline['events']['profile_removed'] and not baseline['events']['external_requests'] and not baseline['events']['page_errors']

downloads = {}
def collect(value):
    if isinstance(value, dict):
        if {'path', 'suggested_filename', 'bytes', 'sha256'} <= value.keys():
            path = Path(value['path'])
            assert path.is_relative_to(ROOT) and path.stat().st_size == value['bytes'] and sha(path) == value['sha256']
            downloads[str(path.relative_to(ROOT))] = value
        for child in value.values():
            collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)
for result in [baseline, first, second]:
    collect(result)
assert len(downloads) == 8

for name in ['baseline-build-binding.json', 'candidate-ca27-build-binding.json']:
    binding = json.loads((ROOT / 'evidence' / name).read_text())
    for row in binding['build_files']:
        assert sha(Path(binding['receiving_build']) / row['path']) == row['sha256']

canonical = {
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'method': 'Direct read-only GitHub connector fetch; these are selected observed commit fields, not a copied raw response.',
    'url': 'https://api.github.com/repos/Jacob-Met/ReturnBy/git/commits/9f73bf729b59012ceda564d022a5de664c2b39e5',
    'commit': '9f73bf729b59012ceda564d022a5de664c2b39e5',
    'tree': 'e5185cdd12fa8eebfbc2f7b4afaaf1da0cc9cbe5',
    'parent': '507a9227c97a252644af03019a2ce7ab6991651d',
    'native_successor_with_identical_tree': '842a320b4b226da25bdab93a1f5076f394df3432',
}
canonical_sha = write_new(ROOT / 'evidence/canonical-commit-observation.json', canonical)
review = {
    'schema': 'returnby.lifecycle-independent-receiving-review.v1',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'worker_id': 'chatgpt-a0eb505c4971/mac_production',
    'producer_worker_id': 'chatgpt-a0eb505c4971/integration_review',
    'claim_seq': 4583,
    'producer_claim_seq': 4573,
    'result': 'No blocking finding in the scoped independent actual-browser receiving',
    'baseline_commit': '7829e56e57ef91dfe8edd5853fd68d6c7890fac0',
    'baseline_tree': 'b28e7b706fe67fd4b34111badd581c6bdd2ed4a7',
    'tested_runtime_commit': 'ca27fec63ff50256f1092c38453e05a527da8bce',
    'tested_runtime_tree': '8a27965e1b51946d9f49a1d5c1dfaabbf2f39037',
    'current_native_successor': canonical['native_successor_with_identical_tree'],
    'canonical_commit': canonical['commit'],
    'canonical_tree': canonical['tree'],
    'canonical_observation_sha256': canonical_sha,
    'source_preservation': 'Direct native Git comparison proves README is the sole successor change; all other 195 leaves and all six browser build files are exact. The stronger PR20 README is an exact prefix of the successor README.',
    'independent_contract_sha256': pins['fixtures/expectations.json'],
    'baseline_finding': 'Actual v1 import retains three fictional identities and correct due/expired counts, but offers no completion action or history. Its real backup and calendar downloads establish the original field, UID, date and alarm baseline.',
    'qualified_groups': [{'name': case['name'], 'milestones': case['details']['milestones'], 'source_attempt': 1 if case in first['cases'] else 2} for case in qualified],
    'qualification_composition': 'Four groups passed in the first run. Only the two unfinished groups ran again after correcting receiver assumptions; both then passed on the same runtime.',
    'original_attempt_preserved': {'result_sha256': pins['evidence/candidate-ca27-attempt1/browser-receiving.json'], 'passed': 4, 'stopped': 2, 'classifications': ['The backup UI reports the readable completion status/date label rather than the internal completedAt field name.', 'The calendar removes completed rows rather than retaining disabled choices. Both satisfy the pre-read contract.']},
    'focused_receiving_result_sha256': pins['evidence/candidate-ca27-attempt2/browser-receiving.json'],
    'narrative_label_note': 'The focused controller retains the inherited milestone label completed choice disabled. Its actual assertion permits an absent completed row or a disabled unchecked row; this source excludes completed rows. The attested outcome is nonselectability, not a retained disabled row.',
    'actual_downloads': [{'path': name, 'bytes': value['bytes'], 'sha256': value['sha256'], 'filename': value['suggested_filename']} for name, value in sorted(downloads.items())],
    'profile_and_data_scope': 'Nine owned temporary browser profiles across baseline, original receiving and two focused groups were closed and removed. Storage, clock and refusal controls affect only fictional local orders in those profiles. No user profile or provider account was used.',
    'network': 'No page errors or external page requests in baseline or any receiving group.',
    'product_source_edits_by_receiver': 0,
    'production_build_or_unit_reruns_by_receiver': 0,
    'github_writes_by_receiver': 0,
    'screenshots': ['evidence/baseline-browser/baseline-active-tracker.png', 'evidence/candidate-ca27-attempt1/lifecycle/completed-history-desktop.png', 'evidence/candidate-ca27-attempt1/lifecycle/completed-history-390.png'],
    'limits': ['Checks bind this exact source/build and fixed fictional UTC date; they do not establish transactional simultaneous cross-tab writes or continuous synchronization.', 'Existing external calendar files were not imported, recalled or changed; the UI states that such reminders must be removed in the external calendar.', 'Hosted CI is separate producer evidence; this review did not rerun it.', 'GitHub content-creation limits remain an independent publication condition; this review made no GitHub write.'],
}
review_sha = write_new(ROOT / 'evidence/independent-browser-review.json', review)
CUSTODY.mkdir(mode=0o755)
leaves = []
for source in sorted(ROOT.rglob('*')):
    if not source.is_file() or '__pycache__' in source.parts:
        continue
    assert not source.is_symlink()
    relative = source.relative_to(ROOT)
    target = CUSTODY / 'receiving' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    original_sha = sha(source)
    shutil.copy2(source, target)
    assert sha(target) == original_sha == sha(source)
    leaves.append({'path': str(target.relative_to(CUSTODY)), 'bytes': target.stat().st_size, 'sha256': original_sha, 'mode': stat.S_IMODE(target.stat().st_mode)})
shutil.copy2(ROOT / 'evidence/independent-browser-review.json', CUSTODY / 'independent-review.json')
assert sha(CUSTODY / 'independent-review.json') == review_sha
manifest_sha = write_new(CUSTODY / 'manifest.json', {'schema': 'returnby.lifecycle-browser-custody.v1', 'review_sha256': review_sha, 'files': leaves})

sys.path.insert(0, str(Path('/opt/hamon/current').resolve()))
from hamon_server.conscience_log import ConscienceLog
key = 'claim:chatgpt-a0eb505c4971-returnby-completion-browser'
log = ConscienceLog('/var/lib/hamon/conscience.sqlite3', initialize=False)
log.append('conscience.decision', actor='chatgpt:a0eb505c4971:coordination', payload={
    'key': key, 'worker_id': 'chatgpt-a0eb505c4971/mac_production',
    'text': 'Complete independent ReturnBy lifecycle receiving: six actual-browser groups qualified on frozen ca27 runtime, with four original passes and only two focused completions after preserved receiver-assumption stops. Eight actual baseline/candidate downloads and all source/fixtures/logs/screenshots are sealed. No scoped product blocker. Direct native and GitHub tree readback binds the README-only successor 9f73 / tree e518 with all 195 other leaves and six build files unchanged. Producer retains issue 30 and final source/consumer integration. No Mac, live-data, provider or GitHub write was performed by this receiver.',
    'value': {'status': 'completed', 'review_path': str(CUSTODY / 'independent-review.json'), 'review_sha256': review_sha, 'manifest_sha256': manifest_sha, 'canonical_commit': canonical['commit'], 'canonical_tree': canonical['tree'], 'qualified_browser_groups': 6, 'actual_downloads': 8},
}, branch='main')
log.close()
db = sqlite3.connect('file:/var/lib/hamon/conscience.sqlite3?mode=ro', uri=True)
row = db.execute("SELECT seq,event_id,payload_ref FROM conscience_events WHERE event_type='conscience.decision' AND payload_ref LIKE ? ORDER BY seq DESC LIMIT 1", ('%' + key + '%',)).fetchone()
db.close()
closure = {'seq': row[0], 'event_id': row[1], 'payload': json.loads(row[2])}
closure_sha = write_new(CUSTODY / 'native-closure.json', closure)
print(json.dumps({'review_path': str(CUSTODY / 'independent-review.json'), 'review_sha256': review_sha, 'manifest_sha256': manifest_sha, 'original_files': len(leaves), 'native_seq': row[0], 'native_event_id': row[1], 'closure_sha256': closure_sha, 'actual_downloads': len(downloads)}))
