#!/bin/zsh
set -eu
APP_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
exec /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 -B "$APP_DIR/serve.py" "$@"
