#!/usr/bin/env python3
"""Native qualification of the new ReturnBy installer and launch boundary."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PYTHON = "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3"
SOURCE = ROOT / "source"
ARCHIVE = ROOT / "qualified-preview.zip"
OUTPUT = ROOT / "author-qualification"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(folder):
    return {str(p.relative_to(folder)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
            for p in sorted(folder.rglob("*")) if p.is_file()}


vm = subprocess.check_output(["/usr/bin/vm_stat"], text=True)
page = int(re.search(r"page size of (\d+) bytes", vm).group(1))
memory = sum(int(re.search(re.escape(k) + r":\s+(\d+)\.", vm).group(1))
             for k in ["Pages free", "Pages inactive", "Pages speculative"]) * page
free = shutil.disk_usage(ROOT).free
if free < 256 * 1024 * 1024 or memory < 2 * 1024 * 1024 * 1024:
    raise SystemExit("resource guard refused before qualification")
OUTPUT.mkdir(mode=0o700, exist_ok=False)
source_before = snapshot(SOURCE)
archive_before = sha(ARCHIVE.read_bytes())
events, checks = [], []


def run(name, args):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.run(args, cwd="/tmp", text=True, capture_output=True, timeout=15)
    event = {"name": name, "args": args, "started": start,
             "ended": datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "exit": child.returncode, "stdout": child.stdout, "stderr": child.stderr}
    (OUTPUT / (name + ".json")).write_text(json.dumps(event, indent=2) + "\n")
    events.append({"name": name, "exit": child.returncode})
    return child


def check(name, value):
    checks.append({"name": name, "pass": bool(value)})
    if not value:
        raise AssertionError(name)


success = OUTPUT / "accepted-copy"
try:
    installed = run("install", [PYTHON, "-B", str(SOURCE / "install.py"),
                                "--archive", str(ARCHIVE), "--destination", str(success)])
    check("install exits zero", installed.returncode == 0)
    manifest = json.loads((success / "site/BUILD-MANIFEST.json").read_text())
    check("all nine qualified files exact", len(manifest["files"]) == 9 and
          all((success / "site" / name).stat().st_size == pin["bytes"] and
              sha((success / "site" / name).read_bytes()) == pin["sha256"]
              for name, pin in manifest["files"].items()))
    check("recovery archive exact", sha((success / "recovery/qualified-preview.zip").read_bytes()) == archive_before)
    check("launcher executable", os.access(success / "Launch ReturnBy.command", os.X_OK))
    before = snapshot(success)
    repeated = run("existing-destination", [PYTHON, "-B", str(SOURCE / "install.py"),
                                           "--archive", str(ARCHIVE), "--destination", str(success)])
    check("existing destination refused unchanged", repeated.returncode == 2 and snapshot(success) == before)
    altered = bytearray(ARCHIVE.read_bytes())
    altered[-1] ^= 1
    wrong = OUTPUT / "changed.zip"
    wrong.write_bytes(altered)
    missing = OUTPUT / "must-not-exist"
    rejected = run("changed-archive", [PYTHON, "-B", str(SOURCE / "install.py"),
                                      "--archive", str(wrong), "--destination", str(missing)])
    check("changed archive refused before destination", rejected.returncode == 2 and not os.path.lexists(missing))
    with socket.socket() as occupied:
        occupied.bind(("127.0.0.1", 48643))
        occupied.listen(1)
        checked = run("check-while-port-occupied", [str(success / "Launch ReturnBy.command"), "--check"])
        check("actual launcher check needs no port", checked.returncode == 0 and
              json.loads(checked.stdout)["sourceCommit"] == manifest["sourceCommit"])
        collision = run("occupied-port", [str(success / "Launch ReturnBy.command"), "--no-open"])
        check("occupied port refused without displacement", collision.returncode == 2 and
              occupied.getsockname() == ("127.0.0.1", 48643))
    marker = success / "INSTALLATION.json"
    marker.rename(success / "INSTALLATION.saved.json")
    incomplete = run("incomplete-copy", [str(success / "Launch ReturnBy.command"), "--check"])
    check("incomplete installation refused", incomplete.returncode == 2)
    (success / "INSTALLATION.saved.json").rename(marker)
    asset = success / "site/index.html"
    original = asset.read_bytes()
    changed = bytes([original[0] ^ 1]) + original[1:]
    asset.write_bytes(changed)
    tampered = run("changed-installed-asset", [str(success / "Launch ReturnBy.command"), "--check"])
    check("changed asset refused", tampered.returncode == 2)
    check("qualification inputs preserved", snapshot(SOURCE) == source_before and sha(ARCHIVE.read_bytes()) == archive_before)
finally:
    receipt = {"schema": "returnby-local-preview-author-qualification-v1",
               "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "free_disk_before": free, "memory_estimate_before": memory,
               "events": events, "checks": checks,
               "source_before": source_before, "source_after": snapshot(SOURCE),
               "archive_sha256_before": archive_before, "archive_sha256_after": sha(ARCHIVE.read_bytes())}
    (OUTPUT / "RESULT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"events": events, "checks": checks, "result": str(OUTPUT / "RESULT.json")}, indent=2))
