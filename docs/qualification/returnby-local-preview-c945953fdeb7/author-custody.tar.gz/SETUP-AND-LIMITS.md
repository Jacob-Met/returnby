# Local preview author setup and limits

The first Mac resource reader failed with AttributeError while parsing the vm_stat header because its regular expression was escaped incorrectly. It stopped before checking the destination, port or browser and before any source or installation write. The unchanged admission limits were then applied by the corrected reader; its complete tool result is retained.

The first in-memory JavaScript call defining candidate strings failed at parsing because Markdown backticks were not escaped inside a template literal. No part of that call executed and no file or tool mutation occurred. The corrected source-definition call then succeeded; the first native source freeze is source-freeze.json.

The independent receiver contract was retained natively before the first candidate source write. Author tests were created after candidate source and are explicitly same-author qualification. Their seven child invocations and eleven assertions cover installer/entrypoint behavior; they do not repeat the product owner's C1-C7 application campaign.

The original product package has exactly nine qualified files and one unchanged build manifest. It remains a separately qualified owner-baseline preview, not a canonical-main composition or LA7 installed adoption. Native installation here is a new Mac-local directory only. Default-browser/Finder activation and a human using the app have not yet been observed by this author. Independent actual running-use receiving is a separate record.

No Git ref, PR, merge, workflow, dependency installation, shared service, startup item, paid resource, account, credential or access change was performed. The local HTTP address is loopback only. Existing package copies and owner installations remain unchanged.
